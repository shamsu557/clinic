# The Clinic DiabetesCare — Android and iPhone PWA

## Included changes

- Android: installable Progressive Web App manifest, app icons, service worker, and a pop-up invitation with an **Install app** button. If the browser offers the native install prompt, the button uses it; otherwise it explains how to install using Chrome's menu.
- iPhone/iPad: automatic on-page instructions for Share → Add to Home Screen, with **Open as Web App** where supported.
- The invitation can be dismissed. It remains hidden for the current page load, but returns on the next visit/reload if the app was not installed. The browser itself determines whether and when it allows a native Android install dialog.
- App opens in standalone mode after successful installation. Instructions are hidden inside an installed app.
- Separate clinic telephone contact **09099009988** (`tel:+2349099009988`) and emails **supports@theclinic.com.ng** and **mmramalan@gmail.com**, shown as clickable links in the site footer and on the sign-in page.
- **The previously configured WhatsApp number is preserved.** WhatsApp contact and outgoing alerts continue to use the existing `whatsapp_number` value and the existing `whatsapp_enabled` setting; neither is replaced by the contact phone number.
- Security: sensitive medical records, API calls, user sessions, HTML pages and uploads are never placed in PWA caches. Without internet, a basic offline notice displays instead.

## Deployment — Node/Express

1. Back up the existing live website and database.
2. Extract `clinic-pwa-update.zip`. Copy its `clinic/` folders over the existing `clinic/` project folder. Preserve the server's **existing `.env`, `uploads/` and MySQL database**; the archive deliberately does not include them.
3. In the project directory run `npm install` if necessary. (The archive omits `node_modules`.) No new runtime dependencies are added.
4. **Do not change or reset the WhatsApp number.** No database migration is required. The older `scripts/set-clinic-phone.js` is now a harmless informational command and does not write to the database. The phone/email contacts are separate website contact details. Leave the existing WhatsApp alerts setting as it is.
5. Restart the Node.js app (using your hosting platform's normal restart process). Ensure the domain is served using **HTTPS** with a valid certificate.
6. Open `https://YOUR-DOMAIN/manifest.webmanifest`, `https://YOUR-DOMAIN/sw.js`, and `https://YOUR-DOMAIN/assets/icons/icon-192.png` to confirm a `200` response. The site must be hosted at `/` (this application's API paths are rooted at `/api`).
7. Test on an Android Chrome browser and an iPhone Safari browser. If a previous service worker was installed, reload once or reopen the website to activate the new version. Check that the existing WhatsApp alerts number still appears under Owner → WhatsApp alerts and that WhatsApp buttons go to that same number.

## User installation

**Android (Chrome):** Visit the website. Tap **Install app** in the bottom pop-up. If Chrome does not present an installation dialog yet, follow the displayed **⋮ → Install app / Add to Home screen** instructions. Installability and native prompt timing depend on Chrome and cannot be forced on every visit.

**iPhone (Safari):** Visit the website, tap **Share** (or the page menu then **Share**), choose **Add to Home Screen**, select **Open as Web App** if offered and tap **Add**. iOS doesn't support the JavaScript native `beforeinstallprompt` flow.

On both platforms, closing the invitation only hides it until the next page load. Once launched from an installed Home Screen icon, it is hidden.

## Verification and cautions

- This package is a **deployment-ready source update**, not an APK or an iOS App Store package.
- No production server or database was accessible from the supplied ZIP. This release deliberately does not modify the WhatsApp database setting. Deploy the files to publish the new phone and emails.
- The uploaded ZIP did not contain the project's `db/migrations/*.sql` files. Keep those from the live server; this PWA change does not require a schema migration.
- Do not upload your `.env`, database backups, or confidential uploads to any public web directory.
- Updating `public/sw.js` in future versions requires changing `VERSION` to a new unique string to refresh cached CSS and scripts.
