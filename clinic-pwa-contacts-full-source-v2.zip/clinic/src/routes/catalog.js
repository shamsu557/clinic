'use strict';
const express = require('express');
const config = require('../config');
const { db, tx } = require('../db');
const V = require('../lib/validate');
const T = require('../lib/time');
const sched = require('../lib/schedule');
const { audit } = require('../lib/audit');
const { notify, notifyPermission } = require('../lib/notify');
const { requirePerm, requirePortal } = require('../middleware/auth');

const router = express.Router();
const { HttpError, bad } = V;

// ---------- Payment account details (shown to patients while booking) ----------
router.get('/settings/payment', async (req, res, next) => {
  try {
    const [rows] = await db.query("SELECT setting_key k, setting_value v FROM app_settings WHERE setting_key LIKE 'payment_%'");
    const m = Object.fromEntries(rows.map((r) => [r.k, r.v]));
    res.json({ accountName: m.payment_account_name, bank: m.payment_bank, accountNumber: m.payment_account_number, instructions: m.payment_instructions });
  } catch (e) { next(e); }
});

// Public clinic contact information; separate from the existing WhatsApp alert destination.
// WhatsApp visibility continues to follow the original enable/disable setting.
router.get('/settings/contact', async (req, res, next) => {
  try {
    const s = await require('../lib/whatsapp').settings(db);
    res.json({
      phoneNumber: '09099009988',
      emailAddresses: ['supports@theclinic.com.ng', 'mmramalan@gmail.com'],
      whatsappNumber: s.enabled && s.number ? s.number : null,
    });
  } catch (e) { next(e); }
});

// ---------- Services & fees ----------
const shapeService = (s) => ({ id: s.id, name: s.name, description: s.description, fee: Number(s.fee), active: !!s.active });

router.get('/services', async (req, res, next) => {
  try {
    const all = req.user && req.user.permissions.includes('services.manage') && req.query.all === '1';
    const [rows] = await db.query(`SELECT * FROM services ${all ? '' : 'WHERE active=1'} ORDER BY name`);
    let out = rows.map(shapeService);
    if (all) {
      const [cnt] = await db.query("SELECT service_id, COUNT(*) n, SUM(status='requested') pending FROM bookings GROUP BY service_id");
      out = out.map((s) => { const c = cnt.find((x) => x.service_id === s.id); return { ...s, bookings: c ? c.n : 0, pendingRequests: c ? Number(c.pending) : 0 }; });
    }
    res.json({ services: out });
  } catch (e) { next(e); }
});

router.post('/services', requirePerm('services.manage'), async (req, res, next) => {
  try {
    const b = req.body || {};
    const name = V.str(b.name, { min: 2, max: 120, field: 'Service name' });
    const description = V.str(b.description, { max: 500, field: 'Description', required: false });
    const fee = V.money(b.fee);
    try {
      await tx(async (c) => {
        const [r] = await c.query('INSERT INTO services (name, description, fee, active, created_by) VALUES (?,?,?,?,?)', [name, description, fee, b.active === false ? 0 : 1, req.user.id]);
        await audit(c, req, 'service.create', 'service', r.insertId, { name, fee });
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'A service with this name already exists.'); throw e; }
    res.status(201).json({ ok: true });
  } catch (e) { next(e); }
});

router.patch('/services/:id', requirePerm('services.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Service' });
    const [[old]] = await db.query('SELECT * FROM services WHERE id=?', [id]);
    if (!old) throw new HttpError(404, 'Service not found.');
    const b = req.body || {}; const sets = []; const vals = []; const changes = {};
    if (b.name !== undefined) { sets.push('name=?'); vals.push(V.str(b.name, { min: 2, max: 120, field: 'Service name' })); }
    if (b.description !== undefined) { sets.push('description=?'); vals.push(V.str(b.description, { max: 500, required: false, field: 'Description' })); }
    if (b.fee !== undefined) { const f = V.money(b.fee); sets.push('fee=?'); vals.push(f); changes.fee = { from: Number(old.fee), to: f }; }
    if (b.active !== undefined) { sets.push('active=?'); vals.push(b.active ? 1 : 0); changes.active = !!b.active; }
    if (!sets.length) throw bad('Nothing to update.');
    try {
      await tx(async (c) => {
        await c.query(`UPDATE services SET ${sets.join(', ')} WHERE id=?`, [...vals, id]); // existing bookings keep their snapshot fee
        await audit(c, req, 'service.update', 'service', id, changes);
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'A service with this name already exists.'); throw e; }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- Consultants (for the booking form) ----------
router.get('/consultants', async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.full_name, c.specialty, c.bio FROM consultants c JOIN users u ON u.id=c.user_id
        WHERE u.status='active' AND c.accepting_bookings=1
          AND EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND r.portal='consultant')
        ORDER BY u.full_name`);
    res.json({ consultants: rows.map((r) => ({ id: r.id, fullName: r.full_name, specialty: r.specialty, bio: r.bio })) });
  } catch (e) { next(e); }
});

/** Dates (next N days) on which the consultant still has at least one free slot. */
router.get('/consultants/:id/dates', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Consultant' });
    const [ok] = await db.query("SELECT 1 FROM consultants c JOIN users u ON u.id=c.user_id WHERE c.user_id=? AND u.status='active' AND c.accepting_bookings=1 AND EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND r.portal='consultant')", [id]);
    if (!ok.length) throw new HttpError(404, 'Consultant not found.');
    const today = T.nowLocal().date; const dates = [];
    for (let i = 0; i <= config.maxBookingDaysAhead; i++) {
      const d = T.addDays(today, i);
      const slots = await sched.slotsFor(db, id, d);
      const free = slots.filter((s) => s.available).length;
      if (free) dates.push({ date: d, freeSlots: free });
    }
    res.json({ dates });
  } catch (e) { next(e); }
});

router.get('/consultants/:id/slots', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Consultant' });
    const date = String(req.query.date || '');
    if (!T.isValidDate(date)) throw bad('Please choose a valid date.');
    const slots = await sched.slotsFor(db, id, date);
    res.json({ date, slots });
  } catch (e) { next(e); }
});

// ---------- Consultant's own availability ----------
const consultantOnly = [requirePortal('consultant')];

async function myRules(consultantId) {
  const [rules] = await db.query(
    `SELECT id, rule_type, day_of_week, specific_date, start_time, end_time, slot_minutes FROM consultant_availability
      WHERE consultant_id=? AND (rule_type='weekly' OR specific_date >= ?) ORDER BY rule_type, day_of_week, specific_date, start_time`,
    [consultantId, T.nowLocal().date]);
  const [blocked] = await db.query('SELECT id, blocked_date, reason FROM consultant_blocked_dates WHERE consultant_id=? AND blocked_date >= ? ORDER BY blocked_date', [consultantId, T.nowLocal().date]);
  const [[me]] = await db.query('SELECT accepting_bookings, specialty, bio FROM consultants WHERE user_id=?', [consultantId]);
  return {
    accepting: !!me.accepting_bookings, specialty: me.specialty, bio: me.bio,
    rules: rules.map((r) => ({ id: r.id, type: r.rule_type, dayOfWeek: r.day_of_week, date: r.specific_date,
      startTime: r.start_time.slice(0, 5), endTime: r.end_time.slice(0, 5), slotMinutes: r.slot_minutes })),
    blocked: blocked.map((b) => ({ id: b.id, date: b.blocked_date, reason: b.reason })),
  };
}

/** After any availability change, flag existing bookings that now fall outside the new hours (they are never auto-cancelled). */
async function afterAvailabilityChange(req, consultantId) {
  const affected = await sched.bookingsOutsideAvailability(db, consultantId);
  if (affected.length) {
    await notifyPermission(null, 'bookings.manage', 'availability_conflict', 'Consultant availability changed',
      `${req.user.fullName} changed availability; ${affected.length} existing booking(s) now fall outside the new hours and need review.`);
  }
  return affected.map((b) => ({ id: b.id, code: b.booking_code, date: b.appointment_date, startTime: b.start_time.slice(0, 5), status: b.status }));
}

router.get('/availability', ...consultantOnly, async (req, res, next) => {
  try { res.json(await myRules(req.user.id)); } catch (e) { next(e); }
});

router.post('/availability', ...consultantOnly, async (req, res, next) => {
  try {
    const b = req.body || {};
    const type = b.type === 'date' ? 'date' : 'weekly';
    const start = T.normTime(b.startTime); const end = T.normTime(b.endTime);
    if (!start || !end || end <= start) throw bad('Please enter a valid start and end time (end must be after start).');
    const slot = V.int(b.slotMinutes, { min: 10, max: 240, field: 'Appointment length' });
    if (T.toMin(end) - T.toMin(start) < slot) throw bad('The time range is shorter than one appointment.');
    let dayOfWeek = null; let date = null;
    if (type === 'weekly') dayOfWeek = V.int(b.dayOfWeek, { min: 0, max: 6, field: 'Day of week' });
    else {
      date = String(b.date || '');
      if (!T.isValidDate(date) || date < T.nowLocal().date) throw bad('Please choose a valid future date.');
    }
    // reject overlapping ranges within the same day/rule type
    const [existing] = await db.query(
      `SELECT start_time, end_time FROM consultant_availability WHERE consultant_id=? AND rule_type=? AND ${type === 'weekly' ? 'day_of_week=?' : 'specific_date=?'}`,
      [req.user.id, type, type === 'weekly' ? dayOfWeek : date]);
    if (existing.some((r) => r.start_time < end && r.end_time > start)) throw bad('This time range overlaps one you already set for that day.');
    await db.query('INSERT INTO consultant_availability (consultant_id, rule_type, day_of_week, specific_date, start_time, end_time, slot_minutes) VALUES (?,?,?,?,?,?,?)',
      [req.user.id, type, dayOfWeek, date, start, end, slot]);
    res.status(201).json({ ok: true, affectedBookings: await afterAvailabilityChange(req, req.user.id) });
  } catch (e) { next(e); }
});

router.delete('/availability/:id', ...consultantOnly, async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Rule' });
    const [r] = await db.query('DELETE FROM consultant_availability WHERE id=? AND consultant_id=?', [id, req.user.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Availability entry not found.');
    res.json({ ok: true, affectedBookings: await afterAvailabilityChange(req, req.user.id) });
  } catch (e) { next(e); }
});

router.post('/availability/blocked', ...consultantOnly, async (req, res, next) => {
  try {
    const date = String((req.body || {}).date || '');
    if (!T.isValidDate(date) || date < T.nowLocal().date) throw bad('Please choose a valid future date.');
    try {
      await db.query('INSERT INTO consultant_blocked_dates (consultant_id, blocked_date, reason) VALUES (?,?,?)',
        [req.user.id, date, V.str(req.body.reason, { max: 200, required: false, field: 'Reason' })]);
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That date is already blocked.'); throw e; }
    res.status(201).json({ ok: true, affectedBookings: await afterAvailabilityChange(req, req.user.id) });
  } catch (e) { next(e); }
});

router.delete('/availability/blocked/:id', ...consultantOnly, async (req, res, next) => {
  try {
    const [r] = await db.query('DELETE FROM consultant_blocked_dates WHERE id=? AND consultant_id=?', [V.int(req.params.id, { field: 'Entry' }), req.user.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Entry not found.');
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.patch('/availability/profile', ...consultantOnly, async (req, res, next) => {
  try {
    const b = req.body || {};
    await db.query('UPDATE consultants SET accepting_bookings=?, specialty=?, bio=? WHERE user_id=?',
      [b.accepting ? 1 : 0, V.str(b.specialty, { max: 120, required: false, field: 'Specialty' }), V.str(b.bio, { max: 500, required: false, field: 'Bio' }), req.user.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;
