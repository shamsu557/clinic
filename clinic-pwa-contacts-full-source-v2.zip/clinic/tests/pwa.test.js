'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const appDir = path.join(__dirname, '..');
const source = fs.readFileSync(path.join(appDir, 'public/assets/js/pwa-install.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(appDir, 'public/manifest.webmanifest'), 'utf8'));
function create(ua, standalone = false) {
  const dom = new JSDOM('<!doctype html><html><body><div id="pwaInstallRoot"></div></body></html>', {
    url: 'https://clinic.example/', runScripts: 'outside-only'
  });
  const w = dom.window;
  Object.defineProperty(w.navigator, 'userAgent', { configurable: true, value: ua });
  Object.defineProperty(w.navigator, 'platform', { configurable: true, value: /iPhone/.test(ua) ? 'iPhone' : 'Linux armv8l' });
  w.matchMedia = () => ({ matches: standalone, addEventListener(){} });
  w.setTimeout = (f) => { f(); return 1; };
  w.eval(source);
  return dom;
}
function pwaRoot(dom) { return dom.window.document.getElementById('pwaInstallRoot'); }
function click(dom, action) {
  const el = pwaRoot(dom).querySelector(`[data-pwa="${action}"]`);
  assert.ok(el, `${action} button exists`); el.click();
}
(async () => {
  assert.equal(manifest.display, 'standalone');
  assert.equal(manifest.start_url, '/');
  assert.ok(manifest.icons.some((i) => i.sizes === '192x192'));
  assert.ok(manifest.icons.some((i) => i.sizes === '512x512'));
  const iphone = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1';
  const android = 'Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36';
  const ios = create(iphone);
  assert.match(pwaRoot(ios).textContent, /Add to Home Screen/);
  assert.match(pwaRoot(ios).textContent, /Open as Web App/);
  click(ios, 'install');
  assert.equal(pwaRoot(ios).textContent, '', 'iOS dismiss hides guide this page load');
  ios.window.close();
  const secondVisit = create(iphone);
  assert.match(pwaRoot(secondVisit).textContent, /Add to Home Screen/, 'invite returns on next visit');
  secondVisit.window.close();
  const a = create(android);
  assert.match(pwaRoot(a).textContent, /Install app/);
  click(a, 'install');
  assert.match(pwaRoot(a).textContent, /Chrome/, 'manual guidance shown when no native prompt');
  click(a, 'later');
  assert.equal(pwaRoot(a).textContent, '', 'dismisses on Android');
  a.window.close();
  const b = create(android);
  let promptCalls = 0;
  const e = new b.window.Event('beforeinstallprompt', { cancelable: true });
  e.prompt = async () => { promptCalls++; };
  e.userChoice = Promise.resolve({ outcome: 'accepted' });
  b.window.dispatchEvent(e);
  assert.equal(e.defaultPrevented, true, 'custom banner controls browser prompt');
  click(b, 'install');
  await new Promise((resolve) => setTimeout(resolve, 10));
  assert.equal(promptCalls, 1, 'native prompt called on tap');
  assert.equal(pwaRoot(b).textContent, '', 'banner hides after native acceptance');
  b.window.close();
  const c = create(android, true);
  assert.equal(pwaRoot(c).textContent, '', 'installed standalone view does not show banner');
  c.window.close();
  const worker = fs.readFileSync(path.join(appDir, 'public/sw.js'), 'utf8');
  assert.ok(worker.includes("request.mode === 'navigate'"), 'navigation network-only');
  assert.ok(worker.includes("!PUBLIC_ASSETS.has(url.pathname)"), 'unlisted/private paths not cached');
  console.log('PWA tests passed: manifest, iOS, Android fallback/native, revisit and standalone, sensitive cache exclusion.');
})().catch((e) => { console.error(e); process.exitCode = 1; });
