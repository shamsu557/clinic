'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const base = path.join(__dirname, '..');
const get = (x) => fs.readFileSync(path.join(base, x), 'utf8');
const html = new JSDOM(get('public/index.html'));
const doc = html.window.document;
const footer = doc.querySelector('#clinicContactFooter');
assert.ok(footer, 'contact footer exists');
for (const href of ['tel:+2349099009988','mailto:supports@theclinic.com.ng','mailto:mmramalan@gmail.com']) {
  assert.ok(footer.querySelector(`a[href="${href}"]`), `clickable link: ${href}`);
}
const auth = get('public/assets/js/auth.js');
for (const email of ['supports@theclinic.com.ng', 'mmramalan@gmail.com']) assert.ok(auth.includes(email), 'sign-in shows ' + email);
const whatsapp = get('src/lib/whatsapp.js');
assert.match(whatsapp, /number:\s*m\.whatsapp_number\s*\|\|\s*''/, 'original WhatsApp number setting remains source of truth');
assert.doesNotMatch(whatsapp, /09099009988/, 'new contact number not used for WhatsApp');
const endpoint = get('src/routes/catalog.js');
assert.match(endpoint, /whatsappNumber: s\.enabled && s\.number \? s\.number : null/, 'WhatsApp endpoint respects existing enabled flag and existing number');
assert.match(endpoint, /phoneNumber: '09099009988'/, 'phone contact separately returned');
assert.doesNotMatch(get('scripts/set-clinic-phone.js'), /UPDATE\s+app_settings|INSERT\s+INTO\s+app_settings/i, 'legacy script cannot overwrite WhatsApp');
console.log('Contact tests passed: telephone and both emails published; WhatsApp configuration unchanged.');
