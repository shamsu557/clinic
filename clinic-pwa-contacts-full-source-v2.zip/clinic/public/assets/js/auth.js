'use strict';
/* Public pages: home (with the login card), patient registration, password recovery, first-time setup. */
(function (App) {
  const { esc, UI, btn } = App; const S = App.state;
  const field = (label, name, type = 'text', extra = '') => `<div><label class="${UI.label}" for="f_${name}">${label}</label><input id="f_${name}" name="${name}" type="${type}" class="${UI.input}" ${extra}></div>`;
  const submitBtn = (label, kind = 'primary') => `<button type="submit" class="w-full ${UI.btn} ${kind === 'success' ? 'bg-brand-gold hover:bg-[#a0723b] text-white shadow' : 'bg-brand-teal hover:bg-brand-ink text-white shadow-lg'} py-3 font-semibold tracking-wide">${esc(label)}</button>`;
  const link = (label, action) => `<button type="button" data-action="${action}" class="text-brand-teal hover:text-brand-ink font-semibold underline-offset-2 hover:underline">${label}</button>`;

  const icon = (d) => `<span class="flex-none w-10 h-10 rounded-full bg-white/80 ring-1 ring-brand-gold/40 text-brand-teal flex items-center justify-center shadow-sm"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">${d}</svg></span>`;
  const perk = (d, title, text) => `<li class="flex items-start gap-4 text-left">${icon(d)}<div><div class="font-semibold text-brand-ink">${title}</div><div class="text-sm text-gray-600">${text}</div></div></li>`;

  /** Branded home layout: promise on the left, the active card (login / register / …) on the right, health artwork behind.
   *  The logo lives in the navbar only. Sized to fit one screen: on short screens the extra copy is hidden instead of scrolling. */
  const hero = (cardHtml, wide = false) => `<section class="relative isolate overflow-hidden bg-brand-ivory flex-1 flex items-center">
    <div class="hero-photo absolute inset-0 -z-10" aria-hidden="true"></div>
    <img src="./assets/images/health-bg.svg" alt="" aria-hidden="true" class="absolute inset-0 -z-10 w-full h-full object-cover opacity-[0.22] select-none pointer-events-none">
    <div class="absolute inset-0 -z-10 bg-gradient-to-br from-white/80 via-brand-ivory/40 to-brand-mist/90" aria-hidden="true"></div>
    <div class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-5 lg:py-6 grid lg:grid-cols-2 gap-6 lg:gap-14 items-center">
      <div class="text-center lg:text-left rise">
        <h1 class="font-script italic font-semibold text-[1.9rem] leading-[1.08] sm:text-5xl lg:text-6xl text-brand-teal">Specialist diabetes care,<br> wherever you are.</h1>
        <div class="gold-rule my-3 lg:my-5 max-w-xs mx-auto lg:mx-0"></div>
        <p class="hidden sm:block text-gray-700 sm:text-base lg:text-lg max-w-xl mx-auto lg:mx-0 [@media(max-height:760px)]:!hidden">Consult our endocrinology and diabetes specialists by secure video, share your test results safely, and receive prescriptions you can take straight to the pharmacy.</p>
        <ul class="mt-6 space-y-3 max-w-md mx-auto lg:mx-0 hidden lg:block [@media(max-height:760px)]:!hidden">
          ${perk('<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3z"/>', 'Secure video consultations', 'Meet your specialist on Google Meet from home.')}
          ${perk('<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/>', 'Simple booking', 'Choose a service, consultant and time that suits you.')}
          ${perk('<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>', 'Private by design', 'Your records are visible only to you and the consultant you booked.')}
        </ul>
      </div>
      <div class="w-full ${wide ? 'max-w-xl' : 'max-w-md'} mx-auto lg:mr-0 lg:ml-auto rise">${cardHtml}</div>
    </div></section>`;

  const card = (title, sub, inner, footer = '') => `<div class="tight-card bg-white/85 backdrop-blur-md rounded-2xl shadow-2xl ring-1 ring-brand-gold/25 border border-white/70 p-5 sm:p-7">
    <div class="text-center mb-4 sm:mb-5"><div class="gold-rule w-16 mx-auto mb-3"></div><h2 class="font-display font-semibold tracking-[0.12em] uppercase text-xl sm:text-2xl text-brand-ink">${esc(title)}</h2><p class="mt-1.5 text-sm text-gray-600 [@media(max-height:700px)]:hidden">${esc(sub)}</p></div>${inner}${footer}</div>`;

  function loginCard() {
    return card('Login Portal', 'Sign in with your email address or phone number', `
      <form data-form="login" class="space-y-4" autocomplete="on">
        ${field('Email or Phone Number', 'identifier', 'text', 'required autocomplete="username" inputmode="email" placeholder="you@example.com or 0803 000 0000"')}
        <div><label class="${UI.label}" for="f_password">Password</label><div class="relative"><input id="f_password" name="password" type="password" required autocomplete="current-password" class="${UI.input} pr-16">
          <button type="button" data-action="togglePw" class="absolute inset-y-0 right-3 text-sm font-semibold text-brand-teal">Show</button></div></div>
        <div class="text-right text-sm">${link('Forgot password?', 'showForgot')}</div>${submitBtn('Sign in')}</form>
      <div class="flex items-center gap-3 my-4 text-xs uppercase tracking-widest text-gray-400 [@media(max-height:700px)]:!hidden"><span class="flex-1 gold-rule"></span>New here?<span class="flex-1 gold-rule"></span></div>
      <button type="button" data-action="showRegister" class="w-full ${UI.btn} border-2 border-brand-gold text-brand-ink hover:bg-brand-gold hover:text-white py-3 font-semibold tracking-wide [@media(max-height:700px)]:mt-3">Create a patient account</button>
      <p class="mt-4 text-center text-xs text-gray-500 [@media(max-height:780px)]:!hidden">Patients, consultants and clinic staff all sign in here.</p>
      <div class="mt-3 text-center text-xs text-gray-700 space-y-1"><p>Need help? Call <a href="tel:+2349099009988" class="font-semibold text-brand-teal underline">09099009988</a></p><p><a href="mailto:supports@theclinic.com.ng" class="text-brand-teal underline">supports@theclinic.com.ng</a> · <a href="mailto:mmramalan@gmail.com" class="text-brand-teal underline">mmramalan@gmail.com</a></p></div>`);
  }
  const footLogin = `<div class="mt-6 text-center text-sm text-gray-600">${link('← Back to sign in', 'showLogin')}</div>`;

  App.views.landing = (root) => { root.innerHTML = hero(loginCard()); };
  App.views.login = App.views.landing;

  App.actions.togglePw = (el) => { const i = el.parentElement.querySelector('input'); i.type = i.type === 'password' ? 'text' : 'password'; el.textContent = i.type === 'password' ? 'Show' : 'Hide'; };
  App.forms.login = async (f, d) => {
    const r = await App.api.post('/auth/login', { identifier: d.identifier, password: d.password });
    S.user = r.user; await loadMe(); enter();
  };
  async function loadMe() { const d = await App.api.get('/auth/me'); S.user = d.user; S.app = d.app || {}; }
  function enter() {
    S.tab = null; S.portal = S.user.portal;
    if (S.user.mustChangePassword || S.user.mustSetupSecurity) return App.go('setup');
    if (S.user.needRole) return App.go('chooseRole');
    App.go('portal');
  }
  App.enter = enter; App.loadMe = loadMe;

  App.views.register = (root) => {
    root.innerHTML = hero(card('Create Account', 'Join The Clinic as a patient', `
      <form data-form="register" class="space-y-3" novalidate>
        ${field('Full Name *', 'fullName', 'text', 'required autocomplete="name" maxlength="150"')}
        <div class="grid grid-cols-2 gap-3">${field('Age *', 'age', 'number', 'required min="0" max="120"')}
          <div><label class="${UI.label}" for="f_gender">Gender *</label><select id="f_gender" name="gender" required class="${UI.input}"><option value="">Select</option><option>Male</option><option>Female</option></select></div></div>
        <div class="grid sm:grid-cols-2 gap-3">${field('Email Address *', 'email', 'email', 'required autocomplete="email"')}${field('Phone Number *', 'phone', 'tel', 'required autocomplete="tel" placeholder="0803 000 0000"')}</div>
        <div class="grid sm:grid-cols-2 gap-3">${field('Password * (min 6)', 'password', 'password', 'required minlength="6" autocomplete="new-password"')}${field('Confirm Password *', 'confirmPassword', 'password', 'required minlength="6" autocomplete="new-password"')}</div>
        ${submitBtn('Create account')}</form>
      <div class="mt-4 text-center text-sm text-gray-600">Already registered? ${link('Sign in', 'showLogin')}</div>`), true);
  };
  App.forms.register = async (f, d) => {
    await App.api.post('/auth/register', d);
    App.toast('Account created. Please sign in with your email or phone number.', 'success'); App.go('login');
  };

  // ----- password recovery -----
  let rec = { step: 1 };
  App.views.forgot = (root) => {
    let c;
    if (rec.step === 1) c = card('Reset Password', 'Enter the email or phone number you registered with', `
      <form data-form="recStart" class="space-y-5">${field('Email or Phone Number', 'identifier', 'text', 'required autocomplete="username"')}${submitBtn('Continue')}</form>${footLogin}`);
    else if (rec.step === 2) c = card('Verify It’s You', 'Answer your security question', `
      <form data-form="recVerify" class="space-y-5"><div class="p-4 bg-brand-mist rounded-lg border border-brand-teal/15"><div class="text-[11px] font-bold text-brand-teal uppercase tracking-widest mb-1">Security question</div><div class="font-semibold text-brand-ink">${esc(rec.question)}</div></div>
        ${field('Your answer', 'answer', 'text', 'required autocomplete="off"')}
        ${rec.otpRequired ? field('6-digit code sent to your email', 'otp', 'text', 'required inputmode="numeric" maxlength="6" autocomplete="one-time-code"') : ''}
        ${submitBtn('Verify')}</form>${footLogin}`);
    else c = card('New Password', 'Choose a password of at least 6 characters', `
      <form data-form="recReset" class="space-y-5">${field('New Password', 'newPassword', 'password', 'required minlength="6" autocomplete="new-password"')}${field('Confirm Password', 'confirmPassword', 'password', 'required minlength="6" autocomplete="new-password"')}${submitBtn('Reset password', 'success')}</form>${footLogin}`);
    root.innerHTML = hero(c);
  };
  App.actions.showForgot = () => { rec = { step: 1 }; App.go('forgot'); };
  App.forms.recStart = async (f, d) => { const r = await App.api.post('/auth/recover/start', { identifier: d.identifier }); rec = { step: 2, token: r.recoveryToken, question: r.question, otpRequired: r.otpRequired }; App.render(); };
  App.forms.recVerify = async (f, d) => {
    try { const r = await App.api.post('/auth/recover/verify', { recoveryToken: rec.token, answer: d.answer, otp: d.otp }); rec.resetToken = r.resetToken; rec.step = 3; App.render(); }
    catch (e) { if (e.status === 429 || /expired/i.test(e.message)) { rec = { step: 1 }; App.render(); } throw e; }
  };
  App.forms.recReset = async (f, d) => {
    await App.api.post('/auth/recover/reset', { resetToken: rec.resetToken, newPassword: d.newPassword, confirmPassword: d.confirmPassword });
    rec = { step: 1 }; App.toast('Password changed. Please sign in with your new password.', 'success'); App.go('login');
  };

  // ----- forced first-time setup -----
  App.views.setup = async (root) => {
    const u = S.user; if (!u) return App.go('login');
    const needPw = u.mustChangePassword; const needQ = u.mustSetupSecurity;
    let qs = [];
    if (needQ) qs = (await App.api.get('/auth/security-questions')).questions;
    root.innerHTML = hero(card('Finish Setup', needPw ? 'Replace the temporary password and choose a security question.' : 'Choose a security question so you can recover your account.', `
      <form data-form="setup" class="space-y-5">
        ${needPw ? field('New Password (at least 6 characters)', 'newPassword', 'password', 'required minlength="6" autocomplete="new-password"') + field('Confirm New Password', 'confirmPassword', 'password', 'required minlength="6" autocomplete="new-password"') : ''}
        ${needQ ? `<div><label class="${UI.label}" for="f_questionId">Security Question</label><select id="f_questionId" name="questionId" required class="${UI.input}"><option value="">Select a question</option>${qs.map((q) => `<option value="${q.id}">${esc(q.question)}</option>`).join('')}</select></div>
        ${field('Your Answer', 'answer', 'text', 'required autocomplete="off" maxlength="100"')}<p class="text-xs text-gray-500">Answers are not case-sensitive and are stored securely (hashed).</p>` : ''}
        ${submitBtn('Save and continue')}</form>
      <div class="mt-4 text-center">${btn('Sign out', 'logout', 'ghost')}</div>`));
  };
  App.forms.setup = async (f, d) => {
    await App.api.post('/auth/setup', { newPassword: d.newPassword, confirmPassword: d.confirmPassword, questionId: d.questionId, answer: d.answer });
    await loadMe(); App.toast('Account setup complete.', 'success'); enter();
  };

  // ----- several roles on one account: choose which one to act as -----
  const ROLE_HINT = { staff: 'Manage the clinic according to this role’s permissions', consultant: 'Your consultations, patients, prescriptions and availability', patient: 'Book and manage your consultations' };
  App.views.chooseRole = (root) => {
    const u = S.user; if (!u) return App.go('login');
    root.innerHTML = hero(card('Choose Your Role', `Welcome, ${u.fullName.split(' ')[0]}. You have more than one role — pick the one to sign in as.`, `
      <div class="space-y-3">${u.roles.map((r) => `<button type="button" data-action="pickRole" data-role="${r.id}" class="w-full text-left p-4 rounded-xl border-2 border-gray-200 hover:border-brand-teal hover:bg-brand-mist transition focus:outline-none focus:ring-2 focus:ring-brand-teal">
        <div class="font-display font-semibold tracking-wide text-brand-ink">${esc(r.name)}</div><div class="text-sm text-gray-600 mt-0.5">${esc(ROLE_HINT[r.portal] || '')}</div></button>`).join('')}</div>
      <p class="mt-5 text-xs text-gray-500 text-center">You act as one role at a time. You can switch later from the top of the page.</p>
      <div class="mt-4 text-center">${btn('Sign out', 'logout', 'ghost')}</div>`));
  };
  App.actions.pickRole = async (el) => {
    await App.api.post('/auth/select-role', { roleId: parseInt(el.dataset.role, 10) });
    await loadMe(); enter();
  };

  App.actions.home = () => App.go(S.user ? 'portal' : 'landing');
  App.actions.showLogin = () => App.go('login');
  App.actions.showRegister = () => App.go('register');
  App.actions.logout = async () => {
    try { await App.api.post('/auth/logout'); } catch (_) { /* ignore */ }
    App.stopPolling(); S.user = null; S.tab = null; S.portal = null; App.closeModal(); await App.api.get('/auth/me').catch(() => {}); App.go('landing');
  };
})(window.App);
