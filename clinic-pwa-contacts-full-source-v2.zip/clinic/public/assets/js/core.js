'use strict';
/* Core: state, API client, helpers, modal/toast, shell rendering, notifications. No inline handlers (strict CSP). */
window.App = { state: { user: null, csrf: null, app: {}, view: 'landing', tab: null, portal: null }, actions: {}, forms: {}, tabs: {} };
(function (App) {
  const S = App.state;

  // ---------- helpers ----------
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const UI = {
    input: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white',
    label: 'block text-sm font-semibold text-gray-700 mb-1.5',
    btn: 'inline-flex items-center justify-center gap-2 font-semibold rounded-lg px-4 py-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed',
    primary: 'bg-blue-600 hover:bg-blue-700 text-white shadow',
    success: 'bg-green-600 hover:bg-green-700 text-white shadow',
    danger: 'bg-red-600 hover:bg-red-700 text-white shadow',
    ghost: 'border border-gray-300 text-gray-700 hover:bg-gray-100',
    card: 'bg-white rounded-xl shadow-md border border-gray-100',
  };
  const btn = (label, action, kind = 'primary', attrs = '') => `<button type="button" data-action="${action}" ${attrs} class="${UI.btn} ${UI[kind]}">${label}</button>`;
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const STATUS = {
    requested: ['Awaiting payment check', 'bg-yellow-100 text-yellow-800'],
    confirmed: ['Confirmed', 'bg-green-100 text-green-800'],
    reschedule_requested: ['Reschedule requested', 'bg-purple-100 text-purple-800'],
    completed: ['Completed', 'bg-blue-100 text-blue-800'],
    cancelled: ['Cancelled', 'bg-gray-200 text-gray-700'],
    missed: ['Not consulted', 'bg-red-100 text-red-800'],
    rejected: ['Payment rejected', 'bg-red-100 text-red-800'],
  };
  const statusLabel = (st) => (STATUS[st] ? STATUS[st][0] : String(st).replace(/_/g, ' '));
  // current clinic-local time as 'YYYY-MM-DD HH:MM:SS' (to decide whether a consultation has started / ended)
  const nowStr = () => new Date().toLocaleString('sv-SE', { timeZone: S.app.timezone || 'Africa/Lagos' });
  const hasStarted = (b) => `${b.date} ${b.startTime}:00` <= nowStr();
  const hasEnded = (b) => `${b.date} ${b.endTime}:00` <= nowStr();
  const badge = (st) => { const [t, c] = STATUS[st] || [st, 'bg-gray-100 text-gray-700']; return `<span class="inline-block px-2.5 py-1 rounded-full text-xs font-bold ${c}">${esc(t)}</span>`; };
  const money = (n) => '₦' + Number(n).toLocaleString('en-NG', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const fmtDate = (d) => (d ? new Date(d + 'T00:00:00Z').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }) : '');
  const fmtTime = (t) => { if (!t) return ''; const [h, m] = t.split(':'); const hr = parseInt(h, 10); return `${((hr + 11) % 12) + 1}:${m} ${hr < 12 ? 'AM' : 'PM'}`; };
  const fmtDT = (iso) => (iso ? new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: S.app.timezone || 'Africa/Lagos' }) : '');
  const ago = (iso) => { const s = (Date.now() - new Date(iso).getTime()) / 1000; if (s < 60) return 'just now'; if (s < 3600) return `${Math.floor(s / 60)} min ago`; if (s < 86400) return `${Math.floor(s / 3600)} h ago`; return fmtDT(iso); };
  const empty = (msg) => `<div class="text-center text-gray-500 py-10 bg-white rounded-xl border border-dashed border-gray-300">${esc(msg)}</div>`;
  const spinner = '<div class="text-center text-gray-500 py-10">Loading…</div>';
  const today = () => new Date().toLocaleDateString('en-CA', { timeZone: S.app.timezone || 'Africa/Lagos' });
  Object.assign(App, { statusLabel, nowStr, hasStarted, hasEnded, esc, $, $$, UI, btn, DAYS, badge, money, fmtDate, fmtTime, fmtDT, ago, empty, spinner, today });

  // ---------- API ----------
  async function api(method, path, body, retried) {
    const opts = { method, headers: { 'X-CSRF-Token': S.csrf || '' }, credentials: 'same-origin' };
    if (body instanceof FormData) opts.body = body;
    else if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    let res;
    try { res = await fetch('/api' + path, opts); } catch (_) { throw new Error('Cannot reach the server. Please check your connection.'); }
    let data = {};
    try { data = await res.json(); } catch (_) { /* non-JSON */ }
    if (data.csrfToken) S.csrf = data.csrfToken;
    if (!res.ok) {
      if (res.status === 403 && data.code === 'CSRF' && !retried) { // stale token: fetch a fresh one and retry once, silently
        const me = await fetch('/api/auth/me', { credentials: 'same-origin' }).then((r) => r.json()).catch(() => ({}));
        if (me.csrfToken) { S.csrf = me.csrfToken; return api(method, path, body, true); }
      }
      if (res.status === 401 && !path.startsWith('/auth/')) { S.user = null; go('login'); toast('Your session has ended. Please sign in again.', 'error'); }
      else if (res.status === 403 && data.code === 'SETUP_REQUIRED') { go('setup'); }
      else if (res.status === 403 && data.code === 'ROLE_REQUIRED') { go('chooseRole'); }
      const err = new Error(data.error || 'Something went wrong. Please try again.'); err.status = res.status; throw err;
    }
    return data;
  }
  App.api = { get: (p) => api('GET', p), post: (p, b) => api('POST', p, b || {}), put: (p, b) => api('PUT', p, b || {}), patch: (p, b) => api('PATCH', p, b || {}), del: (p) => api('DELETE', p), form: (p, fd) => api('POST', p, fd) };

  // ---------- toast / modal ----------
  function toast(msg, type = 'info') {
    const c = { info: 'bg-gray-900', success: 'bg-green-600', error: 'bg-red-600' }[type] || 'bg-gray-900';
    const el = document.createElement('div');
    el.className = `${c} text-white text-sm font-medium rounded-lg shadow-lg px-4 py-3`; el.textContent = msg; el.setAttribute('role', type === 'error' ? 'alert' : 'status');
    $('#toasts').appendChild(el); setTimeout(() => el.remove(), type === 'error' ? 7000 : 4000);
  }
  function openModal(title, html, { wide = false } = {}) {
    closeModal();
    $('#modalRoot').innerHTML = `<div class="modal active" id="activeModal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-content ${wide ? 'wide' : ''}">
      <div class="p-5 border-b border-gray-200 flex justify-between items-center sticky top-0 bg-white rounded-t-2xl z-10"><h2 class="text-xl font-bold text-gray-900">${esc(title)}</h2>
      <button type="button" data-action="closeModal" class="text-gray-400 hover:text-gray-600 text-3xl font-bold leading-none" aria-label="Close">&times;</button></div>
      <div class="p-5" id="modalBody">${html}</div></div></div>`;
    document.body.style.overflow = 'hidden';
    return $('#modalBody');
  }
  function closeModal() { $('#modalRoot').innerHTML = ''; document.body.style.overflow = ''; }
  Object.assign(App, { toast, openModal, closeModal });
  App.actions.closeModal = () => closeModal();   // the × button on every dialog
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && $('#activeModal')) closeModal(); });
  document.addEventListener('click', (e) => { if (e.target.id === 'activeModal') closeModal(); });

  // ---------- event delegation ----------
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-action]');
    if (!el) { const dd = $('#notifDropdown'); if (dd && !e.target.closest('#notifWrap')) dd.classList.remove('active'); return; }
    const fn = App.actions[el.dataset.action];
    if (fn) { e.preventDefault(); (async () => fn(el, e))().catch((err) => toast(err.message, 'error')); }
  });
  document.addEventListener('submit', (e) => {
    const f = e.target.closest('form[data-form]'); if (!f) return;
    e.preventDefault();
    const fn = App.forms[f.dataset.form]; if (!fn) return;
    const submit = f.querySelector('[type=submit]'); if (submit) submit.disabled = true;
    (async () => fn(f, Object.fromEntries(new FormData(f))))().catch((err) => toast(err.message, 'error')).finally(() => { if (submit) submit.disabled = false; });
  });
  document.addEventListener('change', (e) => { const el = e.target.closest('[data-change]'); if (el && App.actions[el.dataset.change]) (async () => App.actions[el.dataset.change](el, e))().catch((err) => toast(err.message, 'error')); });

  // ---------- navigation / shell ----------
  function go(view, tab) { S.view = view; if (tab) S.tab = tab; render(); window.scrollTo(0, 0); }
  App.go = go;

  const logo = `<img src="./assets/images/logo-transparent.png" alt="The Clinic — Diabetes, Endocrine and Metabolic Care" class="logo-wide">`;
  function renderHeader() {
    const h = $('#appHeader');
    if (S.user && S.view === 'portal') {
      const u = S.user;
      h.innerHTML = `<nav class="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex flex-wrap sm:flex-nowrap justify-between items-center gap-2 py-2">
        <div class="flex items-center gap-3">${logo}<div class="hidden md:flex flex-col border-l border-brand-gold/50 pl-3"><span class="text-[10px] text-gray-500 uppercase tracking-widest">Signed in as</span><span class="text-sm font-semibold text-brand-ink">${esc(u.roleName)}</span></div></div>
        <div class="flex items-center justify-end flex-wrap gap-2 sm:gap-3 min-w-0">
          ${u.roles.length > 1 ? `<div class="flex items-center gap-2 max-w-full min-w-0"><span class="hidden lg:inline text-[10px] uppercase tracking-widest text-gray-500">Acting as</span><div class="flex max-w-[min(100%,75vw)] overflow-x-auto rounded-lg border border-gray-300" role="group" aria-label="Switch role">${u.roles.map((r) => `<button type="button" data-action="switchRole" data-role="${r.id}" aria-pressed="${u.role && r.id === u.role.id}" class="shrink-0 px-2 sm:px-3 py-2 text-xs sm:text-sm font-semibold ${u.role && r.id === u.role.id ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}">${esc(r.name)}</button>`).join('')}</div></div>` : ''}
          <div class="relative" id="notifWrap"><button type="button" data-action="toggleNotifs" class="relative p-2 rounded-lg hover:bg-gray-100" aria-label="Notifications">
            <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.4-1.4A2 2 0 0118 14.2V11a6 6 0 10-12 0v3.2a2 2 0 01-.6 1.4L4 17h5m6 0a3 3 0 11-6 0"/></svg>
            <span id="notifBadge" class="hidden absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full min-w-[20px] h-5 px-1 flex items-center justify-center"></span></button>
            <div id="notifDropdown" class="notification-dropdown"></div></div>
          <div class="hidden md:block text-right leading-tight"><div class="text-sm font-bold text-gray-900">${esc(u.fullName)}</div><div class="text-xs text-gray-500">${esc(u.email || u.phone)}</div></div>
          ${btn('Logout', 'logout', 'ghost', 'aria-label="Log out"')}
        </div></div></div></nav>`;
    } else {
      h.innerHTML = `<nav class="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex flex-wrap sm:flex-nowrap justify-between items-center gap-2 py-2">
        <button type="button" data-action="home" class="flex items-center text-left" aria-label="The Clinic home">${logo}</button>
        ${S.user ? '' : `<div class="flex items-center gap-2"><a class="hidden sm:inline font-semibold text-sm text-brand-teal mr-2" href="tel:+2349099009988" aria-label="Call The Clinic at 09099009988">09099009988</a>${btn('Login', 'showLogin', 'ghost')}${btn('Register', 'showRegister', 'primary')}</div>`}</div></div></nav>`;
    }
  }

  function render() {
    renderHeader();
    const v = App.views[S.view] || App.views.landing;
    v($('#view'));
  }
  App.render = render;

  // ---------- portal shell with tabs ----------
  App.views = App.views || {};
  App.views.portal = function (root) {
    const u = S.user;
    if (u.needRole) return go('chooseRole');
    S.portal = u.portal;
    const defs = (App.tabs[S.portal] || []).filter((t) => !t.perm || t.perm.some((p) => u.permissions.includes(p)));
    if (!defs.length) { root.innerHTML = '<div class="p-10 text-center text-gray-600">Your role does not have any portal sections yet. Please contact the clinic owner.</div>'; return; }
    if (!defs.find((t) => t.id === S.tab)) S.tab = defs[0].id;
    root.innerHTML = `<div class="max-w-7xl mx-auto min-w-0 px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
      <div class="flex flex-wrap items-center justify-between gap-3 mb-4"><div><h1 class="text-2xl md:text-3xl font-extrabold text-gray-900">Welcome, ${esc(u.fullName.split(' ')[0])}</h1><p class="text-gray-600 text-sm" id="portalSub"></p></div><div id="portalActions"></div></div>
      <div class="tabbar border-b border-gray-200 mb-6" role="tablist">${defs.map((t) => `<button type="button" role="tab" data-action="tab" data-tab="${t.id}" aria-selected="${t.id === S.tab}" class="whitespace-nowrap px-4 py-3 font-semibold border-b-2 ${t.id === S.tab ? 'border-blue-600 text-blue-700' : 'border-transparent text-gray-600 hover:text-gray-900'}">${esc(t.label)}</button>`).join('')}</div>
      <div id="tabContent" class="min-w-0">${spinner}</div></div>`;
    const sub = App.portalSubtitle && App.portalSubtitle(u, S.portal); if (sub) $('#portalSub').textContent = sub;
    if (App.portalActions) $('#portalActions').innerHTML = App.portalActions(u, S.portal) || '';
    const tab = defs.find((t) => t.id === S.tab);
    const activeBtn = $('[role=tab][aria-selected=true]'); if (activeBtn && activeBtn.scrollIntoView) activeBtn.scrollIntoView({ inline: 'center', block: 'nearest' });   // keep the current tab visible on small screens
    Promise.resolve(tab.render($('#tabContent'))).catch((e) => { $('#tabContent').innerHTML = `<div class="p-6 bg-red-50 text-red-700 rounded-lg">${esc(e.message)}</div>`; });
    refreshNotifs();
  };
  App.reloadTab = () => { const t = (App.tabs[S.portal] || []).find((x) => x.id === S.tab); const el = $('#tabContent'); if (t && el) return Promise.resolve(t.render(el)).catch((e) => { el.innerHTML = `<div class="p-6 bg-red-50 text-red-700 rounded-lg">${esc(e.message)}</div>`; }); };
  App.actions.tab = (el) => { S.tab = el.dataset.tab; render(); };
  App.actions.switchRole = async (el) => {
    const id = parseInt(el.dataset.role, 10); if (S.user.role && S.user.role.id === id) return;
    await App.api.post('/auth/select-role', { roleId: id });
    closeModal(); await App.loadMe(); S.tab = null; S.portal = S.user.portal; App.render(); App.toast(`You are now acting as ${S.user.roleName}.`, 'success');
  };

  // ---------- notifications ----------
  let notifTimer = null;
  async function refreshNotifs(list) {
    if (!S.user || S.view !== 'portal') return;
    try {
      const d = await App.api.get('/notifications'); S.notifs = d;
      const b = $('#notifBadge'); if (b) { b.textContent = d.unread > 99 ? '99+' : d.unread; b.classList.toggle('hidden', !d.unread); }
      const dd = $('#notifDropdown'); if (dd) renderNotifs(dd, d);
    } catch (_) { /* ignore polling errors */ }
    if (!notifTimer) notifTimer = setInterval(() => refreshNotifs(), 60000);
  }
  const selectedNotifs = new Set();
  function renderNotifs(dd, d) {
    const notes = d.notifications || [];
    const ids = new Set(notes.map((n) => Number(n.id)));
    for (const id of selectedNotifs) if (!ids.has(id)) selectedNotifs.delete(id);
    dd.innerHTML = `<div class="p-3 border-b border-gray-200 sticky top-0 bg-white z-10">
      <div class="flex flex-wrap items-center justify-between gap-2"><h3 class="font-bold text-gray-900">Notifications</h3><div class="flex flex-wrap gap-1">
      ${d.unread ? btn('Mark all read', 'readAllNotifs', 'ghost') : ''}
      ${notes.length ? btn('Clear all', 'clearAllNotifs', 'danger') : ''}</div></div>
      ${notes.length ? `<div class="flex items-center justify-between gap-2 mt-2 text-sm">
        <label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" data-change="selectAllNotifs" ${notes.every((n) => selectedNotifs.has(Number(n.id))) ? 'checked' : ''} aria-label="Select all displayed notifications"> Select all</label>
        <button type="button" data-action="clearSelectedNotifs" ${selectedNotifs.size ? '' : 'disabled'} class="rounded-lg px-3 py-2 bg-red-50 text-red-700 font-semibold disabled:opacity-40">Clear selected (${selectedNotifs.size})</button>
      </div>` : ''}</div>` +
      (notes.length ? `<div class="divide-y divide-gray-100">${notes.map((n) => `<div class="flex items-start gap-2 p-3 ${n.read ? '' : 'bg-blue-50'}">
        <input type="checkbox" data-change="selectNotif" data-id="${n.id}" ${selectedNotifs.has(Number(n.id)) ? 'checked' : ''} aria-label="Select notification: ${esc(n.title)}" class="mt-3 shrink-0">
        <button type="button" data-action="openNotif" data-id="${n.id}" data-booking="${n.bookingId || ''}" class="flex-1 min-w-0 text-left hover:underline">
          <div class="flex flex-wrap justify-between gap-2"><span class="font-semibold text-sm text-gray-900">${esc(n.title)}</span><span class="text-xs text-gray-500">${esc(ago(n.createdAt))}</span></div>
          <p class="text-sm text-gray-600 mt-1 break-words">${esc(n.message)}</p></button>
        <button type="button" data-action="clearOneNotif" data-id="${n.id}" aria-label="Clear notification: ${esc(n.title)}" title="Clear notification" class="shrink-0 rounded-md p-2 text-red-700 hover:bg-red-100 text-sm font-bold">✕</button>
      </div>`).join('')}</div>` : '<p class="p-6 text-center text-gray-500 text-sm">No notifications yet.</p>');
  }
  function redrawNotifs() { const dd = $('#notifDropdown'); if (dd && S.notifs) renderNotifs(dd, S.notifs); }
  App.actions.selectNotif = (el) => { const id = Number(el.dataset.id); if (el.checked) selectedNotifs.add(id); else selectedNotifs.delete(id); redrawNotifs(); };
  App.actions.selectAllNotifs = (el) => { for (const n of (S.notifs?.notifications || [])) { if (el.checked) selectedNotifs.add(Number(n.id)); else selectedNotifs.delete(Number(n.id)); } redrawNotifs(); };
  App.actions.clearOneNotif = async (el) => {
    const id = Number(el.dataset.id);
    if (!Number.isSafeInteger(id) || id < 1) return;
    await App.api.post('/notifications/clear-selected', { ids: [id] });
    selectedNotifs.delete(id); await refreshNotifs(); toast('Notification cleared.');
  };
  App.actions.clearSelectedNotifs = async () => {
    const ids = [...selectedNotifs]; if (!ids.length) return;
    await App.api.post('/notifications/clear-selected', { ids });
    selectedNotifs.clear(); await refreshNotifs(); toast(`${ids.length} notification(s) cleared.`);
  };
  App.actions.clearAllNotifs = async () => {
    if (!window.confirm('Clear all your notifications? This cannot be undone.')) return;
    await App.api.del('/notifications/clear-all');
    selectedNotifs.clear(); await refreshNotifs(); toast('All notifications cleared.');
  };
  App.actions.toggleNotifs = () => { const dd = $('#notifDropdown'); dd.classList.toggle('active'); if (dd.classList.contains('active') && S.notifs) renderNotifs(dd, S.notifs); };
  App.actions.readAllNotifs = async () => { await App.api.post('/notifications/read-all'); await refreshNotifs(); };
  App.actions.openNotif = async (el) => {
    await App.api.post(`/notifications/${el.dataset.id}/read`).catch(() => {}); refreshNotifs();
    $('#notifDropdown').classList.remove('active');
    if (el.dataset.booking && App.openBooking) App.openBooking(parseInt(el.dataset.booking, 10));
  };
  App.refreshNotifs = refreshNotifs;
  App.stopPolling = () => { clearInterval(notifTimer); notifTimer = null; S.notifs = null; selectedNotifs.clear(); };
})(window.App);
