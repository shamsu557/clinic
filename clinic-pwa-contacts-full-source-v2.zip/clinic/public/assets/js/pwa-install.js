/* Native Android install when available; manual iOS / Android instructions otherwise.
 * A dismissal lasts only for this page load: the invite returns on a later visit.
 * No app/installation state or patient data is stored in localStorage. */
'use strict';
(function () {
  const root = document.getElementById('pwaInstallRoot');
  if (!root) return;
  const ua = navigator.userAgent || '';
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const isPhone = isIOS || isAndroid;
  const standalone = () => window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  let deferredPrompt = null;
  let dismissed = false;
  let showManual = false;
  let shown = false;
  let installed = standalone();

  function dismiss() {
    dismissed = true;
    root.replaceChildren();
  }
  function manualSteps() {
    if (isIOS) {
      return '<ol class="pwa-steps"><li>Open this page in <strong>Safari</strong> (recommended).</li>' +
        '<li>Tap <strong>Share</strong> (the square with an up arrow). If it is hidden, use the page menu, then Share.</li>' +
        '<li>Scroll to <strong>Add to Home Screen</strong>.</li>' +
        '<li>Turn on <strong>Open as Web App</strong> if shown, then tap <strong>Add</strong>.</li></ol>';
    }
    return '<ol class="pwa-steps"><li>Open this page in <strong>Chrome</strong> on Android.</li>' +
      '<li>Tap the browser menu (<strong>⋮</strong>).</li>' +
      '<li>Choose <strong>Install app</strong> or <strong>Add to Home screen</strong>, then confirm.</li></ol>';
  }
  function render() {
    if (!isPhone || dismissed || installed || standalone()) return;
    shown = true;
    const title = isIOS ? 'Add The Clinic to your iPhone' : 'Install The Clinic on your Android phone';
    const subtitle = isIOS ? 'Save The Clinic to your Home Screen and open it like an app.' : 'Get quick access to appointments and the clinic portal from your Home Screen.';
    const primary = isIOS ? 'Got it' : (showManual ? 'Got it' : 'Install app');
    root.innerHTML = '<section class="pwa-install" role="region" aria-label="Install The Clinic app">' +
      '<div class="pwa-install-header"><img class="pwa-install-icon" src="/assets/icons/icon-192.png" alt="The Clinic icon">' +
      '<div class="pwa-install-info"><h2 class="pwa-install-title">' + title + '</h2><p class="pwa-install-subtitle">' + subtitle + '</p></div>' +
      '<button type="button" class="pwa-install-close" data-pwa="close" aria-label="Dismiss install guide">&times;</button></div>' +
      ((isIOS || showManual) ? manualSteps() : '') +
      '<div class="pwa-install-buttons">' +
      (isIOS ? '' : '<button type="button" class="pwa-btn pwa-btn-secondary" data-pwa="later">Not now</button>') +
      '<button type="button" class="pwa-btn pwa-btn-primary" data-pwa="install">' + primary + '</button></div>' +
      (isIOS ? '<p class="pwa-install-note">Your iPhone requires the Share menu; websites cannot trigger the iOS installer directly.</p>' : '') +
      '</section>';
  }

  root.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-pwa]');
    if (!button) return;
    if (button.dataset.pwa === 'close' || button.dataset.pwa === 'later' || isIOS || showManual) return dismiss();
    if (deferredPrompt) {
      const prompt = deferredPrompt;
      deferredPrompt = null;
      try {
        // Must be called directly from a user's click to satisfy browser policy.
        await prompt.prompt();
        const choice = await prompt.userChoice;
        if (choice && choice.outcome === 'accepted') { dismiss(); return; }
      } catch (_) { /* Browser may refuse to show it. Offer normal menu instructions. */ }
      // Browser controls repeat timing for native prompts; our own reminder returns next visit.
      dismiss();
    } else {
      showManual = true;
      render();
    }
  });

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    if (!shown && !dismissed && !installed) render();
  });
  window.addEventListener('appinstalled', () => { installed = true; deferredPrompt = null; dismiss(); });
  if (window.matchMedia) {
    const media = window.matchMedia('(display-mode: standalone)');
    if (media.addEventListener) media.addEventListener('change', () => { if (standalone()) { installed = true; dismiss(); } });
  }
  if (isPhone && !installed) window.setTimeout(render, 1600);
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => { /* normal website remains usable */ }); });
  }
})();
