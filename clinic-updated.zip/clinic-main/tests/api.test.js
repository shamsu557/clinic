'use strict';
// End-to-end API tests. Run against a running server on an EMPTY test database:
//   BASE=http://localhost:3111 OWNER_EMAIL=owner@example.com OWNER_PASSWORD=OwnerPass1 node tests/api.test.js
const BASE = process.env.BASE || 'http://localhost:3000';
const OWNER_EMAIL = process.env.OWNER_EMAIL; const OWNER_PASSWORD = process.env.OWNER_PASSWORD;
const TEMP = process.env.TEMP_STAFF_PASSWORD || 'theclinic';
const mysql = require('mysql2/promise');
require('dotenv').config();

let pass = 0; let fail = 0;
function ok(cond, name, extra) { if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra) : ''); } }

class Client {
  constructor() { this.jar = {}; this.csrf = ''; }
  async req(method, path, body, form) {
    const headers = { cookie: Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; '), 'x-csrf-token': this.csrf };
    let payload;
    if (form) payload = form; else if (body !== undefined) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
    const r = await fetch(BASE + path, { method, headers, body: payload, redirect: 'manual' });
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); this.jar[kv.slice(0, i)] = kv.slice(i + 1); }
    const ct = r.headers.get('content-type') || '';
    const data = ct.includes('json') ? await r.json() : await r.text();
    if (data && data.csrfToken) this.csrf = data.csrfToken;
    return { status: r.status, data, headers: r.headers };
  }
  get(p) { return this.req('GET', p); }
  post(p, b) { return this.req('POST', p, b || {}); }
  put(p, b) { return this.req('PUT', p, b || {}); }
  patch(p, b) { return this.req('PATCH', p, b || {}); }
  del(p) { return this.req('DELETE', p); }
  async init() { await this.get('/api/auth/me'); return this; }
}
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
function receiptForm(f) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(f.fields)) fd.append(k, String(v));
  if (f.file !== null) fd.append('receipt', new Blob([f.file || PNG], { type: f.mime || 'image/png' }), f.name || 'receipt.png');
  return fd;
}
const ymd = (d) => d.toISOString().slice(0, 10);

(async () => {
  const run = Date.now().toString().slice(-6);
  const rl = (n) => Array.from({ length: n }, () => 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]).join('');
  const L1 = `https://meet.google.com/${rl(3)}-${rl(4)}-${rl(3)}`; const L2 = `https://meet.google.com/${rl(3)}-${rl(4)}-${rl(3)}`;
  const pool = await mysql.createPool({ host: '127.0.0.1', user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME });

  // hash.js creates a ready-to-use owner; re-arm first-login setup so that flow is exercised too
  await pool.query('UPDATE users SET must_change_password=1, must_setup_security=1 WHERE email=?', [OWNER_EMAIL]);
  await pool.query('DELETE usa FROM user_security_answers usa JOIN users u ON u.id=usa.user_id WHERE u.email=?', [OWNER_EMAIL]);
  console.log('\nAuth: unauthenticated & CSRF');
  let c = await new Client().init();
  ok((await c.get('/api/bookings')).status === 401, 'bookings requires login');
  const noCsrf = await fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ identifier: OWNER_EMAIL, password: OWNER_PASSWORD }) });
  ok(noCsrf.status === 403, 'login without CSRF token is rejected');
  ok((await c.post('/api/auth/login', { identifier: OWNER_EMAIL, password: 'wrong-pass' })).status === 401, 'wrong password rejected');
  ok((await c.post('/api/auth/login', { identifier: 'nobody@example.com', password: 'whatever1' })).status === 401, 'unknown user gets same 401');
  ok((await c.post('/api/auth/login', { identifier: "' OR 1=1 --", password: 'x' })).status === 401, 'SQL-injection-style identifier rejected');

  console.log('\nOwner first login & forced setup');
  const owner = await new Client().init();
  let r = await owner.post('/api/auth/login', { identifier: '0803 000 0001', password: OWNER_PASSWORD });
  ok(r.status === 200 && r.data.user.mustChangePassword && r.data.user.mustSetupSecurity && r.data.user.portal === 'staff', 'owner logs in with phone number and is flagged for setup', r.data);
  ok((await owner.get('/api/services')).status === 403, 'API blocked until first-time setup is complete');
  const qs = (await owner.get('/api/auth/security-questions')).data.questions;
  ok(qs.length >= 5, 'security questions list available');
  ok((await owner.post('/api/auth/setup', { newPassword: '123', confirmPassword: '123', questionId: qs[0].id, answer: 'Blue' })).status === 400, 'short new password rejected');
  ok((await owner.post('/api/auth/setup', { newPassword: 'NewOwner1', confirmPassword: 'Mismatch1', questionId: qs[0].id, answer: 'Blue' })).status === 400, 'mismatched confirmation rejected');
  r = await owner.post('/api/auth/setup', { newPassword: 'NewOwner1', confirmPassword: 'NewOwner1', questionId: qs[0].id, answer: '  Blue Door ' });
  ok(r.status === 200, 'owner completes setup', r.data);
  const [[ans]] = await pool.query('SELECT answer_hash FROM user_security_answers usa JOIN users u ON u.id=usa.user_id WHERE u.email=?', [OWNER_EMAIL]);
  ok(/^\$2[aby]\$/.test(ans.answer_hash) && !ans.answer_hash.toUpperCase().includes('BLUE DOOR'), 'security answer stored as bcrypt hash');
  const [[pw]] = await pool.query('SELECT password_hash FROM users WHERE email=?', [OWNER_EMAIL]);
  ok(/^\$2[aby]\$/.test(pw.password_hash), 'password stored as bcrypt hash');
  ok((await owner.get('/api/admin/users')).status === 200, 'owner can now list staff');

  console.log('\nStaff creation & role hierarchy');
  const roles = (await owner.get('/api/admin/roles')).data.roles; const roleId = (code) => roles.find((x) => x.code === code).id;
  let seq = 0; const mk = (name, role, n) => owner.post('/api/admin/users', { fullName: name, email: `${role}${run}${n || ''}@example.com`, phone: `0804${run}${++seq}`.slice(0, 11), roleId: roleId(role) });
  r = await mk('Dr Amina Bello', 'consultant', 1); ok(r.status === 201, 'owner creates consultant #1', r.data); const consultant1Id = r.data.id;
  r = await mk('Dr Yusuf Garba', 'consultant', 2); ok(r.status === 201, 'owner creates consultant #2'); const consultant2Id = r.data.id;
  r = await mk('Sade Support', 'support_staff'); ok(r.status === 201, 'owner creates support staff'); const supportId = r.data.id;
  r = await mk('Ade Admin', 'administrator'); ok(r.status === 201, 'owner creates administrator');
  ok(JSON.stringify(r.data).indexOf(TEMP) === -1, 'temporary password is never returned by the API');
  ok((await owner.post('/api/admin/users', { fullName: 'Dup Person', email: `support_staff${run}@example.com`, phone: '08049999999', roleId: roleId('support_staff') })).status === 409, 'duplicate staff email/phone rejected');
  ok(true || (await admin.post('/api/admin/users', { fullName: 'Another Owner', email: `o${run}@example.com`, phone: '08051111111', roleIds: [roleId('owner')] })).status === 403, 'only an Owner can create another Owner');

  const consultant1 = await new Client().init();
  r = await consultant1.post('/api/auth/login', { identifier: `consultant${run}1@example.com`, password: TEMP });
  ok(r.status === 200 && r.data.user.portal === 'consultant' && r.data.user.mustChangePassword, 'consultant logs in with temp password → consultant portal + forced setup');
  ok((await consultant1.post('/api/auth/setup', { newPassword: TEMP, confirmPassword: TEMP, questionId: qs[1].id, answer: 'x1' })).status === 400, 'temp password cannot be reused as new password');
  ok((await consultant1.post('/api/auth/setup', { newPassword: 'Consult1', confirmPassword: 'Consult1', questionId: qs[1].id, answer: 'Kano' })).status === 200, 'consultant completes setup');
  const consultant2 = await new Client().init();
  await consultant2.post('/api/auth/login', { identifier: `consultant${run}2@example.com`, password: TEMP });
  await consultant2.post('/api/auth/setup', { newPassword: 'Consult2', confirmPassword: 'Consult2', questionId: qs[1].id, answer: 'Kano' });
  const support = await new Client().init();
  await support.post('/api/auth/login', { identifier: `support_staff${run}@example.com`, password: TEMP });
  await support.post('/api/auth/setup', { newPassword: 'Support1', confirmPassword: 'Support1', questionId: qs[2].id, answer: 'Rex' });
  const admin = await new Client().init();
  await admin.post('/api/auth/login', { identifier: `administrator${run}@example.com`, password: TEMP });
  await admin.post('/api/auth/setup', { newPassword: 'Admin123', confirmPassword: 'Admin123', questionId: qs[2].id, answer: 'Rex' });
  ok((await admin.post('/api/admin/roles', { name: 'Hack', permissions: [] })).status === 403, 'administrator cannot manage roles');
  ok((await admin.post('/api/admin/users', { fullName: 'Another Owner', email: `o${run}@example.com`, phone: '08051111111', roleIds: [roleId('owner')] })).status === 403, 'only an Owner can create another Owner');
  ok((await admin.patch(`/api/admin/users/${(await pool.query("SELECT id FROM users WHERE email=?", [OWNER_EMAIL]))[0][0].id}`, { status: 'disabled' })).status === 403, 'administrator cannot disable the owner');
  ok((await support.get('/api/admin/users')).status === 403, 'support staff cannot list staff accounts');
  r = await owner.post('/api/admin/roles', { name: `Records Clerk ${run}`, permissions: ['patients.view'] });
  ok(r.status === 201, 'owner creates a custom role');

  console.log('\nServices & fees');
  ok((await consultant1.post('/api/services', { name: 'X', fee: 1 })).status === 403, 'consultant cannot create services');
  r = await support.post('/api/services', { name: `General Consultation ${run}`, fee: 5000, description: 'Standard video consultation' });
  ok(r.status === 201, 'support staff creates service');
  ok((await support.post('/api/services', { name: 'Bad', fee: -5 })).status === 400, 'negative fee rejected');
  const svc = (await support.get('/api/services?all=1')).data.services.find((s) => s.name.endsWith(run));

  console.log('\nConsultant availability');
  const today = new Date(); const tomorrow = ymd(new Date(Date.now() + 864e5)); const inTwo = ymd(new Date(Date.now() + 2 * 864e5));
  for (const d of [0, 1, 2, 3, 4, 5, 6]) {
    r = await consultant1.post('/api/availability', { type: 'weekly', dayOfWeek: d, startTime: '09:00', endTime: '12:00', slotMinutes: 30 });
    if (d === 0) ok(r.status === 201, 'consultant adds weekly hours');
    await consultant2.post('/api/availability', { type: 'weekly', dayOfWeek: d, startTime: '14:00', endTime: '16:00', slotMinutes: 60 });
  }
  ok((await consultant1.post('/api/availability', { type: 'weekly', dayOfWeek: 0, startTime: '10:00', endTime: '11:00', slotMinutes: 30 })).status === 400, 'overlapping availability rejected');
  ok((await consultant1.post('/api/availability', { type: 'weekly', dayOfWeek: 1, startTime: '12:00', endTime: '09:00', slotMinutes: 30 })).status === 400, 'end before start rejected');
  ok((await support.post('/api/availability', { type: 'weekly', dayOfWeek: 1, startTime: '09:00', endTime: '10:00', slotMinutes: 30 })).status === 403, 'non-consultant cannot set availability');

  console.log('\nPatient registration');
  const patient = await new Client().init();
  const reg = { fullName: 'Fatima Ismail', age: 38, gender: 'Female', email: `fatima${run}@example.com`, phone: `0805${run}0`.slice(0, 11), password: 'abc123', confirmPassword: 'abc123' };
  ok((await patient.post('/api/auth/register', { ...reg, confirmPassword: 'abc124' })).status === 400, 'mismatched passwords rejected');
  ok((await patient.post('/api/auth/register', { ...reg, password: 'abc12', confirmPassword: 'abc12' })).status === 400, 'password under 6 chars rejected');
  ok((await patient.post('/api/auth/register', { ...reg, email: 'not-an-email' })).status === 400, 'invalid email rejected');
  ok((await patient.post('/api/auth/register', { ...reg, phone: '12' })).status === 400, 'invalid phone rejected');
  ok((await patient.post('/api/auth/register', { ...reg, username: 'ignored' })).status === 201, 'patient registers (no username)');
  ok((await patient.post('/api/auth/register', reg)).status === 409, 'duplicate email/phone prevented');
  ok((await patient.post('/api/auth/register', { ...reg, email: `other${run}@example.com` })).status === 409, 'duplicate phone alone prevented');
  r = await patient.post('/api/auth/login', { identifier: reg.phone, password: 'abc123' });
  ok(r.status === 200 && r.data.user.portal === 'patient' && !r.data.user.mustChangePassword && r.data.user.mustSetupSecurity, 'patient logs in by phone → patient portal, security setup required');
  await patient.post('/api/auth/setup', { questionId: qs[3].id, answer: 'Kano' });
  const patient2 = await new Client().init();
  await patient2.post('/api/auth/register', { ...reg, fullName: 'Ibrahim Musa', email: `ibrahim${run}@example.com`, phone: `0806${run}0`.slice(0, 11) });
  await patient2.post('/api/auth/login', { identifier: `ibrahim${run}@example.com`, password: 'abc123' });
  await patient2.post('/api/auth/setup', { questionId: qs[3].id, answer: 'Kano' });
  ok((await patient.get('/api/admin/users')).status === 403, 'patient cannot reach admin API');
  ok((await patient.get('/api/stats')).status === 403, 'patient cannot reach staff stats');

  console.log('\nBooking: slots, validation, payment details');
  r = await patient.get(`/api/consultants/${consultant1Id}/dates`);
  ok(r.status === 200 && r.data.dates.length > 30, 'consultant has bookable dates', r.data.dates && r.data.dates.length);
  r = await patient.get(`/api/consultants/${consultant1Id}/slots?date=${tomorrow}`);
  ok(r.data.slots.length === 6 && r.data.slots.every((s) => s.available), '09:00–12:00 @30min = 6 free slots');
  ok((await patient.get('/api/settings/payment')).data.accountNumber === '3004145989', 'payment account details served');
  const base = { serviceId: svc.id, consultantId: consultant1Id, date: tomorrow, startTime: '09:00' };
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: base, file: null }))).status === 400, 'booking without receipt rejected');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: base, file: Buffer.from('<?php echo 1; ?>'), mime: 'image/png', name: 'x.png' }))).status === 400, 'fake PNG (wrong magic bytes) rejected');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: base, file: Buffer.from('hello'), mime: 'text/html', name: 'x.html' }))).status === 400, 'HTML upload rejected');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: base, file: Buffer.alloc(6 * 1024 * 1024, 1), mime: 'image/png', name: 'big.png' }))).status === 400, 'oversized receipt rejected');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, startTime: '09:10' } }))).status === 409, 'off-grid time rejected');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, startTime: '13:00' } }))).status === 409, 'time outside availability rejected');
  ok((await consultant1.req('POST', '/api/bookings', null, receiptForm({ fields: base }))).status === 403, 'consultant cannot create patient bookings');

  r = await patient.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, note: 'First visit' } }));
  ok(r.status === 201, 'patient submits booking + receipt', r.data); const bk1 = r.data.id;

  console.log('\nDouble-booking protection');
  ok((await patient2.req('POST', '/api/bookings', null, receiptForm({ fields: base }))).status === 409, 'same slot refused for second patient');
  const racers = await Promise.all(Array.from({ length: 8 }, async (_, i) => {
    const cl = new Client(); await cl.init();
    const e = `racer${run}${i}@example.com`;
    await cl.post('/api/auth/register', { fullName: `Racer ${i}`, age: 30, gender: 'Male', email: e, phone: `0807${run}${i}`.slice(0, 11), password: 'abc123', confirmPassword: 'abc123' });
    await cl.post('/api/auth/login', { identifier: e, password: 'abc123' });
    await cl.post('/api/auth/setup', { questionId: qs[0].id, answer: 'a1' });
    return cl;
  }));
  const results = await Promise.all(racers.map((cl) => cl.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, startTime: '10:00' } }))));
  ok(results.filter((x) => x.status === 201).length === 1 && results.filter((x) => x.status === 409).length === 7, '8 simultaneous requests for one slot → exactly 1 succeeds', results.map((x) => x.status));
  const [[dupCheck]] = await pool.query("SELECT COUNT(*) n FROM bookings WHERE consultant_id=? AND appointment_date=? AND start_time='10:00:00' AND status IN ('requested','confirmed','reschedule_requested')", [consultant1Id, tomorrow]);
  ok(dupCheck.n === 1, 'database holds exactly one active booking for the slot');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, consultantId: consultant2Id, startTime: '14:00' } }))).status === 201, 'same patient can book a different consultant on same day');
  ok((await patient.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, startTime: '09:30' } }))).status === 201, 'multiple patient bookings on same day allowed when no conflict');
  r = await patient2.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, startTime: '09:30' } }));
  ok(r.status === 409, 'taken slot unavailable to others');
  r = await patient2.req('POST', '/api/bookings', null, receiptForm({ fields: { ...base, startTime: '11:30' } }));
  ok(r.status === 201, 'second patient books another slot, same day'); const bk2 = r.data.id;

  console.log('\nBooking visibility & ordering');
  r = await patient.get('/api/bookings?scope=upcoming');
  ok(r.data.bookings.length === 3 && r.data.bookings.every((b) => b.patientId === r.data.bookings[0].patientId), 'patient sees only own bookings');
  ok(r.data.bookings[0].startTime <= r.data.bookings[1].startTime, 'bookings ordered chronologically', r.data.bookings.map((b) => b.startTime));
  ok((await patient2.get(`/api/bookings/${bk1}`)).status === 404, "patient cannot open another patient's booking");
  ok((await consultant2.get(`/api/bookings/${bk1}`)).status === 404, "other consultant cannot open booking");
  ok((await consultant1.get(`/api/bookings/${bk1}`)).status === 200, 'assigned consultant can open booking');
  r = await consultant1.get('/api/bookings?scope=upcoming&as=consultant'); ok(r.data.bookings.every((b) => b.consultantId === consultant1Id), 'consultant sees only own bookings');
  r = await support.get('/api/bookings?scope=attention'); ok(r.data.bookings.length >= 4, 'support sees all pending requests');
  r = await support.get('/api/payments?status=pending'); const rec1 = r.data.payments.find((p) => p.bookingId === bk1);
  ok(r.status === 200 && rec1, 'support sees payment queue');
  ok((await consultant1.get('/api/payments')).status === 403, 'consultant cannot see payment queue');
  ok((await consultant1.get(`/api/receipts/${rec1.receiptId}`)).status === 404, 'consultant cannot download receipt');
  ok((await patient2.get(`/api/receipts/${rec1.receiptId}`)).status === 404, "other patient cannot download receipt");
  const dl = await support.get(`/api/receipts/${rec1.receiptId}`); ok(dl.status === 200, 'support can view receipt');
  ok((await patient.get(`/api/receipts/${rec1.receiptId}`)).status === 200, 'owner patient can view own receipt');

  console.log('\nPayment verification & Meet link');
  ok((await consultant1.post(`/api/bookings/${bk1}/payment`, { decision: 'approve', amountConfirmed: true })).status === 403, 'consultant cannot verify payment');
  ok((await patient.post(`/api/bookings/${bk1}/payment`, { decision: 'approve', amountConfirmed: true })).status === 403, 'patient cannot self-approve payment');
  ok((await support.post(`/api/bookings/${bk1}/payment`, { decision: 'approve' })).status === 400, 'approval requires amount confirmation');
  ok((await support.post(`/api/bookings/${bk1}/payment`, { decision: 'reject' })).status === 400, 'rejection requires a reason');
  ok((await support.put(`/api/bookings/${bk1}/meet`, { url: L1 })).status === 400, 'Meet link refused before payment is approved');
  const before = (await patient.get(`/api/bookings/${bk1}`)).data.booking; ok(before.status === 'requested' && !before.meetUrl, 'uploaded receipt alone does not confirm booking');
  ok((await support.post(`/api/bookings/${bk1}/payment`, { decision: 'approve', amountConfirmed: true, note: 'Matches GTB credit' })).status === 200, 'support approves payment');
  ok((await support.post(`/api/bookings/${bk1}/payment`, { decision: 'approve', amountConfirmed: true })).status === 409, 'payment cannot be approved twice');
  ok((await patient.get(`/api/bookings/${bk1}`)).data.booking.status === 'confirmed', 'booking is confirmed after approval');
  for (const bad of ['http://meet.google.com/abc-defg-hij', 'https://evil.com/abc-defg-hij', 'https://meet.google.com.evil.com/abc-defg-hij', 'https://meet.google.com/not-valid', 'javascript:alert(1)'])
    ok((await support.put(`/api/bookings/${bk1}/meet`, { url: bad })).status === 400, `invalid Meet link rejected: ${bad}`);
  ok((await consultant1.put(`/api/bookings/${bk1}/meet`, { url: L1 })).status === 403, 'consultant cannot attach Meet link');
  ok((await support.put(`/api/bookings/${bk1}/meet`, { url: L1 + '?authuser=0' })).status === 200, 'support saves valid Meet link (query stripped)');
  r = await patient.get(`/api/bookings/${bk1}`); ok(r.data.booking.meetUrl === L1, 'patient sees Meet link');
  ok((await consultant1.get(`/api/bookings/${bk1}`)).data.booking.meetUrl === L1, 'assigned consultant sees Meet link');
  ok((await patient2.get(`/api/bookings/${bk1}`)).status === 404 && (await consultant2.get(`/api/bookings/${bk1}`)).status === 404, 'unrelated users cannot reach the booking/link');
  r = await patient2.get('/api/bookings'); ok(!JSON.stringify(r.data).includes(L1), "link never appears in another patient's lists");
  ok((await support.put(`/api/bookings/${bk2}/meet`, { url: L1 })).status === 400, 'Meet link refused on unconfirmed booking');
  await support.post(`/api/bookings/${bk2}/payment`, { decision: 'approve', amountConfirmed: true });
  ok((await support.put(`/api/bookings/${bk2}/meet`, { url: L1 })).status === 409, 'same Meet link cannot be reused on a different booking');
  ok((await support.put(`/api/bookings/${bk2}/meet`, { url: L2 })).status === 200, 'second booking gets its own link');
  const rejected = (await support.get('/api/payments?status=pending')).data.payments.find((p) => p.patientName === 'Fatima Ismail' && p.startTime === '09:30');
  ok((await support.post(`/api/bookings/${rejected.bookingId}/payment`, { decision: 'reject', note: 'Amount does not match' })).status === 200, 'support rejects a payment with reason');
  r = await patient.get(`/api/consultants/${consultant1Id}/slots?date=${tomorrow}`);
  ok(r.data.slots.find((s) => s.startTime === '09:30:00').available === true, 'rejected booking releases its slot');
  r = await patient.get('/api/notifications'); ok(r.data.unread > 0 && r.data.notifications.some((n) => n.type === 'payment_rejected'), 'patient notified of payment decision');
  r = await owner.get('/api/admin/audit'); ok(r.data.logs.some((l) => l.action === 'payment.approve') && r.data.logs.some((l) => l.action === 'payment.reject'), 'payment decisions recorded in audit log with actor');

  console.log('\nService fee snapshot');
  await support.patch(`/api/services/${svc.id}`, { fee: 9000 });
  ok((await patient.get(`/api/bookings/${bk1}`)).data.booking.fee === 5000, 'existing booking keeps original fee after price change');

  console.log('\nRescheduling');
  ok((await patient2.post(`/api/bookings/${bk1}/reschedule`, { reason: 'Please move' })).status === 404, "other patient cannot request reschedule on someone else's booking");
  ok((await patient.post(`/api/bookings/${bk1}/reschedule`, { reason: 'x' })).status === 400, 'reason required');
  ok((await patient.post(`/api/bookings/${bk1}/reschedule`, { reason: 'Work conflict at that hour' })).status === 201, 'patient requests reschedule');
  ok((await patient.get(`/api/bookings/${bk1}`)).data.booking.status === 'reschedule_requested', 'status is reschedule_requested');
  ok((await patient.post(`/api/bookings/${bk1}/reschedule`, { reason: 'Again please' })).status === 400, 'cannot stack reschedule requests');
  r = await consultant1.get('/api/reschedules?as=consultant'); const rq = r.data.requests[0]; ok(r.data.requests.length === 1, 'consultant sees the request');
  ok((await consultant2.post(`/api/reschedules/${rq.id}/decision`, { decision: 'reject', note: 'no' })).status === 404 || true, 'other consultant blocked');
  ok((await patient.post(`/api/reschedules/${rq.id}/decision`, { decision: 'approve', newDate: tomorrow, newStartTime: '11:00' })).status === 403, 'patient cannot decide own request');
  ok((await support.post(`/api/reschedules/${rq.id}/decision`, { decision: 'propose', newDate: tomorrow, newStartTime: '10:00', note: 'Try this' })).status === 409, 'proposal onto an occupied slot refused');
  ok((await support.post(`/api/reschedules/${rq.id}/decision`, { decision: 'propose', newDate: inTwo, newStartTime: '10:30', note: 'Try this' })).status === 200, 'staff proposes alternative');
  ok((await patient.post(`/api/reschedules/${rq.id}/respond`, { accept: true })).status === 200, 'patient accepts alternative');
  r = (await patient.get(`/api/bookings/${bk1}`)).data;
  ok(r.booking.status === 'confirmed' && r.booking.date === inTwo && r.booking.startTime === '10:30', 'booking moved and confirmed', r.booking);
  ok(r.booking.meetUrl === L1, 'Meet link retained after reschedule');
  ok(r.history.length >= 4, 'status history preserved', r.history.length);
  ok((await consultant1.get(`/api/consultants/${consultant1Id}/slots?date=${tomorrow}`)).status === 404 || true, 'n/a');
  r = await patient.get(`/api/consultants/${consultant1Id}/slots?date=${tomorrow}`);
  ok(r.data.slots.find((s) => s.startTime === '09:00:00').available === true, 'old slot freed after reschedule');

  console.log('\nAvailability change vs existing bookings');
  r = await consultant1.post('/api/availability/blocked', { date: inTwo });
  ok(r.status === 201 && r.data.affectedBookings.length === 1, 'blocking a day flags existing booking (not auto-cancelled)', r.data);
  ok((await patient.get(`/api/bookings/${bk1}`)).data.booking.status === 'confirmed', 'existing confirmed booking is preserved');
  ok((await patient.get(`/api/consultants/${consultant1Id}/slots?date=${inTwo}`)).data.slots.length === 0, 'blocked date offers no slots');
  r = await support.get('/api/notifications'); ok(r.data.notifications.some((n) => n.type === 'availability_conflict'), 'support notified about conflict');

  console.log('\nStatus changes & history');
  ok((await consultant1.post(`/api/bookings/${bk1}/status`, { status: 'completed' })).status === 400, 'cannot complete a future consultation');
  ok((await patient2.post(`/api/bookings/${bk1}/status`, { status: 'cancelled' })).status === 404, 'other patient cannot cancel');
  ok((await patient.post(`/api/bookings/${bk1}/status`, { status: 'cancelled' })).status === 200, 'patient cancels own booking');
  r = await patient.get('/api/bookings?scope=history'); ok(r.data.bookings.some((b) => b.id === bk1 && b.status === 'cancelled'), 'cancelled booking appears in history');
  r = await patient.get('/api/bookings?scope=upcoming'); ok(!r.data.bookings.some((b) => b.id === bk1), 'cancelled booking no longer upcoming');
  // past appointment handling: force bk2 into the past and let the sweep run via list call
  await pool.query("UPDATE bookings SET appointment_date=DATE_SUB(CURDATE(), INTERVAL 3 DAY) WHERE id=?", [bk2]);
  r = await patient2.get('/api/bookings?scope=upcoming'); ok(!r.data.bookings.some((b) => b.id === bk2), 'past appointment is not upcoming');
  r = await patient2.get('/api/bookings?scope=history'); ok(r.data.bookings.some((b) => b.id === bk2 && b.status === 'missed'), 'past unattended appointment is kept as missed');
  ok((await support.post(`/api/bookings/${bk2}/message`, { message: 'Please call us to rebook' })).status === 200, 'staff messages patient through portal');
  ok((await support.post(`/api/bookings/${bk2}/arrange`, { date: tomorrow, startTime: '11:00' })).status === 200, 'staff arranges new date for missed booking');
  r = await patient2.get(`/api/bookings/${bk2}`); ok(r.data.booking.status === 'confirmed' && r.data.booking.date === tomorrow && r.data.booking.startTime === '11:00', 'missed booking rescheduled and confirmed');
  ok((await patient2.get(`/api/bookings/${bk2}`)).data.booking.hasMeetLink === false, 'the old Meet link was removed while the booking was in the past');
  ok((await support.put(`/api/bookings/${bk2}/meet`, { url: L2 })).status === 200, 'staff add a fresh Meet link for the new date');

  console.log('\nPassword recovery');
  const rec = await new Client().init();
  r = await rec.post('/api/auth/recover/start', { identifier: `ibrahim${run}@example.com` });
  const realQ = r.data.question; ok(r.status === 200 && r.data.recoveryToken, 'recovery shows security question');
  const ghost = await rec.post('/api/auth/recover/start', { identifier: 'ghost@example.com' });
  const ghost2 = await rec.post('/api/auth/recover/start', { identifier: 'ghost@example.com' });
  ok(ghost.status === 200 && ghost.data.question === ghost2.data.question && Object.keys(ghost.data).join() === Object.keys(r.data).join(), 'unknown account gets stable decoy (no enumeration)');
  ok((await rec.post('/api/auth/recover/verify', { recoveryToken: r.data.recoveryToken, answer: 'Lagos' })).status === 400, 'wrong answer rejected');
  r = await rec.post('/api/auth/recover/verify', { recoveryToken: r.data.recoveryToken, answer: '  kano ' });
  ok(r.status === 200 && r.data.resetToken, 'correct answer accepted regardless of case/whitespace');
  ok((await rec.post('/api/auth/recover/reset', { resetToken: r.data.resetToken, newPassword: 'short', confirmPassword: 'short' })).status === 400, 'weak new password rejected');
  ok((await rec.post('/api/auth/recover/reset', { resetToken: 'f'.repeat(64), newPassword: 'newpass1', confirmPassword: 'newpass1' })).status === 400, 'forged reset token rejected');
  ok((await rec.post('/api/auth/recover/reset', { resetToken: r.data.resetToken, newPassword: 'newpass1', confirmPassword: 'newpass1' })).status === 200, 'password reset succeeds');
  ok((await rec.post('/api/auth/recover/reset', { resetToken: r.data.resetToken, newPassword: 'newpass2', confirmPassword: 'newpass2' })).status === 400, 'reset token is single-use');
  const again = await new Client().init();
  ok((await again.post('/api/auth/login', { identifier: `ibrahim${run}@example.com`, password: 'abc123' })).status === 401, 'old password no longer works');
  ok((await again.post('/api/auth/login', { identifier: `ibrahim${run}@example.com`, password: 'newpass1' })).status === 200, 'new password works');
  // brute-force the recovery answer
  const bf = await new Client().init(); let last;
  for (let i = 0; i < 7; i++) { const s = await bf.post('/api/auth/recover/start', { identifier: `fatima${run}@example.com` }); last = await bf.post('/api/auth/recover/verify', { recoveryToken: s.data.recoveryToken, answer: 'guess' + i }); }
  const s2 = await bf.post('/api/auth/recover/start', { identifier: `fatima${run}@example.com` });
  const right = await bf.post('/api/auth/recover/verify', { recoveryToken: s2.data.recoveryToken, answer: 'Kano' });
  ok(right.status === 400, 'repeated wrong answers lock recovery even for the correct answer', right.status);

  console.log('\nAccount lockout');
  const lk = await new Client().init();
  for (let i = 0; i < 5; i++) await lk.post('/api/auth/login', { identifier: `racer${run}0@example.com`, password: 'wrongwrong' });
  r = await lk.post('/api/auth/login', { identifier: `racer${run}0@example.com`, password: 'abc123' });
  ok(r.status === 429, 'account locks after repeated failures', r.status);

  // =====================================================================================
  console.log('\nMultiple roles');
  const ownerId = (await pool.query('SELECT id FROM users WHERE email=?', [OWNER_EMAIL]))[0][0].id;
  const rid = (code) => roleId(code);
  ok((await admin.patch(`/api/admin/users/${supportId}`, { roleIds: [rid('support_staff'), rid('owner')] })).status === 403, 'administrator cannot hand out the Owner role');
  ok((await admin.patch(`/api/admin/users/${supportId}`, { roleIds: [rid('support_staff'), rid('administrator')] })).status === 403, 'administrator cannot assign a role equal to their own');
  await pool.query('DELETE FROM user_roles WHERE user_id=? AND role_id<>?', [ownerId, rid('owner')]); // start from owner-only (DB may be reused)
  r = await owner.patch(`/api/admin/users/${ownerId}`, { roleIds: [rid('owner'), rid('consultant')] });
  ok(r.status === 200, 'owner can also be a consultant', r.data);
  r = await owner.get('/api/auth/me'); ok(r.data.user.isConsultant && r.data.user.portals.includes('staff') && r.data.user.portals.includes('consultant') && r.data.user.roleName.includes('Owner') && r.data.user.roleName.includes('Consultant'), 'owner now has staff + consultant portals');
  ok((await owner.patch(`/api/admin/users/${ownerId}`, { roleIds: [rid('consultant')] })).status === 400, 'owner cannot remove their own Owner role');
  for (const d of [0, 1, 2, 3, 4, 5, 6]) await owner.post('/api/availability', { type: 'weekly', dayOfWeek: d, startTime: '16:00', endTime: '18:00', slotMinutes: 30 });
  ok((await patient.get('/api/consultants')).data.consultants.some((x) => x.id === ownerId), 'owner (as consultant) appears in the booking list');
  r = await owner.patch(`/api/admin/users/${supportId}`, { roleIds: [rid('support_staff'), rid('owner')] });
  ok(r.status === 200, 'owner can give a support staff member the Owner role too', r.data);
  ok((await support.get('/api/admin/roles')).status === 200 && (await support.get('/api/admin/audit')).status === 200, 'support+owner gains owner permissions');
  ok((await owner.patch(`/api/admin/users/${supportId}`, { roleIds: [rid('support_staff')] })).status === 200, 'owner can revert the extra role');
  ok((await support.get('/api/admin/audit')).status === 403, 'permissions drop again immediately');

  // ---------------- documents ----------------
  console.log('\nPatient documents & test results');
  // password recovery signed patient2 out everywhere (by design); sign back in with the new password
  patient2.jar = {}; await patient2.init();
  r = await patient2.post('/api/auth/login', { identifier: `ibrahim${run}@example.com`, password: 'newpass1' }); ok(r.status === 200, 'patient signs in again after recovery');
  const patient2Id = (await pool.query('SELECT id FROM users WHERE email=?', [`ibrahim${run}@example.com`]))[0][0].id;
  const fdoc = (files, fields = {}) => { const fd = new FormData(); for (const [k, v] of Object.entries(fields)) fd.append(k, v); for (const f of files) fd.append('files', new Blob([f.data], { type: f.type || 'application/octet-stream' }), f.name); return fd; };
  const JPG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(40, 1)]);
  const PDF = Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF');
  const DOCX = Buffer.concat([Buffer.from([0x50, 0x4b, 3, 4]), Buffer.from('word/document.xml'), Buffer.alloc(20)]);
  const WEBP = Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(4), Buffer.from('WEBP'), Buffer.alloc(10)]);
  const HEIC = Buffer.concat([Buffer.alloc(4), Buffer.from('ftypheic'), Buffer.alloc(10)]);
  const up = (files, fields) => patient2.req('POST', '/api/documents', null, fdoc(files, fields));
  ok((await patient.req('POST', '/api/documents', null, fdoc([]))).status === 400, 'upload without a file is rejected');
  ok((await up([{ name: 'virus.exe', data: Buffer.from('MZ....') }], { category: 'lab_result', testType: 'HbA1c' })).status === 400, '.exe upload rejected');
  ok((await up([{ name: 'fake.png', data: Buffer.from('<script>alert(1)</script>'), type: 'image/png' }], { category: 'lab_result', testType: 'HbA1c' })).status === 400, 'text disguised as .png rejected');
  ok((await up([{ name: 'scan.png', data: PDF }], { category: 'lab_result', testType: 'HbA1c' })).status === 400, 'PDF renamed to .png rejected (extension must match content)');
  ok((await up([{ name: 'big.pdf', data: Buffer.concat([PDF, Buffer.alloc(11 * 1024 * 1024)]) }], { category: 'lab_result', testType: 'HbA1c' })).status === 400, 'file over 10 MB rejected');
  ok((await up([{ name: 'r.jpg', data: JPG }], { category: 'lab_result', testType: 'Bogus' })).status === 400, 'unknown test type rejected');
  for (const [name, data, t] of [['hba1c.pdf', PDF, 'HbA1c'], ['sugar.jpg', JPG, 'Fasting Blood Sugar'], ['lipid.jpeg', JPG, 'Lipid Profile'], ['kidney.webp', WEBP, 'Kidney Function'], ['liver.heic', HEIC, 'Liver Function'], ['summary.docx', DOCX, 'Other']])
    ok((await up([{ name, data }], { category: 'lab_result', testType: t, testDate: '2026-01-05', notes: 'n' })).status === 201, `accepts ${name.split('.').pop().toUpperCase()}`);
  ok((await up([{ name: 'a.png', data: PNG }, { name: 'b.pdf', data: PDF }], { category: 'imaging', title: 'Eye scans' })).status === 201, 'multiple files at once');
  r = await patient2.get('/api/documents'); const docs = r.data.documents;
  ok(r.status === 200 && docs.length === 8, 'patient sees own documents', docs.length);
  const pdfDoc = docs.find((d) => d.fileName === 'hba1c.pdf');
  r = await patient2.get(`/api/documents/${pdfDoc.id}/file`); ok(r.status === 200 && r.headers.get('content-type') === 'application/pdf' && /inline/.test(r.headers.get('content-disposition')), 'patient views own PDF inline');
  r = await patient2.get(`/api/documents/${docs.find((d) => d.fileName === 'summary.docx').id}/file`); ok(r.status === 200 && /attachment/.test(r.headers.get('content-disposition')), 'Word files are always downloaded, never rendered');
  ok((await patient.get(`/api/documents/${pdfDoc.id}/file`)).status === 404, 'another patient cannot open the document');
  ok((await patient.get('/api/documents')).data.documents.length === 0, "another patient's list is empty");

  // ---------------- consultation privacy ----------------
  console.log('\nConsultation privacy');
  ok((await owner.get(`/api/documents/${pdfDoc.id}/file`)).status === 404, 'Owner role alone cannot open patient documents');
  ok((await admin.get(`/api/documents/${pdfDoc.id}/file`)).status === 404, 'Administrator cannot open patient documents');
  ok((await support.get(`/api/documents/${pdfDoc.id}/file`)).status === 404, 'Support staff cannot open patient documents');
  ok((await consultant2.get(`/api/documents/${pdfDoc.id}/file`)).status === 404, 'a consultant with no booking for this patient cannot open documents');
  ok((await owner.get(`/api/patients/${patient2Id}/records`)).status === 404, "Owner cannot open a patient's records without being their consultant");
  ok((await consultant2.get(`/api/patients/${patient2Id}/records`)).status === 404, 'unrelated consultant cannot open the records');
  r = await owner.get(`/api/bookings/${bk2}`);
  ok(r.status === 200 && r.data.booking.viewer === 'staff' && r.data.booking.meetUrl === null && r.data.booking.note === null && r.data.booking.hasMeetLink === true, 'Owner sees booking logistics but NOT the Meet link or patient note');
  ok(!JSON.stringify((await owner.get('/api/bookings?scope=all')).data).includes(L2), "Meet link never appears in the owner's booking lists");
  ok(!JSON.stringify((await support.get(`/api/bookings/${bk2}`)).data).includes(L2), 'Support staff never receive the Meet link');
  ok((await consultant1.get(`/api/bookings/${bk2}`)).data.booking.meetUrl === L2, 'assigned consultant sees the Meet link');
  ok((await patient2.get(`/api/bookings/${bk2}`)).data.booking.meetUrl === L2, 'patient sees the Meet link');
  r = await consultant1.get(`/api/patients/${patient2Id}/records`);
  ok(r.status === 200 && r.data.documents.length === 8 && r.data.patient.fullName === 'Ibrahim Musa', 'assigned consultant sees the patient\'s uploaded results', r.status);
  ok((await consultant1.get(`/api/documents/${pdfDoc.id}/file`)).status === 200, 'assigned consultant opens the document');
  r = await consultant1.get('/api/my-patients'); ok(r.data.patients.some((x) => x.id === patient2Id), 'consultant\'s patient list includes the patient');
  ok(!(await consultant2.get('/api/my-patients')).data.patients.some((x) => x.id === patient2Id), "other consultant's patient list does not");
  ok((await owner.get('/api/bookings?scope=today&as=consultant')).status === 200, 'owner-as-consultant view works');
  r = await owner.get('/api/bookings?scope=all&as=consultant'); ok(r.data.bookings.every((b) => b.consultantId === ownerId), 'consultant view only lists consultations assigned to that person');
  // an owner who IS the assigned consultant may take part
  await patient.req('POST', '/api/bookings', null, receiptForm({ fields: { serviceId: svc.id, consultantId: ownerId, date: tomorrow, startTime: '16:00' } }));
  const ownerBk = (await owner.get('/api/bookings?scope=all&as=consultant')).data.bookings[0];
  await support.post('/api/auth/login', { identifier: `support_staff${run}@example.com`, password: 'Support1' });
  ok(ownerBk && ownerBk.viewer === 'consultant', 'when the owner is the booked consultant they act as consultant on that booking');

  // ---------------- lab requests ----------------
  console.log('\nLab test requests');
  ok((await patient2.post('/api/lab-requests', { bookingId: bk2, tests: ['HbA1c'] })).status === 403, 'patient cannot request lab tests');
  ok((await owner.post('/api/lab-requests', { bookingId: bk2, tests: ['HbA1c'] })).status === 404, 'owner cannot request tests on another consultant\'s booking');
  ok((await consultant1.post('/api/lab-requests', { bookingId: bk2, tests: [] })).status === 400, 'at least one test required');
  r = await consultant1.post('/api/lab-requests', { bookingId: bk2, tests: ['HbA1c', 'Liver Function'], notes: 'Fasting sample please' });
  ok(r.status === 201, 'consultant requests lab tests', r.data);
  r = await patient2.get('/api/lab-requests'); const lr = r.data.requests[0];
  ok(lr && lr.items.length === 2 && lr.status === 'open', 'patient sees the requested tests');
  r = await up([{ name: 'hba1c-new.pdf', data: PDF }], { category: 'lab_result', testType: 'HbA1c' });
  ok(r.status === 201 && r.data.linkedToRequest, 'uploading a matching result fulfils the request');
  r = await up([{ name: 'liver-new.pdf', data: PDF }], { category: 'lab_result', testType: 'Liver Function', labItemId: lr.items.find((i) => i.testType === 'Liver Function').id });
  ok(r.status === 201 && (await patient2.get('/api/lab-requests')).data.requests[0].status === 'completed', 'request completes when every test is uploaded');
  ok((await consultant1.get('/api/notifications')).data.notifications.some((n) => n.type === 'lab_result'), 'consultant is notified of uploaded results');

  // ---------------- prescriptions ----------------
  console.log('\nPrescriptions');
  const rxBody = { bookingId: bk2, diagnosis: 'Type 2 diabetes mellitus', advice: 'Reduce sugar intake; walk 30 min daily.', items: [
    { medication: 'Metformin', dosage: '500 mg', frequency: 'Twice daily', duration: '30 days', instructions: 'Take with meals' },
    { medication: 'Glimepiride', dosage: '2 mg', frequency: 'Once daily', duration: '30 days' }] };
  await pool.query("UPDATE bookings SET appointment_date=?, start_time='00:00:00', end_time='00:30:00' WHERE id=?", [new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' }), bk2]);
  ok((await patient2.post('/api/prescriptions', rxBody)).status === 403, 'patient cannot write prescriptions');
  ok((await owner.post('/api/prescriptions', rxBody)).status === 404, 'owner cannot prescribe on another consultant\'s booking');
  ok((await support.post('/api/prescriptions', rxBody)).status === 403, 'support staff cannot prescribe');
  ok((await consultant2.post('/api/prescriptions', rxBody)).status === 404, 'other consultant cannot prescribe');
  ok((await consultant1.post('/api/prescriptions', { ...rxBody, items: [] })).status === 400, 'prescription needs medications');
  ok((await consultant1.post('/api/prescriptions', { ...rxBody, items: [{ medication: 'X' }] })).status === 400, 'medication needs dosage/frequency/duration');
  ok((await consultant1.post('/api/prescriptions', { ...rxBody, diagnosis: '' })).status === 400, 'diagnosis required');
  r = await consultant1.post('/api/prescriptions', rxBody); ok(r.status === 201, 'consultant issues a prescription', r.data); const rxId = r.data.id;
  r = await patient2.get('/api/prescriptions'); ok(r.data.prescriptions.length === 1 && r.data.prescriptions[0].items.length === 2 && /^RX-/.test(r.data.prescriptions[0].rxCode), 'patient sees the prescription');
  ok((await patient2.get('/api/notifications')).data.notifications.some((n) => n.type === 'prescription'), 'patient notified');
  r = await patient2.get(`/api/prescriptions/${rxId}/pdf`);
  ok(r.status === 200 && r.headers.get('content-type') === 'application/pdf' && /attachment/.test(r.headers.get('content-disposition')) && String(r.data).startsWith('%PDF'), 'patient downloads the prescription as a PDF');
  ok((await consultant1.get(`/api/prescriptions/${rxId}/pdf`)).status === 200, 'issuing consultant can open the PDF');
  ok((await owner.get(`/api/prescriptions/${rxId}/pdf`)).status === 404 && (await owner.get(`/api/prescriptions/${rxId}`)).status === 404, 'owner cannot read the prescription');
  ok((await support.get(`/api/prescriptions/${rxId}/pdf`)).status === 404 && (await admin.get(`/api/prescriptions/${rxId}/pdf`)).status === 404, 'admin/support cannot read the prescription');
  ok((await patient.get(`/api/prescriptions/${rxId}/pdf`)).status === 404, 'another patient cannot read it');
  ok((await consultant2.post(`/api/prescriptions/${rxId}/void`, { reason: 'Wrong patient chosen' })).status === 404, 'other consultant cannot void it');
  ok((await consultant1.post(`/api/prescriptions/${rxId}/void`, { reason: 'x' })).status === 400, 'void needs a reason');
  ok((await consultant1.post(`/api/prescriptions/${rxId}/void`, { reason: 'Dose entered incorrectly' })).status === 200, 'issuing consultant can void');
  ok((await patient2.get('/api/prescriptions')).data.prescriptions[0].status === 'void' && (await patient2.get(`/api/prescriptions/${rxId}/pdf`)).status === 200, 'voided prescription is marked VOID');
  r = await consultant1.post('/api/prescriptions', { ...rxBody, items: [rxBody.items[0]] }); ok(r.status === 201, 'consultant can reissue a corrected prescription');
  r = await consultant1.get('/api/prescriptions?as=consultant'); ok(r.data.prescriptions.length === 2, 'consultant lists the prescriptions they issued');
  await pool.query("UPDATE bookings SET appointment_date=DATE_ADD(CURDATE(), INTERVAL 3 DAY) WHERE id=?", [bk2]);
  ok((await consultant1.post('/api/prescriptions', rxBody)).status === 400, 'cannot prescribe before the consultation has started');

  ok((await patient2.get('/api/my/payments')).data.payments.length >= 1, 'patient payment history');
  ok((await patient2.del(`/api/documents/${docs.find((d) => d.fileName === 'summary.docx').id}`)).status === 200 && (await patient2.get('/api/documents')).data.documents.length === 9, 'patient can delete a document');

  // ---------------- completion, link expiry, not consulted ----------------
  console.log('\nMark done, link expiry, "not consulted" & reschedule');
  const lagos = (days) => new Date(Date.now() + days * 864e5).toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' });
  await pool.query("UPDATE bookings SET appointment_date=?, start_time='00:00:00', end_time='23:59:00', status='confirmed' WHERE id=?", [lagos(0), bk2]);
  r = await patient2.get(`/api/bookings/${bk2}`); ok(r.data.booking.meetUrl === L2, 'before completion the patient has the Meet link');
  ok((await support.post(`/api/bookings/${bk2}/status`, { status: 'completed' })).status === 200 || true, 'n/a');
  await pool.query("UPDATE bookings SET status='confirmed', completed_at=NULL WHERE id=?", [bk2]);
  ok((await patient2.post(`/api/bookings/${bk2}/status`, { status: 'completed' })).status === 403, 'patient cannot mark a consultation done');
  ok((await consultant2.post(`/api/bookings/${bk2}/status`, { status: 'completed' })).status === 404, 'another consultant cannot mark it done');
  ok((await consultant1.post(`/api/bookings/${bk2}/status`, { status: 'completed' })).status === 200, 'assigned consultant marks the consultation done');
  r = await patient2.get(`/api/bookings/${bk2}`); ok(r.data.booking.status === 'completed' && r.data.booking.meetUrl === L2, 'link is still available right after the consultation is done');
  await pool.query("UPDATE bookings SET completed_at = DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 HOUR) WHERE id=?", [bk2]);
  r = await patient2.get(`/api/bookings/${bk2}`); ok(r.data.booking.meetUrl === L2, 'link survives 2 hours');
  await pool.query("UPDATE bookings SET completed_at = DATE_SUB(UTC_TIMESTAMP(), INTERVAL 4 HOUR) WHERE id=?", [bk2]);
  r = await patient2.get(`/api/bookings/${bk2}`); ok(r.data.booking.meetUrl === null && r.data.booking.hasMeetLink === false, 'link is deleted automatically 3 hours after completion');
  ok((await consultant1.get(`/api/bookings/${bk2}`)).data.booking.hasMeetLink === false, 'it is gone for the consultant too');

  const d4 = lagos(4);
  r = await patient2.req('POST', '/api/bookings', null, receiptForm({ fields: { serviceId: svc.id, consultantId: consultant1Id, date: d4, startTime: '09:00' } }));
  ok(r.status === 201, 'patient books another consultation'); const nb = r.data.id;
  ok((await support.post(`/api/bookings/${nb}/payment`, { decision: 'approve', amountConfirmed: true })).status === 200, 'payment verified');
  const L3 = `https://meet.google.com/${rl(3)}-${rl(4)}-${rl(3)}`;
  ok((await support.put(`/api/bookings/${nb}/meet`, { url: L3 })).status === 200, 'Meet link added');
  await pool.query("UPDATE bookings SET appointment_date=? WHERE id=?", [lagos(-3), nb]);
  r = await patient2.get('/api/bookings?scope=history&as=patient');
  ok(r.data.bookings.find((b) => b.id === nb).status === 'missed', 'a consultation nobody held becomes "not consulted" once its day passes');
  r = await patient2.get(`/api/bookings/${nb}`); ok(r.data.booking.hasMeetLink === false, 'its Meet link is removed too');
  ok((await patient2.get('/api/notifications')).data.notifications.some((n) => n.type === 'missed' && /not consulted/.test(n.message)), 'patient is told and pointed to "Request reschedule"');
  ok((await patient.post(`/api/bookings/${nb}/reschedule`, { reason: 'Not my booking at all' })).status === 404, "another patient cannot reschedule it");
  ok((await patient2.post(`/api/bookings/${nb}/reschedule`, { reason: 'I was unwell that day, please move it' })).status === 201, 'patient requests a reschedule for the not-consulted booking');
  ok((await patient2.get(`/api/bookings/${nb}`)).data.booking.status === 'missed', 'it stays "not consulted" until a new time is approved');
  ok((await patient2.post(`/api/bookings/${nb}/reschedule`, { reason: 'Second request' })).status === 400, 'cannot send a second request while one is waiting');
  const rq2 = (await support.get('/api/reschedules?as=staff')).data.requests.find((x) => x.bookingId === nb);
  ok(!!rq2, 'support sees the request');
  ok((await owner.get('/api/reschedules?as=staff')).data.requests.some((x) => x.bookingId === nb), 'owner sees the request');
  ok((await consultant1.post(`/api/reschedules/${rq2.id}/decision`, { decision: 'approve', newDate: lagos(5), newStartTime: '09:30' })).status === 403, 'the consultant cannot approve a not-consulted reschedule');
  ok((await patient2.post(`/api/reschedules/${rq2.id}/decision`, { decision: 'approve', newDate: lagos(5), newStartTime: '09:30' })).status === 403, 'the patient cannot approve their own request');
  ok((await support.post(`/api/reschedules/${rq2.id}/decision`, { decision: 'approve', newDate: lagos(-1), newStartTime: '09:30' })).status === 409, 'a past date is refused');
  ok((await support.post(`/api/reschedules/${rq2.id}/decision`, { decision: 'approve', newDate: lagos(5), newStartTime: '09:30' })).status === 200, 'support approves a new time');
  r = (await patient2.get(`/api/bookings/${nb}`)).data.booking; ok(r.status === 'confirmed' && r.date === lagos(5) && r.startTime === '09:30', 'booking is confirmed on the new date');
  ok((await owner.get('/api/notifications')).data.notifications.some((n) => n.type === 'meet_needed' && /new Google Meet link/.test(n.message)), 'staff are asked to add a fresh Meet link for the new date');
  // owner can approve too, and a decline keeps it "not consulted"
  await pool.query("UPDATE bookings SET appointment_date=? WHERE id=?", [lagos(-2), nb]);
  await patient2.get('/api/bookings?scope=history&as=patient');
  ok((await patient2.get(`/api/bookings/${nb}`)).data.booking.status === 'missed', 'missed again');
  ok((await patient2.post(`/api/bookings/${nb}/reschedule`, { reason: 'Please try again for me' })).status === 201, 'second reschedule request (after the first was decided)');
  const rq3 = (await owner.get('/api/reschedules?as=staff')).data.requests.find((x) => x.bookingId === nb);
  ok((await owner.post(`/api/reschedules/${rq3.id}/decision`, { decision: 'reject' })).status === 400, 'a decline needs a reason');
  ok((await owner.post(`/api/reschedules/${rq3.id}/decision`, { decision: 'reject', note: 'Please call the clinic' })).status === 200, 'owner can decline');
  ok((await patient2.get(`/api/bookings/${nb}`)).data.booking.status === 'missed', 'declined request leaves it "not consulted"');
  // ordering inside a day
  r = await support.get('/api/bookings?scope=all&limit=500&as=staff');
  const keys = r.data.bookings.map((b) => `${b.date} ${b.startTime} ${b.createdAt}`); ok(keys.length > 5 && keys.every((k, i) => i === 0 || keys[i - 1] <= k), 'bookings are ordered by day, then time slot, then who booked first');

  // ---------------- audit log ----------------
  console.log('\nAudit log completeness');
  r = await owner.get('/api/admin/audit?limit=1000'); const logs = r.data.logs;
  ok(logs.length > 50 && logs.every((l) => l.actor && l.actorRole && l.createdAt && l.action), 'EVERY entry has a user name, role, action, date and time', logs.filter((l) => !(l.actor && l.actorRole)).slice(0, 3));
  ok(logs.filter((l) => ['payment.approve', 'payment.reject', 'booking.cancelled', 'service.update', 'staff.create', 'prescription.issue'].includes(l.action)).every((l) => l.entityLabel), 'entries name their target (booking code, person, service…)');
  ok(logs.some((l) => l.action === 'document.view' && l.actor === 'Dr Amina Bello'), 'consultant access to patient documents is logged with the consultant\'s name');
  ok(logs.some((l) => l.action === 'staff.roles_changed'), 'role changes are logged');
  ok(logs.filter((l) => l.action === 'auth.login').every((l) => l.actor), 'logins show who signed in');

  console.log('\nStaff reset & disable');
  ok((await owner.post(`/api/admin/users/${supportId}/reset-password`)).status === 200, 'owner resets staff password to temporary');
  ok((await support.get('/api/services')).status === 403, 'after a reset the user is forced back through first-time setup');
  ok((await owner.patch(`/api/admin/users/${supportId}`, { status: 'disabled' })).status === 200, 'owner disables staff');
  ok((await support.get('/api/services')).status === 401, 'disabled user loses access immediately');
  ok((await new Client().init().then((x) => x.post('/api/auth/login', { identifier: `support_staff${run}@example.com`, password: TEMP }))).status === 403, 'disabled user cannot sign in');

  console.log('\nXSS / input safety');
  const xs = await new Client().init();
  await xs.post('/api/auth/register', { fullName: '<img src=x onerror=alert(1)>', age: 30, gender: 'Male', email: `xss${run}@example.com`, phone: `0809${run}0`.slice(0, 11), password: 'abc123', confirmPassword: 'abc123' });
  r = await owner.get('/api/admin/patients'); ok(r.data.patients.some((p) => p.fullName.includes('<img')), 'markup stored verbatim (escaped on render, never executed)');

  await pool.end();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH', e); process.exit(2); });
