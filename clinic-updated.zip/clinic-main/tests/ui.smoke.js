'use strict';
// Loads the real UI in jsdom against a running server and walks every tab for each role.
const { JSDOM } = require('jsdom');
const BASE = process.env.BASE || 'http://localhost:3000';
let fails = 0; const ok = (c, m) => { console.log(c ? '  ✓' : '  ✗', m); if (!c) fails++; };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function open() {
  const jar = {};
  const dom = await JSDOM.fromURL(BASE + '/', { runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true,
    beforeParse(w) {
      w.fetch = async (url, o = {}) => {
        const headers = { ...(o.headers || {}), cookie: Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ') };
        const r = await fetch(new URL(url, BASE).href, { ...o, headers, redirect: 'manual' });
        for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }
        return r;
      };
      w.confirm = () => true; w.scrollTo = () => {};
      w.addEventListener('error', (e) => { console.log('  PAGE ERROR:', e.message); fails++; });
    } });
  await wait(800);
  return dom;
}
const text = (dom) => dom.window.document.body.textContent;
async function login(dom, id, pw) {
  const d = dom.window.document;
  d.querySelector('[data-action=showLogin]').click(); await wait(100);
  d.querySelector('#f_identifier').value = id; d.querySelector('#f_password').value = pw;
  d.querySelector('form[data-form=login]').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true })); await wait(900);
}
async function walkTabs(dom, label) {
  const d = dom.window.document; const tabs = [...d.querySelectorAll('[data-action=tab]')].map((b) => b.dataset.tab);
  ok(tabs.length > 0, `${label}: portal shows tabs [${tabs.join(', ')}]`);
  for (const t of tabs) {
    d.querySelector(`[data-action=tab][data-tab=${t}]`).click(); await wait(700);
    const c = d.querySelector('#tabContent').textContent;
    ok(!/Loading…/.test(c) && !/Something went wrong|undefined|\[object/.test(c) && c.trim().length > 10, `${label}: tab "${t}" renders`);
  }
}

(async () => {
  const mysql = require('mysql2/promise'); require('dotenv').config();
  const db = await mysql.createConnection({ host: '127.0.0.1', user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME });
  const [[pa]] = await db.query("SELECT email FROM users WHERE email LIKE 'ibrahim%' ORDER BY id DESC LIMIT 1");
  const [[co]] = await db.query("SELECT cu.email FROM bookings b JOIN users cu ON cu.id=b.consultant_id JOIN users pu ON pu.id=b.patient_id WHERE pu.email=? AND b.status IN ('confirmed','completed') LIMIT 1", [pa.email]);
  await db.end();

  console.log('Landing / public pages');
  let dom = await open(); let d = dom.window.document;
  ok(/Welcome to/.test(text(dom)) && !/demo|Demo|username/i.test(d.querySelector('#view').textContent), 'landing renders, no demo/username text');
  d.querySelector('[data-action=showRegister]').click(); await wait(100);
  ok(!d.querySelector('[name=username]') && d.querySelector('[name=confirmPassword]') && d.querySelector('[name=email]') && d.querySelector('[name=phone]'), 'register form: no username, has email/phone/confirm');
  d.querySelector('[data-action=showLogin]').click(); await wait(100);
  ok(/Email or Phone Number/.test(text(dom)) && !d.querySelector('[name=username]'), 'login asks for email or phone only');
  d.querySelector('[data-action=showForgot]').click(); await wait(100); ok(/Reset Password/.test(text(dom)), 'forgot-password page opens');
  ok(!/demo123|password123|demo@/i.test(dom.serialize()), 'no demo credentials anywhere in page');

  console.log('Owner'); dom = await open(); await login(dom, 'owner@example.com', 'NewOwner1');
  ok(/Owner/.test(text(dom)) && dom.window.document.querySelector('[data-action=switchPortal]'), 'owner (also a consultant) lands in management portal with a portal switcher'); await walkTabs(dom, 'owner');
  dom.window.document.querySelector('[data-action=tab][data-tab=audit]').click(); await wait(800);
  { const t = dom.window.document.querySelector('#tabContent').textContent; ok(/Audit log/.test(t) && !/System \(automatic\)/.test(t), 'audit log shows a user for every entry'); }
  dom.window.document.querySelector('[data-action=tab][data-tab=staff]').click(); await wait(800);
  ok(/Edit roles/.test(dom.window.document.querySelector('#tabContent').textContent), 'owner can edit their own roles');
  dom.window.document.querySelector('[data-action=switchPortal][data-portal=consultant]').click(); await wait(500); await walkTabs(dom, 'owner-as-consultant');
  ok(/consultations/.test(dom.window.document.querySelector('#portalSub').textContent), 'switching portal changes the view');
  console.log('Consultant'); dom = await open(); await login(dom, co.email, 'Consult1');
  ok(/Consultant/.test(text(dom)) && !dom.window.document.querySelector('[data-action=switchPortal]'), 'consultant lands in consultant portal (no switcher)'); await walkTabs(dom, 'consultant');
  dom.window.document.querySelector('[data-action=tab][data-tab=patients]').click(); await wait(800);
  dom.window.document.querySelector('[data-action=openRecords]').click(); await wait(1000);
  { const t = text(dom); ok(/Test results & documents/.test(t) && /Write a prescription/.test(t) && /Request lab tests/.test(t), 'consultant opens patient records with documents, lab request and prescription forms'); }
  console.log('Patient'); dom = await open(); await login(dom, pa.email, 'newpass1');
  ok(/Patient/.test(text(dom)), 'patient lands in patient portal'); await walkTabs(dom, 'patient');
  dom.window.document.querySelector('[data-action=tab][data-tab=prescriptions]').click(); await wait(800);
  ok(/Download PDF/.test(dom.window.document.querySelector('#tabContent').innerHTML), 'patient sees prescriptions with PDF download');
  dom.window.document.querySelector('[data-action=tab][data-tab=records]').click(); await wait(800);
  ok(/test results/i.test(dom.window.document.querySelector('#tabContent').textContent) && dom.window.document.querySelector('a[href*="/api/documents/"]'), 'patient sees uploaded test results with view/download');
  dom.window.document.querySelector('[data-action=openUpload]').click(); await wait(500);
  ok(dom.window.document.querySelector('form[data-form=uploadDoc] input[type=file][multiple]'), 'upload form accepts multiple files');
  dom.window.document.querySelector('[data-action=closeModal]').click();
  dom.window.document.querySelector('[data-action=tab][data-tab=upcoming]').click(); await wait(500);
  dom.window.document.querySelector('[data-action=openWizard]').click(); await wait(900);
  ok(/Choose a service/.test(text(dom)) && /Consultation/.test(text(dom)), 'booking wizard lists services with fees');
  dom.window.document.querySelector('[data-action=wzService]').click(); await wait(100);
  dom.window.document.querySelector('[data-action=wzConsultant]').click(); await wait(900);
  dom.window.document.querySelector('[data-action=wzDate]').click(); await wait(900);
  dom.window.document.querySelector('[data-action=wzTime]:not([disabled])').click(); await wait(200);
  ok(/3004145989/.test(text(dom)) && /THE CLINIC LTD/.test(text(dom)) && /GTBank/.test(text(dom)), 'wizard shows payment account details');
  console.log(fails ? `\n${fails} FAILED` : '\nUI smoke OK'); process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
