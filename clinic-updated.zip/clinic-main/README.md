# The Clinic DiabetesCare — Telemedicine Portal

Node.js + Express + MySQL backend with the original Tailwind UI, now database-backed. One login for patients, consultants and staff; bookings with receipt upload, payment verification and Google Meet links.

## 1. Requirements
- Node.js 18+ (tested on 22), MySQL 8.0+ (or MariaDB 10.5+), a reverse proxy with HTTPS for production (nginx/Caddy).

## 2. Install
```bash
npm install
cp .env.example .env        # then edit .env (see below)
```
Create the database and a least-privilege user (run as MySQL admin):
```sql
CREATE DATABASE clinic CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'clinic_app'@'localhost' IDENTIFIED BY 'use-a-long-random-password';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES ON clinic.* TO 'clinic_app'@'localhost';
```
(After the first run you may revoke CREATE/ALTER/INDEX/REFERENCES and use a separate migration user for upgrades.)

Edit `.env`: set `DB_*`, and a random `SESSION_SECRET`:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

## 3. Migrate and create the owner
```bash
npm run migrate          # creates tables (incl. sessions) + roles, permissions, security questions, payment details
node hash.js             # asks for the owner's name, email, phone, job title, password and security question
```
`node hash.js` also runs any pending migrations first, so on a new database you can skip the separate `npm run migrate`. Run it again later to replace the owner details/password (it asks for confirmation).
The password is bcrypt-hashed; nothing is stored in plaintext or logged. There are **no default users** — only the owner you create.  Because you type everything in the terminal, no forced first-login setup is required for the owner (other staff still get it).

## 4. Run
```bash
npm start                # http://localhost:3000
```
Production: run under a process manager (`pm2 start server.js --name clinic` or a systemd unit) with `NODE_ENV=production`, behind HTTPS. Example nginx block:
```nginx
server { listen 443 ssl http2; server_name clinic.example.com;
  client_max_body_size 6m;
  location / { proxy_pass http://127.0.0.1:3000; proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; proxy_set_header X-Forwarded-Proto $scheme; } }
```
Keep `TRUST_PROXY=1` (one proxy) so rate limiting sees real client IPs, and `COOKIE_SECURE=auto (or true)`.

## 5. How it works
| Area | Behaviour |
|---|---|
| Login | Email **or** phone + password, one page for all roles; redirected to the patient / consultant / staff portal by role. Accounts lock for 15 min after 5 bad passwords; IP rate limits apply. |
| Patients | Register with name, age, gender, email, phone, password + confirm (≥ 6 chars). Duplicate email/phone blocked. |
| Staff | Created by Owner/Administrator (anyone with `users.manage`) with temporary password `TEMP_STAFF_PASSWORD` (default `theclinic`). First login forces a new password + security question. Users can only manage roles **below** their own rank. |
| Roles | Owner, Administrator, Assistant Administrator, Support Staff, Consultant, Patient + custom roles (Owner → *Roles & permissions*). Every API route checks permissions server-side. |
| Recovery | Email/phone → security question (answer trimmed, uppercased, bcrypt-compared) → new password. Unknown accounts get a stable decoy question; 5 wrong answers lock recovery 30 min; tokens are single-use. Optional email OTP as a second factor (`RECOVERY_OTP_ENABLED=true` + SMTP). |
| Booking | Service (fee shown) → consultant → date → slot → pay to the account shown → upload receipt (JPG/PNG/PDF ≤ 5 MB, content-sniffed). Fee is snapshotted on the booking. |
| Payment | Support staff open the receipt, tick that the amount matches, approve/reject. A receipt alone never confirms a booking. Decisions are audited (who, what, when). Rejection releases the slot. |
| Meet | After approval, authorised staff paste a `https://meet.google.com/xxx-xxxx-xxx` link (validated; one link per booking). Visible only to that patient, that consultant and authorised staff. Optional automatic creation (below). |
| Double-booking | Per-consultant row lock inside a transaction **plus** a UNIQUE index on (consultant, date, start, active). Tested with 8 simultaneous requests → exactly 1 wins. |
| Availability | Consultants set weekly ranges, one-off dates, days off and appointment length. Changes never auto-cancel bookings; affected ones are flagged to staff. |
| Statuses | requested · confirmed · reschedule_requested · completed · cancelled · missed · rejected. Past-date confirmed bookings become *missed* automatically and move to History / follow-up. Full status history kept. |
| Ordering | Date, then start time, then request time (earliest first). |
| Reschedule | Patient requests with reason → consultant/staff approve, decline, or propose an alternative → patient accepts/declines. New times are validated against the consultant’s schedule. Staff can also arrange new times for missed bookings and message patients. |
| Multiple roles | One person can hold several roles (e.g. Owner + Consultant, or Support Staff + Owner). Permissions combine and a **portal switcher** appears (Management / Consultant). Only an Owner can hand out the Owner role; others can assign only roles below their own. The last active Owner can never be removed or disabled. |
| Consultation privacy | Roles never grant access to a consultation. The **Meet link, the patient's note, the patient's documents and prescriptions** are visible only to the patient and the **assigned consultant** — not to the Owner, Administrators or Support (they manage scheduling and payments only). An Owner sees a consultation only when they are the consultant who was booked. Consultant access to documents requires a confirmed booking (or a completed one within `RECORD_ACCESS_DAYS`) and every access is audit-logged. |
| Test results & documents | Patients upload results (HbA1c, Fasting Blood Sugar, Lipid, Kidney, Liver, Other) and other documents: PDF, PNG, JPG/JPEG, GIF, WEBP, HEIC, TIFF, DOC, DOCX (max 10 MB, up to 5 per upload). File content is checked, not just the extension; files live outside the web root. Consultants can request lab tests; the patient's upload fulfils the request. |
| Prescriptions | The booked consultant writes a prescription (diagnosis, medications with dosage/frequency/duration, advice) once the consultation has started. The patient sees it under *Prescriptions* and downloads a **PDF** to take to a pharmacy. Prescriptions can be voided (shown as VOID on the PDF) and reissued. |
| Finishing a consultation | The consultant taps **✔ Mark done** (on the booking card or in its details). The Meet link is then **deleted automatically 3 hours later** (`MEET_LINK_RETENTION_HOURS`); links of consultations never marked done are removed 3 hours after their scheduled end. |
| Not consulted | When a day passes without the consultation being marked done it becomes **Not consulted** (a consultant can also mark it). The patient taps **Request reschedule**; the **Owner, Administrators or Support** approve a new time (or decline, or propose another); the consultant cannot approve these. Staff are asked to add a fresh Meet link for the new date. |
| Daily order | Inside each day: earliest time slot first; same time → whoever booked first. Each card shows its place in the day (1, 2, 3…); cancelled/rejected ones are not numbered. |
| WhatsApp alerts | Every new booking and every reschedule request is sent to the clinic's WhatsApp number (default **+234 703 563 9129**, editable under *Management → WhatsApp alerts*). Messages hold only the patient's name, booking reference, service, consultant and time — never notes or reasons. They are queued in the database (nothing is lost if WhatsApp is down), retried automatically, and a failure never blocks a booking. **Automatic sending needs a provider account** — set `WHATSAPP_PROVIDER` (`cloud` = Meta WhatsApp Business Cloud API, `twilio`, or `callmebot`) and its credentials in `.env`. Without one, alerts wait in the list with a one-tap *Send via WhatsApp* link. |
| Home page | Branded to match the logo (ivory, bronze rule, deep teal, serif headings) with the login card on the home page. The background artwork is `public/assets/images/health-bg.svg`; to use your own photo save it as `public/assets/images/health-bg.jpg` (it is shown softly behind the artwork). After changing styles run `npm run build:css`. |
| Audit log | Every entry records the user's name and role (snapshot), action, target (booking code, person, service…), details, IP, date and time. |
| Notifications | In-portal bell with read/unread; booking requests, payment decisions, Meet links, reschedules, cancellations, reminders (24 h before). |

## 6. Optional: automatic Google Meet links
Needs a Google Cloud project with the **Google Calendar API** enabled and an OAuth client; obtain a refresh token for the clinic’s Google account (e.g. via the OAuth Playground with scope `https://www.googleapis.com/auth/calendar.events`), then set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REFRESH_TOKEN`. A “Generate with Google” button then appears on confirmed bookings. This integration could not be exercised without live Google credentials, so test it once in your environment; pasting links manually always works.

## 7. Backups and recovery
```bash
chmod +x scripts/backup.sh
crontab -e   # 30 2 * * * /opt/clinic/scripts/backup.sh >> /var/log/clinic-backup.log 2>&1
```
Dumps the database (gzip) and the `uploads/` receipts nightly, keeping `BACKUP_KEEP_DAYS` days. Copy backups off the server. Restore:
```bash
gunzip -c backups/db-YYYYMMDD-HHMMSS.sql.gz | mysql -u root -p clinic
tar -xzf backups/uploads-YYYYMMDD-HHMMSS.tar.gz -C .
```
Test a restore on a spare machine before you rely on it.

## 8. Security notes
bcrypt (cost 12) for passwords and answers · parameterised SQL everywhere · server-side validation · httpOnly + SameSite cookie sessions stored in MySQL · CSRF token on every state-changing request · strict CSP (no inline scripts; all assets self-hosted, Tailwind pre-built) + helmet headers · output escaped in the UI · receipts stored outside the web root and served only to the owning patient / payment verifiers · audit log for admin actions · secrets only in `.env`.
Patient data is confidential health information. Before go-live: serve over HTTPS only, restrict server/DB access, review the Nigeria Data Protection Act 2023 obligations (privacy notice, consent, retention, breach process) with your legal adviser, and set up monitoring.

## 9. Development
`npm run build:css` after changing markup/classes. Tests (use an **empty** throwaway database and `RATE_LIMIT_SCALE=100`):
```bash
BASE=http://localhost:3000 OWNER_EMAIL=… OWNER_PASSWORD=<owner password after first-login change> npm run test:api
npm run test:ui
```
The original template pages are kept in `legacy-ui/` for reference (not served).
