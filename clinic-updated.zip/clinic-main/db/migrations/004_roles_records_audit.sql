-- 004: multiple roles per user, richer audit log, patient documents, lab requests, prescriptions.
-- Written to be safely re-runnable.

CREATE TABLE IF NOT EXISTS user_roles (
  user_id     BIGINT UNSIGNED NOT NULL,
  role_id     INT UNSIGNED NOT NULL,
  assigned_by BIGINT UNSIGNED NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, role_id),
  KEY idx_ur_role (role_id),
  CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_ur_assigner FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO user_roles (user_id, role_id) SELECT id, role_id FROM users;

-- audit_logs: snapshot of who did it (name + role at the time) and a readable target label
SET @c := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'audit_logs' AND column_name = 'actor_name');
SET @s := IF(@c = 0, 'ALTER TABLE audit_logs ADD COLUMN actor_name VARCHAR(150) NULL AFTER actor_id, ADD COLUMN actor_role VARCHAR(160) NULL AFTER actor_name, ADD COLUMN entity_label VARCHAR(200) NULL AFTER entity_id', 'SELECT 1');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

-- owner entries written by the old setup script had no actor: the owner created themself
UPDATE audit_logs a JOIN users u ON u.id = CAST(a.entity_id AS UNSIGNED)
   SET a.actor_id = u.id WHERE a.actor_id IS NULL AND a.entity_type = 'user' AND a.action IN ('owner.created', 'owner.updated');
UPDATE audit_logs a JOIN users u ON u.id = a.actor_id
   SET a.actor_name = u.full_name,
       a.actor_role = (SELECT GROUP_CONCAT(r.name ORDER BY r.rank_level DESC SEPARATOR ' + ') FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id)
 WHERE a.actor_name IS NULL;
UPDATE audit_logs a JOIN users u ON u.id = CAST(a.entity_id AS UNSIGNED) SET a.entity_label = u.full_name WHERE a.entity_type = 'user' AND a.entity_label IS NULL;
UPDATE audit_logs a JOIN bookings b ON b.id = CAST(a.entity_id AS UNSIGNED) SET a.entity_label = b.booking_code WHERE a.entity_type = 'booking' AND a.entity_label IS NULL;
UPDATE audit_logs a JOIN services s ON s.id = CAST(a.entity_id AS UNSIGNED) SET a.entity_label = s.name WHERE a.entity_type = 'service' AND a.entity_label IS NULL;
UPDATE audit_logs a JOIN roles r ON r.id = CAST(a.entity_id AS UNSIGNED) SET a.entity_label = r.name WHERE a.entity_type = 'role' AND a.entity_label IS NULL;

CREATE TABLE IF NOT EXISTS patient_documents (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  patient_id    BIGINT UNSIGNED NOT NULL,
  category      ENUM('lab_result','imaging','report','other') NOT NULL DEFAULT 'lab_result',
  test_type     VARCHAR(60) NULL,
  title         VARCHAR(150) NOT NULL,
  notes         VARCHAR(500) NULL,
  test_date     DATE NULL,
  stored_name   VARCHAR(80) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  mime_type     VARCHAR(120) NOT NULL,
  size_bytes    INT UNSIGNED NOT NULL,
  sha256        CHAR(64) NOT NULL,
  uploaded_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at    DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_pd_patient (patient_id, deleted_at, uploaded_at),
  CONSTRAINT fk_pd_patient FOREIGN KEY (patient_id) REFERENCES patient_profiles(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lab_requests (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id    BIGINT UNSIGNED NULL,
  patient_id    BIGINT UNSIGNED NOT NULL,
  consultant_id BIGINT UNSIGNED NOT NULL,
  notes         VARCHAR(500) NULL,
  status        ENUM('open','completed','cancelled') NOT NULL DEFAULT 'open',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_lr_patient (patient_id, status),
  KEY idx_lr_consultant (consultant_id, created_at),
  CONSTRAINT fk_lr_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
  CONSTRAINT fk_lr_patient FOREIGN KEY (patient_id) REFERENCES patient_profiles(user_id),
  CONSTRAINT fk_lr_consultant FOREIGN KEY (consultant_id) REFERENCES consultants(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lab_request_items (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id   BIGINT UNSIGNED NOT NULL,
  test_type    VARCHAR(80) NOT NULL,
  status       ENUM('pending','uploaded') NOT NULL DEFAULT 'pending',
  document_id  BIGINT UNSIGNED NULL,
  fulfilled_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_lri_request (request_id),
  CONSTRAINT fk_lri_request FOREIGN KEY (request_id) REFERENCES lab_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_lri_document FOREIGN KEY (document_id) REFERENCES patient_documents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS prescriptions (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  rx_code       VARCHAR(30) NOT NULL,
  booking_id    BIGINT UNSIGNED NOT NULL,
  patient_id    BIGINT UNSIGNED NOT NULL,
  consultant_id BIGINT UNSIGNED NOT NULL,
  diagnosis     VARCHAR(500) NOT NULL,
  advice        VARCHAR(1000) NULL,
  status        ENUM('issued','void') NOT NULL DEFAULT 'issued',
  void_reason   VARCHAR(300) NULL,
  voided_at     DATETIME NULL,
  issued_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rx_code (rx_code),
  KEY idx_rx_patient (patient_id, issued_at),
  KEY idx_rx_consultant (consultant_id, issued_at),
  KEY idx_rx_booking (booking_id),
  CONSTRAINT fk_rx_booking FOREIGN KEY (booking_id) REFERENCES bookings(id),
  CONSTRAINT fk_rx_patient FOREIGN KEY (patient_id) REFERENCES patient_profiles(user_id),
  CONSTRAINT fk_rx_consultant FOREIGN KEY (consultant_id) REFERENCES consultants(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS prescription_items (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  prescription_id BIGINT UNSIGNED NOT NULL,
  sort_order      SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  medication      VARCHAR(150) NOT NULL,
  dosage          VARCHAR(100) NOT NULL,
  frequency       VARCHAR(100) NOT NULL,
  duration        VARCHAR(100) NOT NULL,
  instructions    VARCHAR(300) NULL,
  PRIMARY KEY (id),
  KEY idx_rxi_rx (prescription_id, sort_order),
  CONSTRAINT fk_rxi_rx FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
