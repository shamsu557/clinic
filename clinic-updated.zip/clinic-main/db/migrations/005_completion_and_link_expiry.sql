-- 005: remember when a consultation was marked done (used to expire the Meet link). Safely re-runnable.
SET @c := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'bookings' AND column_name = 'completed_at');
SET @s := IF(@c = 0, 'ALTER TABLE bookings ADD COLUMN completed_at DATETIME NULL AFTER reminder_sent_at', 'SELECT 1');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
UPDATE bookings SET completed_at = updated_at WHERE status = 'completed' AND completed_at IS NULL;
