-- 002_reference_data.sql : roles, permissions, security questions, payment account details.
-- This is configuration, not demo data: no users, passwords, services or bookings are created here.

INSERT IGNORE INTO permissions (code, description) VALUES
 ('users.view',        'View staff and patient accounts'),
 ('users.manage',      'Create, edit, disable staff accounts and reset their passwords'),
 ('roles.manage',      'Create and edit roles and their permissions'),
 ('services.manage',   'Create/edit consultation services and fees'),
 ('bookings.view_all', 'View all bookings'),
 ('bookings.manage',   'Cancel, arrange, mark and message on any booking'),
 ('payments.verify',   'View receipts and approve/reject payments'),
 ('meet.manage',       'Create or paste Google Meet links on bookings'),
 ('reschedule.review', 'Review and decide reschedule requests for any consultant'),
 ('patients.view',     'View patient directory'),
 ('audit.view',        'View the audit log'),
 ('settings.manage',   'Edit payment account details and system settings');

INSERT IGNORE INTO roles (code, name, portal, rank_level, is_system) VALUES
 ('owner',                   'Owner',                   'staff',      100, 1),
 ('administrator',           'Administrator',           'staff',       80, 1),
 ('assistant_administrator', 'Assistant Administrator', 'staff',       60, 1),
 ('support_staff',           'Support Staff',           'staff',       40, 1),
 ('consultant',              'Consultant',              'consultant',  40, 1),
 ('patient',                 'Patient',                 'patient',      0, 1);

-- owner: everything
INSERT IGNORE INTO role_permissions (role_id, permission_id)
  SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.code = 'owner';
-- administrator: everything except role management
INSERT IGNORE INTO role_permissions (role_id, permission_id)
  SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.code = 'administrator' AND p.code <> 'roles.manage';
-- assistant administrator
INSERT IGNORE INTO role_permissions (role_id, permission_id)
  SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN
   ('users.view','bookings.view_all','bookings.manage','reschedule.review','patients.view') WHERE r.code = 'assistant_administrator';
-- support staff
INSERT IGNORE INTO role_permissions (role_id, permission_id)
  SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN
   ('services.manage','bookings.view_all','bookings.manage','payments.verify','meet.manage','reschedule.review','patients.view') WHERE r.code = 'support_staff';

INSERT IGNORE INTO security_questions (question) VALUES
 ('What was the name of your first school?'),
 ('What is your mother''s maiden name?'),
 ('What was the name of your first pet?'),
 ('In what town or city were you born?'),
 ('What was your childhood nickname?'),
 ('What is the name of your favourite teacher?'),
 ('What was the make of your first car or bicycle?'),
 ('What is the middle name of your oldest sibling?');

INSERT IGNORE INTO app_settings (setting_key, setting_value) VALUES
 ('payment_account_name',   'THE CLINIC LTD.'),
 ('payment_bank',           'GTBank'),
 ('payment_account_number', '3004145989'),
 ('payment_instructions',   'Pay the exact consultation fee, then upload your payment receipt with your booking request.');
