-- 006: WhatsApp alerts to the clinic when a patient books or asks to reschedule. Safely re-runnable.
CREATE TABLE IF NOT EXISTS whatsapp_outbox (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  event_type VARCHAR(30) NOT NULL,
  booking_id BIGINT UNSIGNED NULL,
  to_number  VARCHAR(20) NOT NULL,
  message    VARCHAR(1000) NOT NULL,
  status     ENUM('queued','sending','sent','failed','manual') NOT NULL DEFAULT 'queued',
  attempts   TINYINT UNSIGNED NOT NULL DEFAULT 0,
  provider   VARCHAR(20) NULL,
  last_error VARCHAR(300) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  sent_at    DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_wa_status (status, created_at),
  CONSTRAINT fk_wa_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO app_settings (setting_key, setting_value) VALUES ('whatsapp_number', '+2347035639129'), ('whatsapp_enabled', '1');
