-- 001_init.sql : core schema (MySQL 8 / MariaDB 10.5+). All timestamps are stored in UTC.
-- Appointment date/time columns are clinic-local wall-clock values (see CLINIC_TIMEZONE).

CREATE TABLE IF NOT EXISTS roles (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code          VARCHAR(40)  NOT NULL,
  name          VARCHAR(80)  NOT NULL,
  portal        ENUM('patient','consultant','staff') NOT NULL DEFAULT 'staff',
  rank_level    SMALLINT UNSIGNED NOT NULL DEFAULT 30,   -- a user may only manage users of lower rank
  is_system     TINYINT(1)   NOT NULL DEFAULT 0,         -- system roles cannot be deleted/renamed
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_roles_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS permissions (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code        VARCHAR(60)  NOT NULL,
  description VARCHAR(200) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permissions_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id       INT UNSIGNED NOT NULL,
  permission_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_perm FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  role_id               INT UNSIGNED NOT NULL,
  full_name             VARCHAR(150) NOT NULL,
  email                 VARCHAR(190) NULL,
  phone                 VARCHAR(20)  NULL,
  password_hash         VARCHAR(100) NOT NULL,
  status                ENUM('active','disabled') NOT NULL DEFAULT 'active',
  must_change_password  TINYINT(1) NOT NULL DEFAULT 0,
  must_setup_security   TINYINT(1) NOT NULL DEFAULT 1,
  failed_login_count    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until          DATETIME NULL,
  recovery_failed_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  recovery_locked_until DATETIME NULL,
  password_changed_at   DATETIME NULL,
  last_login_at         DATETIME NULL,
  created_by            BIGINT UNSIGNED NULL,
  created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  UNIQUE KEY uq_users_phone (phone),
  KEY idx_users_role (role_id),
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT fk_users_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT chk_users_contact CHECK (email IS NOT NULL OR phone IS NOT NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS patient_profiles (
  user_id      BIGINT UNSIGNED NOT NULL,
  patient_code VARCHAR(20) NOT NULL,
  age          TINYINT UNSIGNED NULL,
  gender       ENUM('Male','Female') NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_patient_code (patient_code),
  CONSTRAINT fk_pp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_profiles (
  user_id    BIGINT UNSIGNED NOT NULL,
  job_title  VARCHAR(100) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_sp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS consultants (
  user_id          BIGINT UNSIGNED NOT NULL,
  specialty        VARCHAR(120) NULL,
  bio              VARCHAR(500) NULL,
  accepting_bookings TINYINT(1) NOT NULL DEFAULT 1,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_cons_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS security_questions (
  id       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  question VARCHAR(200) NOT NULL,
  active   TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sq_question (question)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_security_answers (
  user_id     BIGINT UNSIGNED NOT NULL,
  question_id INT UNSIGNED NOT NULL,
  answer_hash VARCHAR(100) NOT NULL,       -- bcrypt(UPPERCASE(TRIM(answer)))
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_usa_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_usa_question FOREIGN KEY (question_id) REFERENCES security_questions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS password_recovery_sessions (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_hash      CHAR(64) NOT NULL,                -- sha256 of the opaque token given to the browser
  user_id         BIGINT UNSIGNED NULL,             -- NULL for unknown identifiers (anti-enumeration)
  attempts        TINYINT UNSIGNED NOT NULL DEFAULT 0,
  otp_hash        CHAR(64) NULL,
  otp_expires_at  DATETIME NULL,
  verified_at     DATETIME NULL,
  used_at         DATETIME NULL,
  expires_at      DATETIME NOT NULL,
  ip_address      VARCHAR(45) NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_prs_token (token_hash),
  KEY idx_prs_user (user_id),
  CONSTRAINT fk_prs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS services (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name             VARCHAR(120) NOT NULL,
  description      VARCHAR(500) NULL,
  fee              DECIMAL(12,2) NOT NULL,
  active           TINYINT(1) NOT NULL DEFAULT 1,
  created_by       BIGINT UNSIGNED NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_service_name (name),
  CONSTRAINT chk_service_fee CHECK (fee >= 0),
  CONSTRAINT fk_service_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Consultant availability. Either a weekly rule (day_of_week 0=Sunday..6) or a rule for one specific date.
-- If a consultant has any specific-date rule for a day, those rules replace the weekly rules for that day.
CREATE TABLE IF NOT EXISTS consultant_availability (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  consultant_id BIGINT UNSIGNED NOT NULL,
  rule_type     ENUM('weekly','date') NOT NULL,
  day_of_week   TINYINT UNSIGNED NULL,
  specific_date DATE NULL,
  start_time    TIME NOT NULL,
  end_time      TIME NOT NULL,
  slot_minutes  SMALLINT UNSIGNED NOT NULL DEFAULT 30,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_ca_consultant (consultant_id, rule_type, day_of_week, specific_date),
  CONSTRAINT fk_ca_consultant FOREIGN KEY (consultant_id) REFERENCES consultants(user_id) ON DELETE CASCADE,
  CONSTRAINT chk_ca_times CHECK (end_time > start_time),
  CONSTRAINT chk_ca_shape CHECK (
    (rule_type = 'weekly' AND day_of_week IS NOT NULL AND specific_date IS NULL) OR
    (rule_type = 'date'   AND specific_date IS NOT NULL AND day_of_week IS NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS consultant_blocked_dates (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  consultant_id BIGINT UNSIGNED NOT NULL,
  blocked_date  DATE NOT NULL,
  reason        VARCHAR(200) NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cbd (consultant_id, blocked_date),
  CONSTRAINT fk_cbd_consultant FOREIGN KEY (consultant_id) REFERENCES consultants(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bookings (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_code     VARCHAR(20) NOT NULL,
  patient_id       BIGINT UNSIGNED NOT NULL,
  consultant_id    BIGINT UNSIGNED NOT NULL,
  service_id       INT UNSIGNED NOT NULL,
  service_name     VARCHAR(120) NOT NULL,           -- snapshot at booking time
  fee_amount       DECIMAL(12,2) NOT NULL,          -- snapshot at booking time
  appointment_date DATE NOT NULL,
  start_time       TIME NOT NULL,
  end_time         TIME NOT NULL,
  status           ENUM('requested','confirmed','reschedule_requested','completed','cancelled','missed','rejected') NOT NULL DEFAULT 'requested',
  patient_note     VARCHAR(500) NULL,
  reminder_sent_at DATETIME NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  -- non-NULL only while the booking occupies the slot; the UNIQUE key below makes double-booking impossible
  slot_lock        TINYINT GENERATED ALWAYS AS (CASE WHEN status IN ('requested','confirmed','reschedule_requested') THEN 1 ELSE NULL END) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY uq_booking_code (booking_code),
  UNIQUE KEY uq_booking_slot (consultant_id, appointment_date, start_time, slot_lock),
  KEY idx_booking_patient (patient_id, appointment_date),
  KEY idx_booking_consultant (consultant_id, appointment_date, start_time, created_at),
  KEY idx_booking_status (status, appointment_date),
  CONSTRAINT fk_booking_patient FOREIGN KEY (patient_id) REFERENCES patient_profiles(user_id),
  CONSTRAINT fk_booking_consultant FOREIGN KEY (consultant_id) REFERENCES consultants(user_id),
  CONSTRAINT fk_booking_service FOREIGN KEY (service_id) REFERENCES services(id),
  CONSTRAINT chk_booking_times CHECK (end_time > start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS booking_status_history (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id  BIGINT UNSIGNED NOT NULL,
  from_status VARCHAR(30) NULL,
  to_status   VARCHAR(30) NOT NULL,
  changed_by  BIGINT UNSIGNED NULL,
  note        VARCHAR(500) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_bsh_booking (booking_id, created_at),
  CONSTRAINT fk_bsh_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT fk_bsh_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_receipts (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id      BIGINT UNSIGNED NOT NULL,
  stored_name     VARCHAR(80) NOT NULL,
  original_name   VARCHAR(255) NOT NULL,
  mime_type       VARCHAR(60) NOT NULL,
  size_bytes      INT UNSIGNED NOT NULL,
  sha256          CHAR(64) NOT NULL,
  amount_expected DECIMAL(12,2) NOT NULL,
  status          ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  uploaded_by     BIGINT UNSIGNED NULL,
  uploaded_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_by     BIGINT UNSIGNED NULL,
  reviewed_at     DATETIME NULL,
  review_note     VARCHAR(500) NULL,
  PRIMARY KEY (id),
  KEY idx_pr_booking (booking_id),
  KEY idx_pr_status (status, uploaded_at),
  KEY idx_pr_hash (sha256),
  CONSTRAINT fk_pr_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT fk_pr_uploader FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_pr_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS meeting_links (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id BIGINT UNSIGNED NOT NULL,
  provider   VARCHAR(20) NOT NULL DEFAULT 'google_meet',
  url        VARCHAR(255) NOT NULL,
  source     ENUM('manual','google_api') NOT NULL DEFAULT 'manual',
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_meeting_booking (booking_id),
  UNIQUE KEY uq_meeting_url (url),            -- one Meet link can never be attached to two bookings
  CONSTRAINT fk_ml_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT fk_ml_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reschedule_requests (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id      BIGINT UNSIGNED NOT NULL,
  requested_by    BIGINT UNSIGNED NULL,
  reason          VARCHAR(500) NOT NULL,
  preferred_date  DATE NULL,
  preferred_time  TIME NULL,
  status          ENUM('pending','approved','rejected','alternative_proposed','accepted','declined') NOT NULL DEFAULT 'pending',
  new_date        DATE NULL,
  new_start_time  TIME NULL,
  decided_by      BIGINT UNSIGNED NULL,
  decided_at      DATETIME NULL,
  decision_note   VARCHAR(500) NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rr_booking (booking_id),
  KEY idx_rr_status (status, created_at),
  CONSTRAINT fk_rr_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT fk_rr_requester FOREIGN KEY (requested_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_rr_decider FOREIGN KEY (decided_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    BIGINT UNSIGNED NOT NULL,
  type       VARCHAR(40) NOT NULL,
  title      VARCHAR(150) NOT NULL,
  message    VARCHAR(500) NOT NULL,
  booking_id BIGINT UNSIGNED NULL,
  is_read    TINYINT(1) NOT NULL DEFAULT 0,
  read_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,   -- also the delivery time for in-portal notifications
  PRIMARY KEY (id),
  KEY idx_notif_user (user_id, is_read, created_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_notif_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_logs (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  actor_id    BIGINT UNSIGNED NULL,
  action      VARCHAR(60) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id   VARCHAR(40) NULL,
  details     TEXT NULL,
  ip_address  VARCHAR(45) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_created (created_at),
  KEY idx_audit_actor (actor_id, created_at),
  KEY idx_audit_entity (entity_type, entity_id),
  CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key   VARCHAR(60) NOT NULL,
  setting_value VARCHAR(500) NOT NULL,
  updated_by    BIGINT UNSIGNED NULL,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
