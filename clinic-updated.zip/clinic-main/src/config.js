'use strict';
require('dotenv').config();

const env = process.env;
const isProd = env.NODE_ENV === 'production';

function required(name) {
  const v = env[name];
  if (!v) throw new Error(`Missing required environment variable ${name} (see .env.example)`);
  return v;
}

const config = {
  isProd,
  port: parseInt(env.PORT || '3000', 10),
  trustProxy: env.TRUST_PROXY || (isProd ? '1' : 'false'),
  db: {
    host: env.DB_HOST || '127.0.0.1',
    port: parseInt(env.DB_PORT || '3306', 10),
    user: required('DB_USER'),
    password: env.DB_PASSWORD || '',
    database: required('DB_NAME'),
    connectionLimit: parseInt(env.DB_POOL_SIZE || '10', 10),
  },
  sessionSecret: required('SESSION_SECRET'),
  sessionHours: parseInt(env.SESSION_HOURS || '8', 10),
  // true | false | 'auto' (default: secure cookie only when the request arrives over HTTPS, so plain-http testing still works)
  cookieSecure: env.COOKIE_SECURE === 'true' ? true : env.COOKIE_SECURE === 'false' ? false : 'auto',
  timezone: env.CLINIC_TIMEZONE || 'Africa/Lagos',
  defaultCountryCode: env.DEFAULT_COUNTRY_CODE || '234',
  tempStaffPassword: env.TEMP_STAFF_PASSWORD || 'theclinic',
  // multiplies rate-limit ceilings (leave at 1 in production; the test suite raises it)
  rateScale: parseInt(env.RATE_LIMIT_SCALE || '1', 10),
  bcryptCost: parseInt(env.BCRYPT_COST || '12', 10),
  uploadDir: env.UPLOAD_DIR || require('path').join(__dirname, '..', 'uploads'),
  maxReceiptBytes: parseInt(env.MAX_RECEIPT_MB || '5', 10) * 1024 * 1024,
  // Google Meet links are deleted this many hours after the consultation is marked done (or after its scheduled end)
  meetLinkHours: parseInt(env.MEET_LINK_RETENTION_HOURS || '3', 10),
  whatsapp: {
    // none | cloud (Meta WhatsApp Business Cloud API) | twilio | callmebot
    provider: (env.WHATSAPP_PROVIDER || 'none').toLowerCase(),
    apiBase: env.WHATSAPP_API_BASE || '',                // override host (used by tests)
    cloudToken: env.WHATSAPP_CLOUD_TOKEN || '', cloudPhoneId: env.WHATSAPP_CLOUD_PHONE_ID || '',
    cloudTemplate: env.WHATSAPP_CLOUD_TEMPLATE || '', cloudTemplateLang: env.WHATSAPP_CLOUD_TEMPLATE_LANG || 'en', cloudVersion: env.WHATSAPP_CLOUD_VERSION || 'v21.0',
    twilioSid: env.TWILIO_ACCOUNT_SID || '', twilioToken: env.TWILIO_AUTH_TOKEN || '', twilioFrom: env.TWILIO_WHATSAPP_FROM || '',
    callmebotKey: env.CALLMEBOT_APIKEY || '',
  },
  maxDocumentBytes: parseInt(env.MAX_DOCUMENT_MB || '10', 10) * 1024 * 1024,
  // how long after a completed consultation the consultant may still open that patient's records
  recordAccessDays: parseInt(env.RECORD_ACCESS_DAYS || '90', 10),
  minBookingLeadMinutes: parseInt(env.MIN_BOOKING_LEAD_MINUTES || '60', 10),
  maxBookingDaysAhead: parseInt(env.MAX_BOOKING_DAYS_AHEAD || '60', 10),
  mail: {
    host: env.SMTP_HOST || '',
    port: parseInt(env.SMTP_PORT || '587', 10),
    secure: env.SMTP_SECURE === 'true',
    user: env.SMTP_USER || '',
    pass: env.SMTP_PASS || '',
    from: env.MAIL_FROM || 'The Clinic <no-reply@example.com>',
  },
  recoveryOtp: env.RECOVERY_OTP_ENABLED === 'true',
  google: {
    clientId: env.GOOGLE_CLIENT_ID || '',
    clientSecret: env.GOOGLE_CLIENT_SECRET || '',
    refreshToken: env.GOOGLE_REFRESH_TOKEN || '',
    calendarId: env.GOOGLE_CALENDAR_ID || 'primary',
  },
};

if (config.sessionSecret.length < 32) {
  throw new Error('SESSION_SECRET must be at least 32 characters. Generate one with: node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"');
}
{
  const w = config.whatsapp;
  w.configured = (w.provider === 'cloud' && !!w.cloudToken && !!w.cloudPhoneId) || (w.provider === 'twilio' && !!w.twilioSid && !!w.twilioToken && !!w.twilioFrom) || (w.provider === 'callmebot' && !!w.callmebotKey);
  if (w.provider !== 'none' && !w.configured) console.warn(`[config] WHATSAPP_PROVIDER=${w.provider} but its credentials are incomplete; alerts will be queued for manual sending.`);
}
config.google.enabled = !!(config.google.clientId && config.google.clientSecret && config.google.refreshToken);
config.mail.enabled = !!config.mail.host;
if (config.recoveryOtp && !config.mail.enabled) {
  console.warn('[config] RECOVERY_OTP_ENABLED=true but SMTP is not configured; email OTP is disabled.');
  config.recoveryOtp = false;
}

module.exports = config;
