'use strict';
const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const config = require('../config');
const { db, tx } = require('../db');
const S = require('../lib/security');
const V = require('../lib/validate');
const T = require('../lib/time');
const sched = require('../lib/schedule');
const sweep = require('../lib/sweep');
const wa = require('../lib/whatsapp');
const meet = require('../lib/googleMeet');
const { audit } = require('../lib/audit');
const { notify, notifyPermission } = require('../lib/notify');
const { requirePerm, requirePortal, can } = require('../middleware/auth');

const router = express.Router();
const { HttpError, bad } = V;

fs.mkdirSync(config.uploadDir, { recursive: true });
const upload = multer({
  storage: multer.diskStorage({ destination: config.uploadDir, filename: (req, f, cb) => cb(null, S.randomToken(16)) }),
  limits: { fileSize: config.maxReceiptBytes, files: 1, fields: 20 },
  fileFilter: (req, f, cb) => (['image/jpeg', 'image/png', 'application/pdf'].includes(f.mimetype) ? cb(null, true)
    : cb(new HttpError(400, 'Receipts must be a JPG, PNG or PDF file.'))),
});

/** Verify real file type from magic bytes (the client-sent MIME type can lie). */
function sniff(file) {
  const fd = fs.openSync(file.path, 'r'); const buf = Buffer.alloc(8); fs.readSync(fd, buf, 0, 8, 0); fs.closeSync(fd);
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.slice(0, 4).toString() === '%PDF') return 'application/pdf';
  return null;
}
const rm = (f) => { if (f && f.path) fs.unlink(f.path, () => {}); };
function runUpload(req, res, next) {
  upload.single('receipt')(req, res, (err) => {
    if (!err) return next();
    if (err.code === 'LIMIT_FILE_SIZE') return next(new HttpError(400, `The receipt is too large. Maximum size is ${config.maxReceiptBytes / 1048576} MB.`));
    next(err instanceof HttpError ? err : new HttpError(400, 'The receipt could not be uploaded.'));
  });
}
async function readReceipt(file) {
  if (!file) throw bad('Please upload your payment receipt (JPG, PNG or PDF).');
  const mime = sniff(file);
  if (!mime) throw bad('The uploaded file is not a valid JPG, PNG or PDF.');
  const sha = S.sha256(fs.readFileSync(file.path));
  return { stored: path.basename(file.path), original: String(file.originalname || 'receipt').replace(/[^\w.\- ]/g, '_').slice(0, 200), mime, size: file.size, sha };
}

// ---------- shaping ----------
const BASE_SELECT = `
  SELECT b.*, pu.full_name AS patient_name, pu.phone AS patient_phone, pp.patient_code,
         cu.full_name AS consultant_name, ml.url AS meet_url,
         pr.id AS receipt_id, pr.status AS payment_status, pr.review_note AS payment_note
    FROM bookings b
    JOIN users pu ON pu.id = b.patient_id
    JOIN patient_profiles pp ON pp.user_id = b.patient_id
    JOIN users cu ON cu.id = b.consultant_id
    LEFT JOIN meeting_links ml ON ml.booking_id = b.id
    LEFT JOIN payment_receipts pr ON pr.id = (SELECT MAX(id) FROM payment_receipts WHERE booking_id = b.id)`;

function viewerKind(user, b) {
  if (user.id === b.patient_id) return 'patient';
  if (user.id === b.consultant_id && user.isConsultant) return 'consultant';   // only while acting in the Consultant role
  if (can(user, 'bookings.view_all') || can(user, 'payments.verify') || can(user, 'meet.manage')) return 'staff';
  return null;
}
/**
 * Consultation privacy: the Meet link and the patient's own note are visible ONLY to the patient and the consultant
 * assigned to the booking. Staff (including the Owner) manage scheduling/payments but never see the join link.
 */
function shape(b, user) {
  const kind = viewerKind(user, b);
  const party = kind === 'patient' || kind === 'consultant';
  const showMeet = party && ['confirmed', 'reschedule_requested', 'completed'].includes(b.status);
  const today = T.nowLocal().date;
  const out = {
    id: b.id, code: b.booking_code, status: b.status, date: b.appointment_date, viewer: kind,
    startTime: b.start_time.slice(0, 5), endTime: b.end_time.slice(0, 5),
    serviceId: b.service_id, serviceName: b.service_name, fee: Number(b.fee_amount),
    patientId: b.patient_id, patientName: b.patient_name, patientCode: b.patient_code,
    consultantId: b.consultant_id, consultantName: b.consultant_name,
    note: party ? b.patient_note : null, createdAt: T.iso(b.created_at),
    paymentStatus: b.payment_status || null, paymentNote: b.payment_status === 'rejected' ? b.payment_note : null,
    hasMeetLink: !!b.meet_url, meetUrl: showMeet ? b.meet_url : null,
    overdue: ['requested', 'confirmed', 'reschedule_requested'].includes(b.status) && b.appointment_date < today,
  };
  if (kind === 'staff' || kind === 'consultant') out.patientPhone = b.patient_phone;
  return out;
}

/** Which "hat" a request is made with: patient, consultant (own consultations only) or staff (needs bookings.view_all). */
function scopeFor(u, as, where, args) {
  const mode = as || (u.portals.includes('patient') ? 'patient' : 'staff');
  if (mode === 'patient') { if (!u.portals.includes('patient')) throw new HttpError(403, 'Not a patient account.'); where.push('b.patient_id=?'); args.push(u.id); }
  else if (mode === 'consultant') { if (!u.isConsultant) throw new HttpError(403, 'You are not a consultant.'); where.push('b.consultant_id=?'); args.push(u.id); }
  else if (mode === 'staff') { if (!can(u, 'bookings.view_all')) throw new HttpError(403, 'You do not have permission to view all bookings.'); }
  else throw bad('Invalid view.');
  return mode;
}

// ---------- list ----------
router.get('/bookings', async (req, res, next) => {
  try {
    await sweep.markMissed(); await sweep.expireMeetLinks();
    const u = req.user; const q = req.query; const today = T.nowLocal().date;
    const where = []; const args = [];
    const mode = scopeFor(u, q.as, where, args);

    const scope = q.scope || 'all'; let desc = false;
    const ACT = "('requested','confirmed','reschedule_requested')";
    const TERM = "('completed','cancelled','rejected','missed')";
    if (scope === 'today') { where.push('b.appointment_date=?'); args.push(today); }
    else if (scope === 'upcoming') { where.push(`b.appointment_date>? AND b.status IN ${ACT}`); args.push(today); }
    else if (scope === 'history') { where.push(`(b.appointment_date<? OR (b.appointment_date>? AND b.status IN ${TERM}))`); args.push(today, today); desc = true; }
    else if (scope === 'attention') { where.push(`(b.status IN ('requested','reschedule_requested','missed'))`); }
    else if (scope !== 'all') throw bad('Invalid scope.');
    if (q.status) { if (!['requested', 'confirmed', 'reschedule_requested', 'completed', 'cancelled', 'missed', 'rejected'].includes(q.status)) throw bad('Invalid status.'); where.push('b.status=?'); args.push(q.status); }
    if (q.consultantId && mode === 'staff') { where.push('b.consultant_id=?'); args.push(V.int(q.consultantId, { field: 'Consultant' })); }
    if (q.serviceId) { where.push('b.service_id=?'); args.push(V.int(q.serviceId, { field: 'Service' })); }
    if (q.from && T.isValidDate(q.from)) { where.push('b.appointment_date>=?'); args.push(q.from); }
    if (q.to && T.isValidDate(q.to)) { where.push('b.appointment_date<=?'); args.push(q.to); }
    if (q.q && mode !== 'patient') {
      const like = `%${String(q.q).trim().slice(0, 60).replace(/[%_\\]/g, '\\$&')}%`;
      where.push('(pu.full_name LIKE ? OR pp.patient_code LIKE ? OR b.booking_code LIKE ?)'); args.push(like, like, like);
    }
    const limit = Math.min(parseInt(q.limit || '200', 10) || 200, 500);
    const [rows] = await db.query(
      `${BASE_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
        ORDER BY b.appointment_date ${desc ? 'DESC' : 'ASC'}, b.start_time ASC, b.created_at ASC, b.id ASC LIMIT ?`, [...args, limit]);
    res.json({ bookings: rows.map((b) => shape(b, u)), today });
  } catch (e) { next(e); }
});

router.get('/stats', requirePerm('bookings.view_all'), async (req, res, next) => {
  try {
    await sweep.markMissed();
    const today = T.nowLocal().date;
    const [[s]] = await db.query(
      `SELECT SUM(appointment_date=? AND status<>'rejected') today, SUM(status='requested') pendingPayments,
              SUM(status='reschedule_requested') pendingReschedules, SUM(status='missed') missed,
              SUM(status='confirmed' AND appointment_date>?) upcoming FROM bookings`, [today, today]);
    res.json({ today: Number(s.today || 0), pendingPayments: Number(s.pendingPayments || 0), pendingReschedules: Number(s.pendingReschedules || 0),
      missed: Number(s.missed || 0), upcoming: Number(s.upcoming || 0) });
  } catch (e) { next(e); }
});

async function fetchBooking(c, id, user, { lock = false } = {}) {
  if (lock) await c.query('SELECT id FROM bookings WHERE id=? FOR UPDATE', [id]); // lock first, then read the fresh row
  const [rows] = await c.query(`${BASE_SELECT} WHERE b.id=?`, [id]);
  const b = rows[0];
  if (!b || !viewerKind(user, b)) throw new HttpError(404, 'Booking not found.');
  return b;
}

router.get('/bookings/:id', async (req, res, next) => {
  try {
    await sweep.markMissed(); await sweep.expireMeetLinks();
    const id = V.int(req.params.id, { field: 'Booking' });
    const b = await fetchBooking(db, id, req.user);
    const kind = viewerKind(req.user, b);
    const [hist] = await db.query(
      `SELECT h.from_status, h.to_status, h.note, h.created_at, u.full_name AS by_name FROM booking_status_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.booking_id=? ORDER BY h.id`, [id]);
    const [rr] = await db.query(
      `SELECT r.id, r.reason, r.status, r.preferred_date, r.preferred_time, r.new_date, r.new_start_time, r.decision_note, r.created_at, r.decided_at, u.full_name AS decided_by
         FROM reschedule_requests r LEFT JOIN users u ON u.id=r.decided_by WHERE r.booking_id=? ORDER BY r.id DESC`, [id]);
    let receipts = [];
    if (kind === 'patient' || can(req.user, 'payments.verify') || can(req.user, 'bookings.view_all')) {
      const [r] = await db.query(
        `SELECT pr.id, pr.original_name, pr.mime_type, pr.size_bytes, pr.amount_expected, pr.status, pr.uploaded_at, pr.reviewed_at, pr.review_note, u.full_name AS reviewer
           FROM payment_receipts pr LEFT JOIN users u ON u.id=pr.reviewed_by WHERE pr.booking_id=? ORDER BY pr.id DESC`, [id]);
      receipts = r.map((x) => ({ id: x.id, name: x.original_name, mime: x.mime_type, size: x.size_bytes, amount: Number(x.amount_expected), status: x.status,
        uploadedAt: T.iso(x.uploaded_at), reviewedAt: T.iso(x.reviewed_at), note: x.review_note, reviewer: x.reviewer }));
    }
    res.json({
      booking: shape(b, req.user),
      history: hist.map((h) => ({ from: h.from_status, to: h.to_status, note: h.note, by: h.by_name, at: T.iso(h.created_at) })),
      reschedules: rr.map((r) => ({ id: r.id, reason: r.reason, status: r.status, preferredDate: r.preferred_date, preferredTime: r.preferred_time && r.preferred_time.slice(0, 5),
        newDate: r.new_date, newStartTime: r.new_start_time && r.new_start_time.slice(0, 5), note: r.decision_note, decidedBy: r.decided_by, createdAt: T.iso(r.created_at), decidedAt: T.iso(r.decided_at) })),
      receipts,
    });
  } catch (e) { next(e); }
});

async function history(c, bookingId, from, to, userId, note) {
  await c.query('INSERT INTO booking_status_history (booking_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)', [bookingId, from, to, userId, note ? String(note).slice(0, 500) : null]);
}
const when = (b) => `${b.appointment_date || b.date} ${(b.start_time || b.startTime).slice(0, 5)}`;

// ---------- create booking (patient) ----------
router.post('/bookings', requirePortal('patient'), runUpload, async (req, res, next) => {
  const file = req.file;
  try {
    const b = req.body || {};
    const serviceId = V.int(b.serviceId, { field: 'Service' });
    const consultantId = V.int(b.consultantId, { field: 'Consultant' });
    const date = String(b.date || ''); const startTime = T.normTime(String(b.startTime || ''));
    if (!T.isValidDate(date) || !startTime) throw bad('Please choose a valid date and time.');
    if (date > T.addDays(T.nowLocal().date, config.maxBookingDaysAhead)) throw bad(`Bookings can only be made up to ${config.maxBookingDaysAhead} days ahead.`);
    const note = V.str(b.note, { max: 500, field: 'Note', required: false });
    const rc = await readReceipt(file);

    let created;
    try {
      created = await tx(async (c) => {
        const [[svc]] = await c.query('SELECT id, name, fee FROM services WHERE id=? AND active=1', [serviceId]);
        if (!svc) throw bad('That service is not available.');
        const [[cons]] = await c.query(
          `SELECT c.user_id, u.full_name FROM consultants c JOIN users u ON u.id=c.user_id WHERE c.user_id=? AND u.status='active' AND c.accepting_bookings=1 FOR UPDATE`, [consultantId]);
        if (!cons) throw bad('That consultant is not available.');   // row lock serialises concurrent bookings per consultant
        const slot = await sched.findBookableSlot(c, consultantId, date, startTime, { forUpdate: true });
        if (!slot) throw new HttpError(409, 'Sorry, that time is no longer available. Please choose another slot.');

        const [[mine]] = await c.query(
          `SELECT SUM(status='requested') pending,
                  SUM(appointment_date=? AND start_time < ? AND end_time > ? AND status IN ('requested','confirmed','reschedule_requested')) clash
             FROM bookings WHERE patient_id=?`, [date, slot.endTime, slot.startTime, req.user.id]);
        if (Number(mine.clash || 0) > 0) throw new HttpError(409, 'You already have a consultation booked at that time.');
        if (Number(mine.pending || 0) >= 3) throw new HttpError(429, 'You have several requests awaiting payment verification. Please wait for them to be reviewed.');

        let code; let r;
        for (let i = 0; i < 5 && !r; i++) {
          code = `BK-${date.replace(/-/g, '')}-${S.randomToken(3).toUpperCase()}`;
          try {
            [r] = await c.query(
              `INSERT INTO bookings (booking_code, patient_id, consultant_id, service_id, service_name, fee_amount, appointment_date, start_time, end_time, status, patient_note)
               VALUES (?,?,?,?,?,?,?,?,?, 'requested', ?)`,
              [code, req.user.id, consultantId, svc.id, svc.name, svc.fee, date, slot.startTime, slot.endTime, note]);
          } catch (e) {
            if (e.code === 'ER_DUP_ENTRY' && /uq_booking_code/.test(e.message)) continue;
            throw e;
          }
        }
        if (!r) throw new Error('Could not allocate booking code');
        await c.query(
          'INSERT INTO payment_receipts (booking_id, stored_name, original_name, mime_type, size_bytes, sha256, amount_expected, uploaded_by) VALUES (?,?,?,?,?,?,?,?)',
          [r.insertId, rc.stored, rc.original, rc.mime, rc.size, rc.sha, svc.fee, req.user.id]);
        await history(c, r.insertId, null, 'requested', req.user.id, 'Booking request and payment receipt submitted');
        const text = `${req.user.fullName} requested ${svc.name} with ${cons.full_name} on ${date} at ${startTime.slice(0, 5)}.`;
        await notifyPermission(c, 'payments.verify', 'booking_request', 'New booking awaiting payment verification', text, r.insertId);
        await notify(c, consultantId, 'booking_request', 'New booking request', text + ' It will be confirmed after payment is verified.', r.insertId);
        await notify(c, req.user.id, 'booking_request', 'Booking request received', `Your request ${code} is awaiting payment verification.`, r.insertId);
        const [[pp]] = await c.query('SELECT patient_code FROM patient_profiles WHERE user_id=?', [req.user.id]);
        await wa.enqueue(c, 'booking', r.insertId, wa.bookingText({ patientName: req.user.fullName, patientCode: pp.patient_code, serviceName: svc.name, fee: svc.fee, consultantName: cons.full_name, date, startTime: slot.startTime, code }));
        return { id: r.insertId, code };
      });
    } catch (e) {
      if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Sorry, that time was just taken. Please choose another slot.');
      throw e;
    }
    wa.flushSoon();
    res.status(201).json({ ok: true, ...created });
  } catch (e) { rm(file); next(e); }
});

// ---------- receipts ----------
router.post('/bookings/:id/receipt', requirePortal('patient'), runUpload, async (req, res, next) => {
  const file = req.file;
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const rc = await readReceipt(file);
    await tx(async (c) => {
      const b = await fetchBooking(c, id, req.user, { lock: true });
      if (b.patient_id !== req.user.id) throw new HttpError(404, 'Booking not found.');
      if (b.status !== 'requested') throw bad('A receipt can only be replaced while the booking is awaiting payment verification.');
      await c.query("UPDATE payment_receipts SET status='rejected', reviewed_at=UTC_TIMESTAMP(), review_note='Replaced by a newer upload' WHERE booking_id=? AND status='pending'", [id]);
      await c.query('INSERT INTO payment_receipts (booking_id, stored_name, original_name, mime_type, size_bytes, sha256, amount_expected, uploaded_by) VALUES (?,?,?,?,?,?,?,?)',
        [id, rc.stored, rc.original, rc.mime, rc.size, rc.sha, b.fee_amount, req.user.id]);
      await history(c, id, 'requested', 'requested', req.user.id, 'New payment receipt uploaded');
      await notifyPermission(c, 'payments.verify', 'receipt_uploaded', 'Receipt re-uploaded', `${b.patient_name} uploaded a new receipt for ${b.booking_code}.`, id);
    });
    res.json({ ok: true });
  } catch (e) { rm(file); next(e); }
});

router.get('/receipts/:id', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Receipt' });
    const [[r]] = await db.query(
      `SELECT pr.*, b.patient_id FROM payment_receipts pr JOIN bookings b ON b.id=pr.booking_id WHERE pr.id=?`, [id]);
    if (!r || !(req.user.id === r.patient_id || can(req.user, 'payments.verify'))) throw new HttpError(404, 'Receipt not found.');
    const file = path.join(config.uploadDir, path.basename(r.stored_name));
    if (!fs.existsSync(file)) throw new HttpError(404, 'Receipt file is missing.');
    res.set({ 'Content-Type': r.mime_type, 'Content-Disposition': `inline; filename="receipt-${id}"`, 'Cache-Control': 'private, no-store',
      'Content-Security-Policy': "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox" });
    if (can(req.user, 'payments.verify') && req.user.id !== r.patient_id) await audit(null, req, 'receipt.view', 'receipt', id, null);
    fs.createReadStream(file).pipe(res);
  } catch (e) { next(e); }
});

router.get('/payments', requirePerm('payments.verify'), async (req, res, next) => {
  try {
    const status = ['pending', 'approved', 'rejected'].includes(req.query.status) ? req.query.status : 'pending';
    const [rows] = await db.query(
      `SELECT pr.id, pr.status, pr.original_name, pr.mime_type, pr.amount_expected, pr.uploaded_at, pr.reviewed_at, pr.review_note, ru.full_name AS reviewer,
              b.id AS booking_id, b.booking_code, b.service_name, b.appointment_date, b.start_time, b.status AS booking_status, b.fee_amount,
              pu.full_name AS patient_name, cu.full_name AS consultant_name,
              (SELECT COUNT(*) FROM payment_receipts x WHERE x.sha256=pr.sha256 AND x.id<>pr.id) AS duplicate_hash
         FROM payment_receipts pr JOIN bookings b ON b.id=pr.booking_id JOIN users pu ON pu.id=b.patient_id JOIN users cu ON cu.id=b.consultant_id
         LEFT JOIN users ru ON ru.id=pr.reviewed_by
        WHERE pr.status=? AND pr.id = (SELECT MAX(id) FROM payment_receipts WHERE booking_id=b.id)
        ORDER BY ${status === 'pending' ? 'pr.uploaded_at ASC' : 'pr.reviewed_at DESC'} LIMIT 200`, [status]);
    res.json({ payments: rows.map((r) => ({ receiptId: r.id, status: r.status, fileName: r.original_name, mime: r.mime_type, amount: Number(r.amount_expected),
      uploadedAt: T.iso(r.uploaded_at), reviewedAt: T.iso(r.reviewed_at), note: r.review_note, reviewer: r.reviewer,
      bookingId: r.booking_id, code: r.booking_code, serviceName: r.service_name, date: r.appointment_date, startTime: r.start_time.slice(0, 5),
      bookingStatus: r.booking_status, patientName: r.patient_name, consultantName: r.consultant_name,
      possibleDuplicateReceipt: r.duplicate_hash > 0, overdue: r.booking_status === 'requested' && r.appointment_date < T.nowLocal().date })) });
  } catch (e) { next(e); }
});

router.post('/bookings/:id/payment', requirePerm('payments.verify'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const decision = req.body.decision;
    if (!['approve', 'reject'].includes(decision)) throw bad('Decision must be approve or reject.');
    const note = V.str(req.body.note, { max: 500, field: 'Note', required: decision === 'reject' });
    if (decision === 'approve' && req.body.amountConfirmed !== true) throw bad('Please confirm that the receipt amount matches the consultation fee.');
    await tx(async (c) => {
      const b = await fetchBooking(c, id, req.user, { lock: true });
      if (b.status !== 'requested' || b.payment_status !== 'pending') throw new HttpError(409, 'This payment has already been reviewed.');
      if (decision === 'approve') {
        const n = T.nowLocal();
        if (b.appointment_date < n.date || (b.appointment_date === n.date && b.end_time <= n.time))
          throw bad('This appointment time has already passed. Arrange a new date for the patient, or reject the request.');
        await c.query("UPDATE payment_receipts SET status='approved', reviewed_by=?, reviewed_at=UTC_TIMESTAMP(), review_note=? WHERE id=?", [req.user.id, note, b.receipt_id]);
        await c.query("UPDATE bookings SET status='confirmed' WHERE id=?", [id]);
        await history(c, id, 'requested', 'confirmed', req.user.id, 'Payment verified' + (note ? `: ${note}` : ''));
        await notify(c, b.patient_id, 'payment_approved', 'Payment confirmed', `Payment for ${b.booking_code} was verified. Your consultation on ${when(b)} is confirmed. Your meeting link will appear in your portal.`, id);
        await notify(c, b.consultant_id, 'booking_confirmed', 'Booking confirmed', `${b.patient_name} — ${b.service_name} on ${when(b)} is confirmed.`, id);
        await notifyPermission(c, 'meet.manage', 'meet_needed', 'Meet link needed', `Booking ${b.booking_code} (${when(b)}) is confirmed and needs a Google Meet link.`, id, req.user.id);
        await audit(c, req, 'payment.approve', 'booking', id, { receipt: b.receipt_id, fee: Number(b.fee_amount) });
      } else {
        await c.query("UPDATE payment_receipts SET status='rejected', reviewed_by=?, reviewed_at=UTC_TIMESTAMP(), review_note=? WHERE id=?", [req.user.id, note, b.receipt_id]);
        await c.query("UPDATE bookings SET status='rejected' WHERE id=?", [id]);
        await history(c, id, 'requested', 'rejected', req.user.id, `Payment rejected: ${note}`);
        await notify(c, b.patient_id, 'payment_rejected', 'Payment could not be verified', `Payment for ${b.booking_code} was rejected: ${note}. The time slot has been released; you may book again.`, id);
        await notify(c, b.consultant_id, 'booking_rejected', 'Booking request declined', `Request ${b.booking_code} (${when(b)}) was not approved.`, id);
        await audit(c, req, 'payment.reject', 'booking', id, { receipt: b.receipt_id, reason: note });
      }
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- Google Meet link ----------
router.put('/bookings/:id/meet', requirePerm('meet.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const url = V.parseMeetLink(req.body.url);
    if (!url) throw bad('Please enter a valid Google Meet link, e.g. https://meet.google.com/abc-defg-hij');
    await saveMeet(req, id, url, 'manual');
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/bookings/:id/meet/generate', requirePerm('meet.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const b = await fetchBooking(db, id, req.user);
    if (b.status !== 'confirmed') throw bad('A Meet link can only be created for a confirmed booking.');
    const link = await meet.createMeetLink({ summary: 'The Clinic consultation', date: b.appointment_date, startTime: b.start_time, endTime: b.end_time, bookingCode: b.booking_code });
    const url = V.parseMeetLink(link);
    if (!url) throw new HttpError(502, 'Google returned an unexpected link. Please paste one manually.');
    await saveMeet(req, id, url, 'google_api');
    res.json({ ok: true });
  } catch (e) { next(e); }
});

async function saveMeet(req, id, url, source) {
  try {
    await tx(async (c) => {
      const b = await fetchBooking(c, id, req.user, { lock: true });
      if (b.status !== 'confirmed') throw bad('A Meet link can only be added to a confirmed (payment-verified) booking.');
      const [[taken]] = [await c.query('SELECT booking_id FROM meeting_links WHERE url=?', [url]).then((x) => [x[0][0] || null])];
      if (taken && taken.booking_id !== id) throw new HttpError(409, 'That Meet link is already attached to another booking. Please use a separate link per consultation.');
      if (b.meet_url) await c.query('UPDATE meeting_links SET url=?, source=?, created_by=? WHERE booking_id=?', [url, source, req.user.id, id]);
      else await c.query('INSERT INTO meeting_links (booking_id, url, source, created_by) VALUES (?,?,?,?)', [id, url, source, req.user.id]);
      const text = `The Google Meet link for ${b.booking_code} (${when(b)}) is now available in your portal.`;
      await notify(c, b.patient_id, 'meet_link', 'Your consultation link is ready', text, id);
      await notify(c, b.consultant_id, 'meet_link', 'Consultation link added', text, id);
      await audit(c, req, b.meet_url ? 'meet.update' : 'meet.add', 'booking', id, { source });
    });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That Meet link is already attached to another booking. Please use a separate link per consultation.');
    throw e;
  }
}

router.delete('/bookings/:id/meet', requirePerm('meet.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    await fetchBooking(db, id, req.user);
    await db.query('DELETE FROM meeting_links WHERE booking_id=?', [id]);
    await audit(null, req, 'meet.remove', 'booking', id, null);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- status changes ----------
router.post('/bookings/:id/status', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const to = req.body.status;
    if (!['completed', 'missed', 'cancelled'].includes(to)) throw bad('Invalid status.');
    const note = V.str(req.body.note, { max: 500, field: 'Note', required: to === 'cancelled' && req.user.portal !== 'patient' });
    await tx(async (c) => {
      const b = await fetchBooking(c, id, req.user, { lock: true });
      const kind = viewerKind(req.user, b);
      const staffOK = can(req.user, 'bookings.manage');
      const n = T.nowLocal();
      const started = b.appointment_date < n.date || (b.appointment_date === n.date && b.start_time <= n.time);
      const ended = b.appointment_date < n.date || (b.appointment_date === n.date && b.end_time <= n.time);
      if (to === 'cancelled') {
        const allowed = kind === 'patient' ? ['requested', 'confirmed', 'reschedule_requested'].includes(b.status) && !started
          : (kind === 'consultant' || staffOK) && ['requested', 'confirmed', 'reschedule_requested', 'missed'].includes(b.status);
        if (!allowed || (kind === 'staff' && !staffOK)) throw new HttpError(403, kind === 'patient' ? 'This booking can no longer be cancelled online. Please contact the clinic.' : 'You cannot cancel this booking.');
      } else {
        const own = kind === 'consultant' || (kind === 'staff' && staffOK);
        if (!own) throw new HttpError(403, 'Only the assigned consultant or authorised staff can do that.');
        if (to === 'completed' && (!['confirmed', 'missed'].includes(b.status) || !started)) throw bad('Only a confirmed consultation that has started can be marked completed.');
        if (to === 'missed' && (b.status !== 'confirmed' || !ended)) throw bad('Only a confirmed consultation whose time has passed can be marked as not consulted.');
      }
      await c.query(to === 'completed' ? 'UPDATE bookings SET status=?, completed_at=UTC_TIMESTAMP() WHERE id=?' : 'UPDATE bookings SET status=? WHERE id=?', [to, id]);
      await c.query("UPDATE reschedule_requests SET status='rejected', decided_at=UTC_TIMESTAMP(), decision_note='Booking status changed' WHERE booking_id=? AND status IN ('pending','alternative_proposed')", [id]);
      await history(c, id, b.status, to, req.user.id, note);
      const label = { completed: 'completed', missed: 'marked as not consulted', cancelled: 'cancelled' }[to];
      const msg = to === 'completed' ? `Consultation ${b.booking_code} (${when(b)}) is done. The meeting link is removed automatically after ${config.meetLinkHours} hours.`
        : to === 'missed' ? `Booking ${b.booking_code} (${when(b)}) was marked as not consulted. The patient can request a reschedule.`
        : `Booking ${b.booking_code} (${when(b)}) was ${label}${to === 'cancelled' && note ? `: ${note}` : '.'}`;
      if (req.user.id !== b.patient_id) await notify(c, b.patient_id, `booking_${to}`, `Booking ${label}`, msg, id);
      if (req.user.id !== b.consultant_id) await notify(c, b.consultant_id, `booking_${to}`, `Booking ${label}`, msg, id);
      if (to !== 'completed') await notifyPermission(c, 'bookings.manage', `booking_${to}`, `Booking ${label}`, msg, id, req.user.id);
      await audit(c, req, `booking.${to}`, 'booking', id, { from: b.status, note });
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/bookings/:id/message', requirePerm('bookings.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const message = V.str(req.body.message, { min: 2, max: 400, field: 'Message' });
    const b = await fetchBooking(db, id, req.user);
    await notify(null, b.patient_id, 'staff_message', 'Message from the clinic', `${b.booking_code}: ${message}`, id);
    await audit(null, req, 'booking.message', 'booking', id, null);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- move a booking to a new slot (missed / reschedule / admin) ----------
async function moveBooking(c, req, b, date, startTime, note, newStatus) {
  const slot = await sched.findBookableSlot(c, b.consultant_id, date, startTime, { excludeBookingId: b.id, forUpdate: true });
  if (!slot) throw new HttpError(409, 'That time is not available in the consultant\'s schedule.');
  const nextStatus = newStatus || (b.status === 'requested' ? 'requested' : 'confirmed');
  await c.query('UPDATE bookings SET appointment_date=?, start_time=?, end_time=?, status=?, reminder_sent_at=NULL WHERE id=?', [date, slot.startTime, slot.endTime, nextStatus, b.id]);
  await history(c, b.id, b.status, nextStatus, req.user.id, `Moved from ${when(b)} to ${date} ${slot.startTime.slice(0, 5)}${note ? `: ${note}` : ''}`);
  const [lk] = await c.query('SELECT 1 FROM meeting_links WHERE booking_id=?', [b.id]);
  if (!lk.length && nextStatus === 'confirmed') await notifyPermission(c, 'meet.manage', 'meet_needed', 'Meet link needed', `Booking ${b.booking_code} was moved to ${date} ${slot.startTime.slice(0, 5)} and needs a new Google Meet link.`, b.id, req.user.id);
  return { slot, status: nextStatus };
}

router.post('/bookings/:id/arrange', requirePerm('bookings.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const date = String(req.body.date || ''); const start = T.normTime(String(req.body.startTime || ''));
    if (!T.isValidDate(date) || !start) throw bad('Please choose a valid date and time.');
    const note = V.str(req.body.note, { max: 300, field: 'Note', required: false });
    try {
      await tx(async (c) => {
        const b = await fetchBooking(c, id, req.user, { lock: true });
        if (!['requested', 'confirmed', 'reschedule_requested', 'missed'].includes(b.status)) throw bad('This booking cannot be rescheduled.');
        await c.query('SELECT user_id FROM consultants WHERE user_id=? FOR UPDATE', [b.consultant_id]);
        const m = await moveBooking(c, req, b, date, start, note);
        await c.query("UPDATE reschedule_requests SET status='approved', new_date=?, new_start_time=?, decided_by=?, decided_at=UTC_TIMESTAMP(), decision_note=? WHERE booking_id=? AND status IN ('pending','alternative_proposed')",
          [date, m.slot.startTime, req.user.id, note, id]);
        const text = `Booking ${b.booking_code} has been moved to ${date} at ${m.slot.startTime.slice(0, 5)}.${note ? ' ' + note : ''}`;
        await notify(c, b.patient_id, 'rescheduled', 'Consultation rescheduled', text, id);
        await notify(c, b.consultant_id, 'rescheduled', 'Consultation rescheduled', text, id);
        await audit(c, req, 'booking.arrange', 'booking', id, { date, start });
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That time was just taken.'); throw e; }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- reschedule requests ----------
router.post('/bookings/:id/reschedule', requirePortal('patient'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Booking' });
    const reason = V.str(req.body.reason, { min: 5, max: 500, field: 'Reason' });
    let pd = null; let pt = null;
    if (req.body.preferredDate) { if (!T.isValidDate(req.body.preferredDate)) throw bad('Invalid preferred date.'); pd = req.body.preferredDate; }
    if (req.body.preferredTime) { pt = T.normTime(req.body.preferredTime); if (!pt) throw bad('Invalid preferred time.'); }
    await tx(async (c) => {
      const b = await fetchBooking(c, id, req.user, { lock: true });
      if (b.patient_id !== req.user.id) throw new HttpError(404, 'Booking not found.');
      if (!['confirmed', 'missed'].includes(b.status)) throw bad('Only confirmed bookings, or consultations that were not held, can be rescheduled.');
      const notHeld = b.status === 'missed';
      if (!notHeld && !T.isFutureEnough(b.appointment_date, b.start_time, 0)) throw bad('This appointment has already started or passed. Please contact the clinic.');
      const [[pend]] = await c.query("SELECT COUNT(*) n FROM reschedule_requests WHERE booking_id=? AND status IN ('pending','alternative_proposed')", [id]);
      if (pend.n) throw bad('You already have a reschedule request waiting for a decision.');
      await c.query('INSERT INTO reschedule_requests (booking_id, requested_by, reason, preferred_date, preferred_time) VALUES (?,?,?,?,?)', [id, req.user.id, reason, pd, pt]);
      // a "not consulted" booking stays that way until staff approve a new time
      if (!notHeld) await c.query("UPDATE bookings SET status='reschedule_requested' WHERE id=?", [id]);
      await history(c, id, b.status, notHeld ? 'missed' : 'reschedule_requested', req.user.id, `Reschedule requested: ${reason}`);
      const text = `${b.patient_name} asked to reschedule ${notHeld ? 'a consultation that was not held' : ''} ${b.booking_code} (${when(b)}): ${reason}`.replace(/\s+/g, ' ');
      await notify(c, b.consultant_id, 'reschedule_request', 'Reschedule request', text, id);
      await notifyPermission(c, 'reschedule.review', 'reschedule_request', 'Reschedule request', text, id);
      const [[pp]] = await c.query('SELECT patient_code FROM patient_profiles WHERE user_id=?', [req.user.id]);
      await wa.enqueue(c, 'reschedule', id, wa.rescheduleText({ patientName: b.patient_name, patientCode: pp.patient_code, code: b.booking_code, notHeld, date: b.appointment_date, startTime: b.start_time, preferredDate: pd, preferredTime: pt }));
      await audit(c, req, 'reschedule.request', 'booking', id, null);
    });
    wa.flushSoon();
    res.status(201).json({ ok: true });
  } catch (e) { next(e); }
});

router.get('/reschedules', async (req, res, next) => {
  try {
    const u = req.user; const where = []; const args = [];
    const as = req.query.as || (u.portals.includes('patient') ? 'patient' : 'staff');
    if (as === 'staff' && !can(u, 'reschedule.review')) throw new HttpError(403, 'You do not have permission to view reschedule requests.');
    if (as === 'staff') { /* all requests */ } else scopeFor(u, as, where, args);
    const st = req.query.status === 'open' || !req.query.status ? "r.status IN ('pending','alternative_proposed')" : 'r.status = ?';
    if (st.includes('?')) args.push(req.query.status);
    where.push(st);
    const [rows] = await db.query(
      `SELECT r.*, b.booking_code, b.appointment_date, b.start_time, b.service_name, b.consultant_id, pu.full_name AS patient_name, cu.full_name AS consultant_name
         FROM reschedule_requests r JOIN bookings b ON b.id=r.booking_id JOIN users pu ON pu.id=b.patient_id JOIN users cu ON cu.id=b.consultant_id
        WHERE ${where.join(' AND ')} ORDER BY r.created_at ASC LIMIT 200`, args);
    res.json({ requests: rows.map((r) => ({ id: r.id, bookingId: r.booking_id, code: r.booking_code, date: r.appointment_date, startTime: r.start_time.slice(0, 5),
      serviceName: r.service_name, patientName: r.patient_name, consultantId: r.consultant_id, consultantName: r.consultant_name, reason: r.reason,
      preferredDate: r.preferred_date, preferredTime: r.preferred_time && r.preferred_time.slice(0, 5), status: r.status,
      newDate: r.new_date, newStartTime: r.new_start_time && r.new_start_time.slice(0, 5), note: r.decision_note, createdAt: T.iso(r.created_at) })) });
  } catch (e) { next(e); }
});

router.post('/reschedules/:id/decision', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Request' });
    const decision = req.body.decision;
    if (!['approve', 'reject', 'propose'].includes(decision)) throw bad('Invalid decision.');
    const note = V.str(req.body.note, { max: 500, field: 'Note', required: decision === 'reject' });
    let date = null; let start = null;
    if (decision !== 'reject') {
      date = String(req.body.newDate || ''); start = T.normTime(String(req.body.newStartTime || ''));
      if (!T.isValidDate(date) || !start) throw bad('Please choose the new date and time.');
    }
    try {
      await tx(async (c) => {
        const [[r]] = await c.query('SELECT * FROM reschedule_requests WHERE id=? FOR UPDATE', [id]);
        if (!r) throw new HttpError(404, 'Request not found.');
        const b = await fetchBooking(c, r.booking_id, req.user, { lock: true });
        const kind = viewerKind(req.user, b);
        const reviewer = can(req.user, 'reschedule.review');
        if (!(kind === 'consultant' || (kind === 'staff' && reviewer))) throw new HttpError(403, 'You cannot review this request.');
        if (b.status === 'missed' && !reviewer) throw new HttpError(403, 'Only the owner, administrators or support staff can approve a new time for a consultation that was not held.');
        if (!['pending', 'alternative_proposed'].includes(r.status)) throw new HttpError(409, 'This request has already been decided.');
        await c.query('SELECT user_id FROM consultants WHERE user_id=? FOR UPDATE', [b.consultant_id]);
        let text;
        if (decision === 'reject') {
          await c.query("UPDATE reschedule_requests SET status='rejected', decided_by=?, decided_at=UTC_TIMESTAMP(), decision_note=? WHERE id=?", [req.user.id, note, id]);
          const back = b.status === 'reschedule_requested' ? 'confirmed' : b.status;   // "not consulted" stays "not consulted"
          if (back !== b.status) await c.query('UPDATE bookings SET status=? WHERE id=?', [back, b.id]);
          await history(c, b.id, b.status, back, req.user.id, `Reschedule declined: ${note}`);
          text = back === 'confirmed' ? `Your reschedule request for ${b.booking_code} was declined: ${note}. Your original appointment (${when(b)}) stands.` : `Your reschedule request for ${b.booking_code} was declined: ${note}. Please contact the clinic.`;
        } else if (decision === 'approve') {
          const m = await moveBooking(c, req, b, date, start, note, 'confirmed');
          await c.query("UPDATE reschedule_requests SET status='approved', new_date=?, new_start_time=?, decided_by=?, decided_at=UTC_TIMESTAMP(), decision_note=? WHERE id=?", [date, m.slot.startTime, req.user.id, note, id]);
          text = `Your consultation ${b.booking_code} has been moved to ${date} at ${m.slot.startTime.slice(0, 5)}.${note ? ' ' + note : ''}`;
        } else {
          const slot = await sched.findBookableSlot(c, b.consultant_id, date, start, { excludeBookingId: b.id });
          if (!slot) throw new HttpError(409, 'That alternative time is not available in the consultant\'s schedule.');
          await c.query("UPDATE reschedule_requests SET status='alternative_proposed', new_date=?, new_start_time=?, decided_by=?, decided_at=UTC_TIMESTAMP(), decision_note=? WHERE id=?", [date, slot.startTime, req.user.id, note, id]);
          await history(c, b.id, 'reschedule_requested', 'reschedule_requested', req.user.id, `Alternative proposed: ${date} ${slot.startTime.slice(0, 5)}`);
          text = `An alternative time was proposed for ${b.booking_code}: ${date} at ${slot.startTime.slice(0, 5)}. Please accept or decline it in your portal.`;
        }
        await notify(c, b.patient_id, 'reschedule_decision', 'Reschedule update', text, b.id);
        if (decision === 'approve' && req.user.id !== b.consultant_id) await notify(c, b.consultant_id, 'rescheduled', 'Consultation rescheduled', `${b.booking_code} moved to ${date} at ${start.slice(0, 5)}.`, b.id);
        await audit(c, req, `reschedule.${decision}`, 'booking', b.id, { requestId: id, date, start });
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That time was just taken.'); throw e; }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/reschedules/:id/respond', requirePortal('patient'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Request' });
    const accept = req.body.accept === true;
    try {
      await tx(async (c) => {
        const [[r]] = await c.query('SELECT * FROM reschedule_requests WHERE id=? FOR UPDATE', [id]);
        if (!r) throw new HttpError(404, 'Request not found.');
        const b = await fetchBooking(c, r.booking_id, req.user, { lock: true });
        if (b.patient_id !== req.user.id) throw new HttpError(404, 'Request not found.');
        if (r.status !== 'alternative_proposed') throw new HttpError(409, 'There is no alternative awaiting your response.');
        await c.query('SELECT user_id FROM consultants WHERE user_id=? FOR UPDATE', [b.consultant_id]);
        if (accept) {
          const m = await moveBooking(c, req, b, r.new_date, r.new_start_time, 'Patient accepted the proposed time', 'confirmed');
          await c.query("UPDATE reschedule_requests SET status='accepted' WHERE id=?", [id]);
          const text = `${b.patient_name} accepted the new time for ${b.booking_code}: ${r.new_date} at ${m.slot.startTime.slice(0, 5)}.`;
          await notify(c, b.consultant_id, 'rescheduled', 'Consultation rescheduled', text, b.id);
          await notifyPermission(c, 'reschedule.review', 'rescheduled', 'Reschedule accepted', text, b.id);
        } else {
          await c.query("UPDATE reschedule_requests SET status='declined' WHERE id=?", [id]);
          if (b.status === 'reschedule_requested') await c.query("UPDATE bookings SET status='confirmed' WHERE id=?", [b.id]);
          await history(c, b.id, b.status, b.status === 'reschedule_requested' ? 'confirmed' : b.status, req.user.id, 'Patient declined the proposed alternative');
          await notifyPermission(c, 'reschedule.review', 'reschedule_declined', 'Alternative declined', `${b.patient_name} declined the proposed time for ${b.booking_code}.`, b.id);
        }
        await audit(c, req, accept ? 'reschedule.accept' : 'reschedule.decline', 'booking', b.id, { requestId: id });
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'That time is no longer available. Please ask the clinic for another option.'); throw e; }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- notifications ----------
router.get('/notifications', async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT id, type, title, message, booking_id, is_read, created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60', [req.user.id]);
    const [[c]] = await db.query('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND is_read=0', [req.user.id]);
    res.json({ unread: c.n, notifications: rows.map((n) => ({ id: n.id, type: n.type, title: n.title, message: n.message, bookingId: n.booking_id, read: !!n.is_read, createdAt: T.iso(n.created_at) })) });
  } catch (e) { next(e); }
});
router.post('/notifications/read-all', async (req, res, next) => {
  try { await db.query('UPDATE notifications SET is_read=1, read_at=UTC_TIMESTAMP() WHERE user_id=? AND is_read=0', [req.user.id]); res.json({ ok: true }); }
  catch (e) { next(e); }
});
router.post('/notifications/:id/read', async (req, res, next) => {
  try { await db.query('UPDATE notifications SET is_read=1, read_at=UTC_TIMESTAMP() WHERE id=? AND user_id=? AND is_read=0', [V.int(req.params.id, { field: 'Notification' }), req.user.id]); res.json({ ok: true }); }
  catch (e) { next(e); }
});

module.exports = router;
