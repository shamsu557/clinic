'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const { db, tx } = require('../db');
const S = require('../lib/security');
const V = require('../lib/validate');
const { audit } = require('../lib/audit');
const { sendMail } = require('../lib/mailer');
const { ensureToken } = require('../middleware/csrf');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const { HttpError, bad } = V;

const limiter = (windowMin, max, message) => rateLimit({
  windowMs: windowMin * 60 * 1000, max: max * config.rateScale, standardHeaders: true, legacyHeaders: false,
  handler: (req, res, next) => next(new HttpError(429, message)),
});
const loginLimiter = limiter(15, 20, 'Too many sign-in attempts. Please wait a few minutes and try again.');
const registerLimiter = limiter(60, 15, 'Too many registrations from this network. Please try again later.');
const recoveryLimiter = limiter(30, 15, 'Too many recovery attempts. Please wait and try again later.');

const MAX_FAILS = 5;
const LOCK_MINUTES = 15;

function publicUser(u) {
  return {
    id: u.id, fullName: u.fullName, email: u.email, phone: u.phone, role: u.roleCode, roleName: u.roleName,
    roles: u.roles, role: u.role, needRole: u.needRole, portal: u.portal, portals: u.portals, rank: u.rank, isOwner: u.isOwner, isConsultant: u.isConsultant, permissions: u.permissions,
    mustChangePassword: u.mustChangePassword, mustSetupSecurity: u.mustSetupSecurity,
  };
}

router.get('/csrf', (req, res) => res.json({ csrfToken: ensureToken(req) }));

router.get('/me', (req, res) => {
  res.json({ csrfToken: ensureToken(req), user: req.user ? publicUser(req.user) : null,
    app: { timezone: config.timezone, googleMeetAutomation: config.google.enabled, otpRecovery: config.recoveryOtp, meetLinkHours: config.meetLinkHours, maxReceiptMb: config.maxReceiptBytes / 1048576 } });
});

router.get('/security-questions', async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT id, question FROM security_questions WHERE active=1 ORDER BY id');
    res.json({ questions: rows });
  } catch (e) { next(e); }
});

// ---------- Patient registration ----------
router.post('/register', registerLimiter, async (req, res, next) => {
  try {
    const b = req.body || {};
    const fullName = V.str(b.fullName, { min: 3, max: 150, field: 'Full name' });
    const email = V.normalizeEmail(b.email);
    const phone = V.normalizePhone(b.phone);
    if (!email) throw bad('Please enter a valid email address.');
    if (!phone) throw bad('Please enter a valid phone number (e.g. 0803 000 0000 or +234 803 000 0000).');
    V.checkPassword(b.password, b.confirmPassword);
    const age = V.int(b.age, { min: 0, max: 120, field: 'Age' });
    if (!['Male', 'Female'].includes(b.gender)) throw bad('Please select a gender.');

    const hash = await S.hashPassword(b.password);
    try {
      await tx(async (c) => {
        const [[role]] = await c.query("SELECT id FROM roles WHERE code='patient'");
        const [r] = await c.query(
          `INSERT INTO users (role_id, full_name, email, phone, password_hash, must_change_password, must_setup_security, password_changed_at)
           VALUES (?,?,?,?,?,0,1,UTC_TIMESTAMP())`, [role.id, fullName, email, phone, hash]);
        const code = `PT-${new Date().getUTCFullYear()}-${String(r.insertId).padStart(5, '0')}`;
        await c.query('INSERT INTO patient_profiles (user_id, patient_code, age, gender) VALUES (?,?,?,?)', [r.insertId, code, age, b.gender]);
        await c.query('INSERT INTO user_roles (user_id, role_id) VALUES (?,?)', [r.insertId, role.id]);
        req.auditActorId = r.insertId;
        await audit(c, req, 'patient.register', 'user', r.insertId, null);
      });
    } catch (e) {
      if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'An account with this email address or phone number already exists. Please sign in instead (or use “Forgot password”).');
      throw e;
    }
    res.status(201).json({ ok: true, message: 'Account created. You can now sign in with your email or phone number.' });
  } catch (e) { next(e); }
});

// ---------- Login ----------
router.post('/login', loginLimiter, async (req, res, next) => {
  try {
    const { identifier, password } = req.body || {};
    const id = V.parseIdentifier(identifier);
    const generic = new HttpError(401, 'Incorrect email/phone number or password.');
    if (!id || typeof password !== 'string' || !password || password.length > 200) {
      await S.comparePassword('x', S.DUMMY_HASH);
      throw generic;
    }
    const [rows] = await db.query(
      `SELECT u.*, r.code AS role_code, r.name AS role_name, r.portal
         FROM users u JOIN roles r ON r.id = u.role_id WHERE u.${id.type} = ?`, [id.value]);
    const u = rows[0];
    if (!u) { await S.comparePassword(password, S.DUMMY_HASH); throw generic; }

    if (u.locked_until && new Date(u.locked_until.replace(' ', 'T') + 'Z') > new Date()) {
      throw new HttpError(429, 'Too many failed attempts. This account is temporarily locked. Please try again in a few minutes or reset your password.');
    }
    const ok = await S.comparePassword(password, u.password_hash);
    if (!ok) {
      const fails = u.failed_login_count + 1;
      if (fails >= MAX_FAILS) {
        await db.query('UPDATE users SET failed_login_count=0, locked_until=DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? MINUTE) WHERE id=?', [LOCK_MINUTES, u.id]);
        req.auditActorId = u.id; await audit(null, req, 'auth.lockout', 'user', u.id, null);
      } else {
        await db.query('UPDATE users SET failed_login_count=? WHERE id=?', [fails, u.id]);
      }
      throw generic;
    }
    if (u.status !== 'active') throw new HttpError(403, 'This account has been disabled. Please contact the clinic.');

    await db.query('UPDATE users SET failed_login_count=0, locked_until=NULL, last_login_at=UTC_TIMESTAMP() WHERE id=?', [u.id]);
    // new session id on login prevents session fixation
    await new Promise((resolve, reject) => req.session.regenerate((err) => (err ? reject(err) : resolve())));
    req.session.userId = u.id;
    const [heldRoles] = await db.query('SELECT role_id FROM user_roles WHERE user_id=?', [u.id]);
    if (heldRoles.length === 1) req.session.activeRoleId = heldRoles[0].role_id;   // several roles => they must choose after signing in
    const csrfToken = ensureToken(req);
    req.auditActorId = u.id;
    await audit(null, req, 'auth.login', 'user', u.id, null);
    res.json({
      csrfToken,
      user: {
        id: u.id, fullName: u.full_name, email: u.email, phone: u.phone, role: u.role_code, roleName: u.role_name, portal: u.portal,
        mustChangePassword: !!u.must_change_password, mustSetupSecurity: !!u.must_setup_security,
      },
    });
  } catch (e) { next(e); }
});

/** Choose (at login) or switch (any time) the ONE role you act as. */
router.post('/select-role', requireAuth, async (req, res, next) => {
  try {
    if (req.user.mustChangePassword || req.user.mustSetupSecurity) throw new HttpError(403, 'Please complete your first-time account setup.');
    const roleId = V.int((req.body || {}).roleId, { field: 'Role' });
    const role = req.user.roles.find((r) => r.id === roleId);
    if (!role) throw new HttpError(403, 'You do not hold that role.');
    const from = req.user.role ? req.user.role.name : null;
    req.session.activeRoleId = roleId;
    await new Promise((resolve, reject) => req.session.save((err) => (err ? reject(err) : resolve())));
    if (from !== role.name) await audit(null, req, 'auth.switch_role', 'user', req.user.id, { from: from || 'none (login)', to: role.name });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/logout', (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('clinic.sid');
    res.json({ ok: true });
  });
});

// ---------- First-time setup / change password + security question ----------
router.post('/setup', requireAuth, async (req, res, next) => {
  try {
    const u = req.user;
    if (!u.mustChangePassword && !u.mustSetupSecurity) throw bad('Your account setup is already complete.');
    const b = req.body || {};
    let newHash = null;
    if (u.mustChangePassword) {
      V.checkPassword(b.newPassword, b.confirmPassword);
      if (b.newPassword === config.tempStaffPassword) throw bad('Please choose a password different from the temporary one.');
      newHash = await S.hashPassword(b.newPassword);
    }
    let answerHash = null; let qid = null;
    if (u.mustSetupSecurity) {
      qid = V.int(b.questionId, { field: 'Security question' });
      const ans = V.str(b.answer, { min: 2, max: 100, field: 'Security answer' });
      const [q] = await db.query('SELECT id FROM security_questions WHERE id=? AND active=1', [qid]);
      if (!q.length) throw bad('Please select a valid security question.');
      answerHash = await S.hashAnswer(ans);
    }
    await tx(async (c) => {
      if (newHash) await c.query('UPDATE users SET password_hash=?, must_change_password=0, password_changed_at=UTC_TIMESTAMP() WHERE id=?', [newHash, u.id]);
      if (answerHash) {
        await c.query(
          `INSERT INTO user_security_answers (user_id, question_id, answer_hash) VALUES (?,?,?)
           ON DUPLICATE KEY UPDATE question_id=VALUES(question_id), answer_hash=VALUES(answer_hash)`, [u.id, qid, answerHash]);
        await c.query('UPDATE users SET must_setup_security=0 WHERE id=?', [u.id]);
      }
      await audit(c, req, 'auth.first_time_setup', 'user', u.id, { passwordChanged: !!newHash, securityQuestionSet: !!answerHash });
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// Normal "change password" for signed-in users (requires current password).
router.post('/change-password', requireAuth, async (req, res, next) => {
  try {
    const b = req.body || {};
    V.checkPassword(b.newPassword, b.confirmPassword);
    const [[row]] = await db.query('SELECT password_hash FROM users WHERE id=?', [req.user.id]);
    if (!(await S.comparePassword(String(b.currentPassword || ''), row.password_hash))) throw bad('Your current password is incorrect.');
    await db.query('UPDATE users SET password_hash=?, password_changed_at=UTC_TIMESTAMP() WHERE id=?', [await S.hashPassword(b.newPassword), req.user.id]);
    await audit(null, req, 'auth.change_password', 'user', req.user.id, null);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- Password recovery (security question [+ optional email OTP]) ----------
const RECOVERY_MINUTES = 20;
const MAX_ANSWER_TRIES = 5;

router.post('/recover/start', recoveryLimiter, async (req, res, next) => {
  try {
    const id = V.parseIdentifier((req.body || {}).identifier);
    if (!id) throw bad('Please enter the email address or phone number you registered with.');

    const [users] = await db.query(
      `SELECT u.id, u.email, u.status, u.recovery_locked_until, sq.question, sq.id AS qid, usa.answer_hash
         FROM users u
         LEFT JOIN user_security_answers usa ON usa.user_id = u.id
         LEFT JOIN security_questions sq ON sq.id = usa.question_id
        WHERE u.${id.type} = ?`, [id.value]);
    const u = users[0];
    const usable = u && u.status === 'active' && u.answer_hash &&
      !(u.recovery_locked_until && new Date(u.recovery_locked_until.replace(' ', 'T') + 'Z') > new Date());

    // Unknown / not-set-up accounts get a stable decoy question so responses are indistinguishable.
    let question;
    if (usable) question = u.question;
    else {
      const [qs] = await db.query('SELECT question FROM security_questions WHERE active=1 ORDER BY id');
      const h = parseInt(S.hmac(id.value).slice(0, 8), 16);
      question = qs[h % qs.length].question;
    }

    const token = S.randomToken(32);
    let otp = null;
    if (usable && config.recoveryOtp && u.email) otp = S.randomDigits(6);
    await db.query(
      `INSERT INTO password_recovery_sessions (token_hash, user_id, otp_hash, otp_expires_at, expires_at, ip_address)
       VALUES (?,?,?,?,DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? MINUTE),?)`,
      [S.sha256(token), usable ? u.id : null, otp ? S.sha256(otp) : null,
        otp ? new Date(Date.now() + 10 * 60 * 1000).toISOString().slice(0, 19).replace('T', ' ') : null,
        RECOVERY_MINUTES, String(req.ip || '').slice(0, 45)]);
    if (otp) {
      sendMail(u.email, 'Your password reset code',
        `Your The Clinic password reset code is ${otp}. It expires in 10 minutes. If you did not request this, ignore this email.`)
        .catch((e) => console.error('[mail] OTP send failed:', e.message));
    }
    res.json({ recoveryToken: token, question, otpRequired: config.recoveryOtp });
  } catch (e) { next(e); }
});

router.post('/recover/verify', recoveryLimiter, async (req, res, next) => {
  try {
    const { recoveryToken, answer, otp } = req.body || {};
    const fail = new HttpError(400, 'The details you provided could not be verified. Please check and try again.');
    if (typeof recoveryToken !== 'string' || !answer) throw fail;
    const [rows] = await db.query(
      `SELECT * FROM password_recovery_sessions WHERE token_hash=? AND used_at IS NULL AND verified_at IS NULL AND expires_at > UTC_TIMESTAMP()`,
      [S.sha256(recoveryToken)]);
    const s = rows[0];
    if (!s) throw new HttpError(400, 'This recovery session has expired. Please start again.');
    if (s.attempts >= MAX_ANSWER_TRIES) throw new HttpError(429, 'Too many incorrect attempts. Please start again later.');
    await db.query('UPDATE password_recovery_sessions SET attempts = attempts + 1 WHERE id=?', [s.id]);

    let ok = false;
    if (s.user_id) {
      const [[usa]] = await db.query('SELECT answer_hash FROM user_security_answers WHERE user_id=?', [s.user_id]);
      ok = !!usa && await S.compareAnswer(String(answer), usa.answer_hash);
      if (ok && config.recoveryOtp) {
        ok = !!s.otp_hash && !!otp && S.safeEqual(S.sha256(String(otp).trim()), s.otp_hash) &&
          new Date(s.otp_expires_at.replace(' ', 'T') + 'Z') > new Date();
      }
    } else {
      await S.compareAnswer(String(answer), S.DUMMY_HASH); // same timing as a real check
    }

    if (!ok) {
      if (s.user_id) {
        const [[u]] = await db.query('SELECT recovery_failed_count FROM users WHERE id=?', [s.user_id]);
        const n = u.recovery_failed_count + 1;
        if (n >= 5) {
          await db.query('UPDATE users SET recovery_failed_count=0, recovery_locked_until=DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 MINUTE) WHERE id=?', [s.user_id]);
          req.auditActorId = s.user_id; await audit(null, req, 'auth.recovery_locked', 'user', s.user_id, null);
        } else await db.query('UPDATE users SET recovery_failed_count=? WHERE id=?', [n, s.user_id]);
      }
      throw fail;
    }
    await db.query('UPDATE users SET recovery_failed_count=0 WHERE id=?', [s.user_id]);
    const resetToken = S.randomToken(32);
    await db.query(
      `UPDATE password_recovery_sessions SET token_hash=?, verified_at=UTC_TIMESTAMP(), expires_at=DATE_ADD(UTC_TIMESTAMP(), INTERVAL 10 MINUTE) WHERE id=?`,
      [S.sha256(resetToken), s.id]);
    res.json({ resetToken });
  } catch (e) { next(e); }
});

router.post('/recover/reset', recoveryLimiter, async (req, res, next) => {
  try {
    const { resetToken, newPassword, confirmPassword } = req.body || {};
    V.checkPassword(newPassword, confirmPassword);
    if (typeof resetToken !== 'string') throw bad('This reset link is no longer valid.');
    const hash = await S.hashPassword(newPassword);
    await tx(async (c) => {
      const [rows] = await c.query(
        `SELECT id, user_id FROM password_recovery_sessions
          WHERE token_hash=? AND verified_at IS NOT NULL AND used_at IS NULL AND expires_at > UTC_TIMESTAMP() FOR UPDATE`,
        [S.sha256(resetToken)]);
      const s = rows[0];
      if (!s || !s.user_id) throw bad('This reset session has expired. Please start again.');
      await c.query(
        `UPDATE users SET password_hash=?, must_change_password=0, failed_login_count=0, locked_until=NULL,
                password_changed_at=UTC_TIMESTAMP() WHERE id=?`, [hash, s.user_id]);
      await c.query('UPDATE password_recovery_sessions SET used_at=UTC_TIMESTAMP() WHERE id=?', [s.id]);
      await c.query('UPDATE password_recovery_sessions SET used_at=UTC_TIMESTAMP() WHERE user_id=? AND used_at IS NULL', [s.user_id]);
      // sign out every other session of this user
      await c.query("DELETE FROM sessions WHERE JSON_EXTRACT(data, '$.userId') = ?", [s.user_id]).catch(() => {});
      req.auditActorId = s.user_id;
      await audit(c, req, 'auth.password_recovered', 'user', s.user_id, null);
    });
    res.json({ ok: true, message: 'Your password has been changed. Please sign in with your new password.' });
  } catch (e) { next(e); }
});

module.exports = router;
