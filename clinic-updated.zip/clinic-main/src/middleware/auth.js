'use strict';
const { db } = require('../db');
const { HttpError } = require('../lib/validate');

/** Loads the signed-in user fresh from MySQL on every request so disabled accounts / role changes apply immediately. */
async function loadUser(req, res, next) {
  try {
    const id = req.session && req.session.userId;
    if (!id) return next();
    const [rows] = await db.query(
      `SELECT id, full_name, email, phone, status, must_change_password, must_setup_security FROM users WHERE id = ?`, [id]);
    const u = rows[0];
    if (!u || u.status !== 'active') return req.session.destroy(() => next());
    const [roles] = await db.query(
      `SELECT r.id, r.code, r.name, r.portal, r.rank_level FROM user_roles ur JOIN roles r ON r.id = ur.role_id
        WHERE ur.user_id = ? ORDER BY r.rank_level DESC, r.name`, [id]);
    if (!roles.length) return req.session.destroy(() => next());
    // A person has ONE account but may hold several roles. They act as exactly ONE role at a time (chosen at login,
    // switchable from the header). Permissions come only from that active role, never from the union.
    const all = roles.map((r) => ({ id: r.id, code: r.code, name: r.name, portal: r.portal, rank: r.rank_level }));
    const chosen = req.session.activeRoleId;
    const active = all.find((r) => r.id === chosen) || (all.length === 1 ? all[0] : null);
    let permissions = [];
    if (active) {
      const [perms] = await db.query('SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?', [active.id]);
      permissions = perms.map((p) => p.code);
    }
    req.user = {
      id: u.id, fullName: u.full_name, email: u.email, phone: u.phone,
      roles: all, role: active, needRole: !active,
      roleCode: active ? active.code : null, roleName: active ? active.name : all.map((r) => r.name).join(' / '),
      rank: active ? active.rank : 0,
      isOwner: !!active && active.code === 'owner',
      isConsultant: !!active && active.portal === 'consultant',
      portals: active ? [active.portal] : [], portal: active ? active.portal : null,
      permissions,
      mustChangePassword: !!u.must_change_password, mustSetupSecurity: !!u.must_setup_security,
    };
    next();
  } catch (e) { next(e); }
}

function requireAuth(req, res, next) {
  if (!req.user) return next(new HttpError(401, 'Please sign in to continue.'));
  next();
}

/** Blocks everything except the setup endpoints until first-time setup is complete. */
function requireReady(req, res, next) {
  if (req.user.mustChangePassword || req.user.mustSetupSecurity) {
    const err = new HttpError(403, 'Please complete your first-time account setup.');
    err.code = 'SETUP_REQUIRED';
    return next(err);
  }
  if (req.user.needRole) {
    const err = new HttpError(403, 'Please choose the role you want to sign in as.');
    err.code = 'ROLE_REQUIRED';
    return next(err);
  }
  next();
}

/** Passes if the user has ANY of the listed portals (a user may hold several roles). */
const requirePortal = (...portals) => (req, res, next) =>
  portals.some((p) => req.user.portals.includes(p)) ? next() : next(new HttpError(403, 'You do not have access to this area.'));

/** Passes if the user holds ANY of the listed permissions. */
const requirePerm = (...perms) => (req, res, next) =>
  perms.some((p) => req.user.permissions.includes(p)) ? next() : next(new HttpError(403, 'You do not have permission to do that.'));

const can = (user, perm) => user.permissions.includes(perm);

module.exports = { loadUser, requireAuth, requireReady, requirePortal, requirePerm, can };
