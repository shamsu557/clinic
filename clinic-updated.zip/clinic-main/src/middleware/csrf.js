'use strict';
const { randomToken, safeEqual } = require('../lib/security');
const { HttpError } = require('../lib/validate');

function ensureToken(req) {
  if (!req.session.csrf) req.session.csrf = randomToken(24);
  return req.session.csrf;
}

/** Synchronizer-token CSRF protection for every state-changing /api request. */
function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const sent = req.get('x-csrf-token');
  if (!req.session.csrf || !sent || !safeEqual(sent, req.session.csrf)) {
    const e = new HttpError(403, 'Your session expired. Please refresh the page and try again.'); e.code = 'CSRF'; return next(e);
  }
  next();
}
module.exports = { ensureToken, csrfGuard };
