'use strict';
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const config = require('./config');
const { pool, db } = require('./db');
const { loadUser, requireAuth, requireReady } = require('./middleware/auth');
const { csrfGuard } = require('./middleware/csrf');
const sweep = require('./lib/sweep');
const { HttpError } = require('./lib/validate');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', config.trustProxy === 'false' ? false : (/^\d+$/.test(config.trustProxy) ? parseInt(config.trustProxy, 10) : config.trustProxy));

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:'],
      fontSrc: ["'self'"], connectSrc: ["'self'"], objectSrc: ["'none'"], baseUri: ["'self'"],
      formAction: ["'self'"], frameAncestors: ["'none'"],
      ...(config.cookieSecure ? { upgradeInsecureRequests: [] } : {}),
    },
  },
  hsts: config.cookieSecure ? { maxAge: 15552000, includeSubDomains: true } : false,
  referrerPolicy: { policy: 'same-origin' },
}));
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: false, limit: '50kb' }));

const store = new MySQLStore({ clearExpired: true, checkExpirationInterval: 15 * 60 * 1000, expiration: config.sessionHours * 3600 * 1000,
  createDatabaseTable: false }, pool);
app.use(session({
  name: 'clinic.sid', secret: config.sessionSecret, store, resave: false, saveUninitialized: false, rolling: true,
  cookie: { httpOnly: true, sameSite: 'lax', secure: config.cookieSecure, maxAge: config.sessionHours * 3600 * 1000 },
}));

// Static UI (no directory listing, no dotfiles). Uploaded receipts live outside /public.
app.use(express.static(path.join(__dirname, '..', 'public'), { dotfiles: 'ignore', index: 'index.html', maxAge: config.isProd ? '1h' : 0 }));

// ---- API ----
const api = express.Router();
api.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
api.use(loadUser);
api.use(csrfGuard);
api.use('/auth', require('./routes/auth'));
api.get('/health', async (req, res, next) => { try { await db.query('SELECT 1'); res.json({ ok: true }); } catch (e) { next(e); } });
api.use(requireAuth, requireReady);
api.use('/admin', require('./routes/admin'));
api.use('/', require('./routes/catalog'));
api.use('/', require('./routes/bookings'));
api.use((req, res, next) => next(new HttpError(404, 'Not found.')));
app.use('/api', api);

// ---- errors ----
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, code: err.code, fields: err.fields });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid request.' });
  console.error('[error]', req.method, req.originalUrl, err && err.stack ? err.stack : err); // never logs bodies/passwords
  res.status(500).json({ error: 'Something went wrong on our side. Please try again.' });
});

if (require.main === module || process.env.RUN_VIA_APP_JS) {
  app.listen(config.port, () => {
    console.log(`The Clinic server listening on port ${config.port} (${config.isProd ? 'production' : 'development'})`);
    if (require.main === module) sweep.start();
  });
}
module.exports = app;
