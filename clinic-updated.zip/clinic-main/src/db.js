'use strict';
const mysql = require('mysql2');
const config = require('./config');

// dateStrings: DATE/TIME/DATETIME come back as strings, never JS Dates (no timezone surprises).
// Keep-alive + idle eviction stop remote/hosted MySQL servers from silently dropping idle connections (ECONNRESET).
const pool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  dateStrings: true,
  timezone: 'Z',
  charset: 'utf8mb4',
  connectTimeout: 20000,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,
  maxIdle: Math.min(config.db.connectionLimit, 3),
  idleTimeout: 30000,
});
const db = pool.promise();

pool.on('connection', (conn) => conn.query("SET time_zone = '+00:00'"));

const TRANSIENT = new Set(['ECONNRESET', 'PROTOCOL_CONNECTION_LOST', 'ETIMEDOUT', 'EPIPE', 'ECONNREFUSED', 'EHOSTUNREACH', 'ENOTFOUND', 'EAI_AGAIN']);
const isTransient = (e) => !!e && (TRANSIENT.has(e.code) || e.fatal === true);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const sqlOf = (a) => (typeof a === 'string' ? a : (a && a.sql) || '');

// Reads are retried once on a dead connection; writes only when the failure happened before anything was sent (connect phase).
const rawQuery = db.query.bind(db);
db.query = async (...args) => {
  try { return await rawQuery(...args); }
  catch (e) {
    if (isTransient(e) && (/^\s*(select|show)\b/i.test(sqlOf(args[0])) || e.syscall === 'connect')) { await sleep(200); return rawQuery(...args); }
    throw e;
  }
};

/** Run fn(conn) inside a transaction. Retries once if the connection drops before COMMIT (the server rolls the dead transaction back). */
async function tx(fn) {
  for (let attempt = 0; ; attempt++) {
    let conn;
    try { conn = await db.getConnection(); }
    catch (e) { if (attempt === 0 && isTransient(e)) { await sleep(300); continue; } throw e; }
    let committing = false; let destroyed = false;
    try {
      await conn.beginTransaction();
      const out = await fn(conn);
      committing = true;
      await conn.commit();
      return out;
    } catch (e) {
      const retry = attempt === 0 && !committing && isTransient(e);
      if (retry) { conn.destroy(); destroyed = true; } else { try { await conn.rollback(); } catch (_) { /* ignore */ } }
      if (!retry) throw e;
      await sleep(300);
    } finally {
      if (!destroyed) conn.release();
    }
  }
}

module.exports = { pool, db, tx, isTransient };
