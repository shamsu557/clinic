'use strict';
// Applies db/migrations/*.sql in order, once each. Usage: npm run migrate
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const config = require('../src/config');

(async () => {
  const conn = await mysql.createConnection({ ...config.db, multipleStatements: true, charset: 'utf8mb4' });
  await conn.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(100) PRIMARY KEY, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB`);
  const [done] = await conn.query('SELECT name FROM schema_migrations');
  const applied = new Set(done.map((r) => r.name));
  const dir = path.join(__dirname, '..', 'db', 'migrations');
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
    if (applied.has(f)) { console.log(`skip   ${f}`); continue; }
    console.log(`apply  ${f}`);
    // MySQL DDL cannot be rolled back, so every migration is written to be safely re-runnable (IF NOT EXISTS / INSERT IGNORE).
    try { await conn.query(fs.readFileSync(path.join(dir, f), 'utf8')); await conn.query('INSERT IGNORE INTO schema_migrations (name) VALUES (?)', [f]); }
    catch (e) { console.error(`FAILED ${f}: ${e.message}\nIt is safe to run the command again once the problem is fixed.`); process.exit(1); }
  }
  await conn.end();
  console.log('Migrations complete.');
})().catch((e) => { console.error(e.message); process.exit(1); });
