'use strict';
// Diagnoses database connectivity:  npm run db:check
const mysql = require('mysql2/promise');
const config = require('../src/config');
(async () => {
  const { host, port, user, database } = config.db;
  console.log(`Connecting to ${user}@${host}:${port}/${database} …`);
  const times = [];
  for (let i = 1; i <= 5; i++) {
    const t = Date.now();
    try {
      const c = await mysql.createConnection({ ...config.db, connectTimeout: 15000 });
      await c.query('SELECT 1'); const [[v]] = await c.query('SELECT VERSION() v, @@wait_timeout wt'); await c.end();
      times.push(Date.now() - t); console.log(`  try ${i}: ok in ${Date.now() - t} ms (server ${v.v}, wait_timeout ${v.wt}s)`);
    } catch (e) { console.log(`  try ${i}: FAILED — ${e.code || ''} ${e.message}`); }
    await new Promise((r) => setTimeout(r, 500));
  }
  if (!times.length) console.log('\nCannot reach the database. Check DB_HOST/DB_PORT, that MySQL is running, that your firewall/ISP allows port ' + port + ', and (for a remote host) that your IP is allowed to connect.');
  else if (times.length < 5) console.log('\nConnection is unstable (some attempts failed). This is a network/host problem, not an application bug. A local MySQL is the most reliable option.');
  else if (Math.max(...times) > 2000) console.log('\nConnection works but is slow (>2s). A remote database over a weak link will feel slow and may drop connections; consider a local MySQL.');
  else console.log('\nDatabase connection looks healthy.');
})();
