'use strict';
// Creates the initial Owner account. The password is hashed with bcrypt; nothing is stored or logged in plaintext.
// Interactive:      npm run create-owner
// Non-interactive:  OWNER_NAME=... OWNER_EMAIL=... OWNER_PHONE=... OWNER_PASSWORD=... npm run create-owner
const readline = require('readline');
const mysql = require('mysql2/promise');
const config = require('../src/config');
const V = require('../src/lib/validate');
const S = require('../src/lib/security');

function ask(q, hidden = false) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) { rl._writeToOutput = (s) => { if (s.includes(q)) process.stdout.write(s); else process.stdout.write(s.replace(/[^\r\n]/g, '*')); }; }
    rl.question(q, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); resolve(a); });
  });
}

(async () => {
  const conn = await mysql.createConnection({ ...config.db, charset: 'utf8mb4' });
  const [[o]] = await conn.query("SELECT COUNT(*) n FROM users u JOIN roles r ON r.id=u.role_id WHERE r.code='owner'");
  if (o.n > 0) { console.error('An owner account already exists. Use the Owner portal to manage staff, or reset via the database if access is lost.'); process.exit(1); }

  const name = process.env.OWNER_NAME || await ask('Owner full name: ');
  const email = V.normalizeEmail(process.env.OWNER_EMAIL || await ask('Owner email: '));
  const phone = V.normalizePhone(process.env.OWNER_PHONE || await ask('Owner phone: '));
  let pw = process.env.OWNER_PASSWORD;
  if (!pw) {
    pw = await ask('Temporary password (min 8 chars): ', true);
    const again = await ask('Repeat password: ', true);
    if (pw !== again) { console.error('Passwords do not match.'); process.exit(1); }
  }
  if (!name || name.trim().length < 3) { console.error('Invalid name.'); process.exit(1); }
  if (!email) { console.error('Invalid email.'); process.exit(1); }
  if (!phone) { console.error('Invalid phone.'); process.exit(1); }
  if (pw.length < 8) { console.error('Use at least 8 characters for the owner password.'); process.exit(1); }

  const hash = await S.hashPassword(pw);
  const [[role]] = await conn.query("SELECT id FROM roles WHERE code='owner'");
  const [r] = await conn.query(
    `INSERT INTO users (role_id, full_name, email, phone, password_hash, must_change_password, must_setup_security) VALUES (?,?,?,?,?,1,1)`,
    [role.id, name.trim(), email, phone, hash]);
  await conn.query('INSERT INTO staff_profiles (user_id, job_title) VALUES (?, ?)', [r.insertId, 'Owner']);
  await conn.query("INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, details) VALUES (NULL, 'owner.created', 'user', ?, 'created via CLI')", [String(r.insertId)]);
  await conn.end();
  console.log(`Owner account created for ${email}. On first login you will be asked to set a new password and a security question.`);
})().catch((e) => { console.error(e.code === 'ER_DUP_ENTRY' ? 'That email or phone is already in use.' : e.message); process.exit(1); });
