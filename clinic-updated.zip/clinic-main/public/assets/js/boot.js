'use strict';
/* Restore an existing session (if any) and render the right screen. */
(async function (App) {
  try {
    const d = await App.api.get('/auth/me');
    App.state.csrf = d.csrfToken; App.state.app = d.app || {}; App.state.user = d.user;
    if (d.user) return App.enter();
  } catch (e) { App.toast(e.message, 'error'); }
  App.go('landing');
})(window.App);
