'use strict';
/* Staff portal (owner, administrators, support, custom roles). Tabs appear according to the role's permissions. */
(function (App) {
  const { esc, btn, UI, empty, money, fmtDate, fmtTime, fmtDT, badge } = App; const S = App.state;
  const table = (heads, rows) => `<div class="${UI.card} overflow-x-auto"><table class="w-full text-sm"><thead class="bg-gray-50 text-left text-gray-600"><tr>${heads.map((h) => `<th class="px-4 py-3 font-semibold whitespace-nowrap">${h}</th>`).join('')}</tr></thead><tbody class="divide-y divide-gray-100">${rows.join('')}</tbody></table></div>`;
  const td = (v, cls = '') => `<td class="px-4 py-3 align-top ${cls}">${v}</td>`;
  const stat = (label, val, color, tab) => `<button type="button" data-action="tab" data-tab="${tab}" class="${UI.card} p-5 text-left hover:shadow-lg transition w-full"><div class="text-3xl font-extrabold ${color}">${val}</div><div class="text-sm text-gray-600 font-semibold mt-1">${label}</div></button>`;

  App.tabs.staff = [
    { id: 'overview', label: 'Overview', perm: ['bookings.view_all'], render: async (el) => {
      const [st, t] = await Promise.all([App.api.get('/stats'), App.api.get('/bookings?scope=today')]);
      const can = (p) => S.user.permissions.includes(p);
      el.innerHTML = `<div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">${stat("Today's consultations", st.today, 'text-blue-600', 'bookings')}${can('payments.verify') ? stat('Payments to verify', st.pendingPayments, 'text-yellow-600', 'payments') : stat('Awaiting payment check', st.pendingPayments, 'text-yellow-600', 'bookings')}${stat('Reschedule requests', st.pendingReschedules, 'text-purple-600', 'followup')}${stat('Not consulted (follow-up)', st.missed, 'text-red-600', 'followup')}${stat('Upcoming confirmed', st.upcoming, 'text-green-600', 'bookings')}</div>
        <h2 class="text-xl font-bold mb-3">Today's bookings</h2>${App.bookingList(t.bookings.filter((b) => b.status !== 'rejected'))}`;
    } },
    { id: 'payments', label: 'Payments', perm: ['payments.verify'], render: async (el) => {
      const st = S.payStatus || 'pending'; const d = await App.api.get(`/payments?status=${st}`);
      el.innerHTML = `<div class="flex flex-wrap items-center justify-between gap-3 mb-4"><h2 class="text-xl font-bold">Payment verification</h2><div class="flex gap-2">${['pending', 'approved', 'rejected'].map((s) => btn(s[0].toUpperCase() + s.slice(1), 'payFilter', st === s ? 'primary' : 'ghost', `data-status="${s}"`)).join('')}</div></div>` +
        (d.payments.length ? table(['Submitted', 'Patient', 'Service / appointment', 'Fee', 'Status', ''], d.payments.map((p) => `<tr>${td(esc(fmtDT(p.uploadedAt)))}${td(`<div class="font-semibold">${esc(p.patientName)}</div><div class="text-xs text-gray-500">${esc(p.code)}</div>`)}${td(`${esc(p.serviceName)}<div class="text-xs text-gray-500">${esc(p.consultantName)} · ${esc(fmtDate(p.date))} ${esc(fmtTime(p.startTime))}</div>${p.overdue ? '<div class="text-xs font-bold text-red-600">Appointment date has passed</div>' : ''}`)}${td(`<strong>${esc(money(p.amount))}</strong>${p.possibleDuplicateReceipt ? '<div class="text-xs font-bold text-orange-600">Same file used on another booking</div>' : ''}`)}${td(`${esc(p.status)}${p.reviewer ? `<div class="text-xs text-gray-500">${esc(p.reviewer)}<br>${esc(fmtDT(p.reviewedAt))}</div>` : ''}`)}${td(btn(p.status === 'pending' ? 'Review' : 'Open', 'openBooking', p.status === 'pending' ? 'primary' : 'ghost', `data-id="${p.bookingId}"`))}</tr>`)) : empty(`No ${st} payments.`));
    } },
    { id: 'bookings', label: 'All bookings', perm: ['bookings.view_all'], render: async (el) => {
      const f = S.bookFilter || {};
      const [cons, svc] = await Promise.all([App.api.get('/consultants'), App.api.get('/services?all=1')]);
      const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
      const d = await App.api.get('/bookings' + (qs ? '?' + qs : ''));
      const opt = (arr, key, label, val) => arr.map((x) => `<option value="${x[key]}" ${String(val) === String(x[key]) ? 'selected' : ''}>${esc(x[label])}</option>`).join('');
      el.innerHTML = `<form data-form="bookFilter" class="${UI.card} p-4 mb-5 grid sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
        <div><label class="${UI.label}">Search</label><input name="q" value="${esc(f.q || '')}" placeholder="Patient, ID, ref" class="${UI.input} !py-2"></div>
        <div><label class="${UI.label}">Status</label><select name="status" class="${UI.input} !py-2"><option value="">All</option>${['requested', 'confirmed', 'reschedule_requested', 'completed', 'cancelled', 'missed', 'rejected'].map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${esc(App.statusLabel(s))}</option>`).join('')}</select></div>
        <div><label class="${UI.label}">Consultant</label><select name="consultantId" class="${UI.input} !py-2"><option value="">All</option>${opt(cons.consultants, 'id', 'fullName', f.consultantId)}</select></div>
        <div><label class="${UI.label}">Service</label><select name="serviceId" class="${UI.input} !py-2"><option value="">All</option>${opt(svc.services, 'id', 'name', f.serviceId)}</select></div>
        <div class="grid grid-cols-2 gap-2"><div><label class="${UI.label}">From</label><input type="date" name="from" value="${esc(f.from || '')}" class="${UI.input} !py-2"></div><div><label class="${UI.label}">To</label><input type="date" name="to" value="${esc(f.to || '')}" class="${UI.input} !py-2"></div></div>
        <button type="submit" class="${UI.btn} ${UI.primary}">Filter</button></form>
        <p class="text-sm text-gray-500 mb-2">${d.bookings.length} booking(s) — ordered by date, time, then request time.</p>${App.groupedBookings(d.bookings)}`;
    } },
    { id: 'followup', label: 'Reschedules & not consulted', perm: ['bookings.manage', 'reschedule.review'], render: async (el) => {
      const [rs, ms] = await Promise.all([App.api.get('/reschedules').catch(() => ({ requests: [] })), App.api.get('/bookings?status=missed').catch(() => ({ bookings: [] }))]);
      el.innerHTML = `<h2 class="text-xl font-bold mb-3">Reschedule requests</h2>${rs.requests.length ? `<div class="space-y-3">${rs.requests.map((r) => `<div class="${UI.card} p-4 flex flex-wrap justify-between gap-3"><div><div class="font-bold">${esc(r.patientName)} <span class="text-gray-500 font-normal">${esc(r.code)}</span></div><div class="text-sm text-gray-600">${esc(r.consultantName)} · ${esc(fmtDate(r.date))} ${esc(fmtTime(r.startTime))}</div><div class="text-sm mt-1">“${esc(r.reason)}”</div><div class="text-xs mt-1 text-purple-700 font-semibold">${esc(r.status.replace('_', ' '))}</div></div>${btn('Review', 'openBooking', 'primary', `data-id="${r.bookingId}"`)}</div>`).join('')}</div>` : empty('No open reschedule requests.')}
        <h2 class="text-xl font-bold mt-10 mb-3">Not consulted — approve a new time when the patient requests a reschedule, or arrange one yourself</h2>${App.bookingList(ms.bookings)}`;
    } },
    { id: 'services', label: 'Services & fees', perm: ['services.manage'], render: async (el) => {
      const d = await App.api.get('/services?all=1');
      el.innerHTML = `<div class="grid lg:grid-cols-3 gap-6"><div class="lg:col-span-2">${d.services.length ? table(['Service', 'Fee', 'Bookings', 'Status', ''], d.services.map((s) => `<tr>${td(`<div class="font-semibold">${esc(s.name)}</div><div class="text-xs text-gray-500">${esc(s.description || '')}</div>`)}${td(`<strong>${esc(money(s.fee))}</strong>`)}${td(`${s.bookings}${s.pendingRequests ? `<div class="text-xs text-yellow-700">${s.pendingRequests} awaiting verification</div>` : ''}`)}${td(s.active ? '<span class="text-green-700 font-semibold">Enabled</span>' : '<span class="text-gray-500">Disabled</span>')}${td(`<div class="flex gap-2">${btn('Edit', 'editService', 'ghost', `data-id="${s.id}" data-name="${esc(s.name)}" data-desc="${esc(s.description || '')}" data-fee="${s.fee}"`)}${btn(s.active ? 'Disable' : 'Enable', 'toggleService', 'ghost', `data-id="${s.id}" data-active="${s.active ? 0 : 1}"`)}</div>`)}</tr>`)) : empty('No services yet. Add your first one.')}</div>
        <form data-form="addService" class="${UI.card} p-5 space-y-3 h-fit"><h3 class="font-bold">Add a service</h3><div><label class="${UI.label}">Name</label><input name="name" required maxlength="120" class="${UI.input} !py-2"></div><div><label class="${UI.label}">Description</label><input name="description" maxlength="500" class="${UI.input} !py-2"></div><div><label class="${UI.label}">Fee (₦)</label><input name="fee" type="number" min="0" step="0.01" required class="${UI.input} !py-2"></div><button type="submit" class="w-full ${UI.btn} ${UI.primary}">Add service</button></form></div>`;
    } },
    { id: 'patients', label: 'Patients', perm: ['patients.view'], render: async (el) => {
      const q = S.patientQ || ''; const d = await App.api.get('/admin/patients?q=' + encodeURIComponent(q));
      el.innerHTML = `<form data-form="patientSearch" class="flex gap-2 mb-4"><input name="q" value="${esc(q)}" placeholder="Search name, phone, email, ID" class="${UI.input} !py-2 max-w-md"><button class="${UI.btn} ${UI.primary}" type="submit">Search</button></form>` +
        (d.patients.length ? table(['Patient', 'Contact', 'Age / Gender', 'Bookings', 'Registered'], d.patients.map((p) => `<tr>${td(`<div class="font-semibold">${esc(p.fullName)}</div><div class="text-xs text-gray-500">${esc(p.patientCode)}</div>`)}${td(`${esc(p.email)}<div class="text-xs text-gray-500">${esc(p.phone)}</div>`)}${td(`${esc(p.age ?? '')} ${esc(p.gender || '')}`)}${td(p.bookings)}${td(esc(fmtDT(p.createdAt)))}</tr>`)) : empty('No patients found.'));
    } },
    { id: 'staff', label: 'Staff', perm: ['users.view', 'users.manage'], render: async (el) => {
      const [u, r] = await Promise.all([App.api.get('/admin/users'), App.api.get('/admin/roles')]);
      const me = S.user; const canManage = me.permissions.includes('users.manage'); S.roles = r.roles;
      const assignable = r.roles.filter((x) => x.portal !== 'patient' && (me.isOwner || x.rank < me.rank));
      const top = (x) => Math.max(...x.roles.map((y) => y.rank));
      el.innerHTML = `<div class="grid lg:grid-cols-3 gap-6"><div class="lg:col-span-2">${table(['Name', 'Roles', 'Contact', 'Status', ''], u.users.map((x) => {
        const self = x.id === me.id; const manage = canManage && (self ? me.isOwner : (me.isOwner || top(x) < me.rank));
        return `<tr>${td(`<div class="font-semibold">${esc(x.fullName)}${self ? ' <span class="text-xs text-gray-500">(you)</span>' : ''}</div>${x.setupPending ? '<span class="text-xs font-bold text-orange-600">First-time setup pending</span>' : ''}<div class="text-xs text-gray-400">${x.lastLoginAt ? 'Last login ' + esc(fmtDT(x.lastLoginAt)) : 'Never signed in'}</div>`)}${td(x.roles.map((y) => `<span class="inline-block bg-blue-50 text-blue-800 text-xs font-semibold rounded-full px-2 py-0.5 mr-1 mb-1">${esc(y.name)}</span>`).join(''))}${td(`${esc(x.email || '')}<div class="text-xs text-gray-500">${esc(x.phone || '')}</div>`)}${td(x.status === 'active' ? '<span class="text-green-700 font-semibold">Active</span>' : '<span class="text-red-600 font-semibold">Disabled</span>')}${td(manage ? `<div class="flex flex-wrap gap-2">${btn(self ? 'Edit roles' : 'Edit', 'editStaff', 'ghost', `data-id="${x.id}"`)}${self ? '' : btn(x.status === 'active' ? 'Disable' : 'Enable', 'toggleStaff', 'ghost', `data-id="${x.id}" data-status="${x.status === 'active' ? 'disabled' : 'active'}"`)}${self ? '' : btn('Reset password', 'resetStaffPw', 'ghost', `data-id="${x.id}"`)}</div>` : '')}</tr>`;
      }))}</div>
        ${canManage ? `<form data-form="addStaff" class="${UI.card} p-5 space-y-3 h-fit"><h3 class="font-bold">Create staff account</h3>
          <div><label class="${UI.label}">Full name</label><input name="fullName" required class="${UI.input} !py-2"></div><div><label class="${UI.label}">Email</label><input name="email" type="email" required class="${UI.input} !py-2"></div><div><label class="${UI.label}">Phone</label><input name="phone" type="tel" required class="${UI.input} !py-2"></div>
          <div><label class="${UI.label}">Roles (one or more)</label>${roleChecks(assignable, [])}</div>
          <div><label class="${UI.label}">Job title / specialty (optional)</label><input name="jobTitle" maxlength="100" class="${UI.input} !py-2"></div>
          <p class="text-xs text-gray-600">The account is created with the clinic’s temporary password. The user must change it and set a security question at first login. Share the temporary password with them privately.</p><button type="submit" class="w-full ${UI.btn} ${UI.primary}">Create account</button></form>` : ''}</div>`;
    } },
    { id: 'roles', label: 'Roles & permissions', perm: ['roles.manage'], render: async (el) => {
      const [r, p] = await Promise.all([App.api.get('/admin/roles'), App.api.get('/admin/permissions')]); S.perms = p.permissions;
      const editable = r.roles.filter((x) => x.portal !== 'patient' && x.code !== 'owner');
      el.innerHTML = `<p class="text-sm text-gray-600 mb-4">Owner always has every permission. Consultants and patients get their own portals; tick the permissions each staff role needs. Custom roles can never manage other users.</p><div class="grid md:grid-cols-2 gap-5">${editable.map((x) => roleForm(x, p.permissions)).join('')}
        <form data-form="saveRole" data-new="1" class="${UI.card} p-5 space-y-3 border-2 border-dashed"><h3 class="font-bold">New custom role</h3><input name="name" required minlength="3" maxlength="80" placeholder="e.g. Front Desk" class="${UI.input} !py-2">${permBoxes(p.permissions, [])}<button type="submit" class="${UI.btn} ${UI.primary}">Create role</button></form></div>`;
    } },
    { id: 'audit', label: 'Audit log', perm: ['audit.view'], render: async (el) => {
      const d = await App.api.get('/admin/audit?limit=500'); const q = (S.auditQ || '').toLowerCase();
      const rows = d.logs.filter((l) => !q || [l.actor, l.actorRole, l.action, ACT[l.action], l.entityLabel, l.details].join(' ').toLowerCase().includes(q));
      el.innerHTML = `<div class="flex flex-wrap justify-between items-center gap-3 mb-3"><div><h2 class="text-xl font-bold">Audit log</h2><p class="text-sm text-gray-500">Who did what, when. Newest first.</p></div>
        <form data-form="auditSearch" class="flex gap-2"><input name="q" value="${esc(S.auditQ || '')}" placeholder="Search name, action, booking…" class="${UI.input} !py-2"><button class="${UI.btn} ${UI.primary}" type="submit">Search</button></form></div>` +
        (rows.length ? table(['Date & time', 'User', 'Action', 'Target', 'Details', 'IP'], rows.map((l) => `<tr>${td(esc(fmtDT(l.createdAt)), 'whitespace-nowrap')}${td(l.actor ? `<div class="font-semibold">${esc(l.actor)}</div><div class="text-xs text-gray-500">${esc(l.actorRole || '')}</div>` : '<span class="text-gray-400">System (automatic)</span>')}${td(`<div class="font-semibold">${esc(ACT[l.action] || l.action)}</div><code class="text-xs text-gray-400">${esc(l.action)}</code>`)}${td(esc(l.entityLabel || [l.entityType, l.entityId].filter(Boolean).join(' #')))}${td(`<span class="text-xs text-gray-600">${esc(detailText(l.details))}</span>`)}${td(`<span class="text-xs text-gray-500">${esc(l.ip || '')}</span>`)}</tr>`)) : empty('No matching entries.'));
    } },
    { id: 'whatsapp', label: 'WhatsApp alerts', perm: ['settings.manage', 'bookings.manage'], render: async (el) => {
      const [cfg, box] = await Promise.all([App.api.get('/admin/whatsapp'), App.api.get('/admin/whatsapp/outbox')]);
      const canEdit = S.user.permissions.includes('settings.manage');
      const badgeCls = { sent: 'bg-green-100 text-green-800', manual: 'bg-yellow-100 text-yellow-800', queued: 'bg-blue-100 text-blue-800', sending: 'bg-blue-100 text-blue-800', failed: 'bg-red-100 text-red-800' };
      el.innerHTML = `<div class="grid lg:grid-cols-3 gap-6"><div class="space-y-4">
        <div class="${UI.card} p-5"><h3 class="font-bold mb-1">Alert number</h3><p class="text-sm text-gray-600 mb-3">Every new booking and reschedule request is sent to this WhatsApp number.</p>
          ${canEdit ? `<form data-form="saveWa" class="space-y-3"><input name="number" required value="${esc(cfg.number)}" class="${UI.input}" aria-label="WhatsApp number"><label class="flex items-center gap-2 text-sm"><input type="checkbox" name="enabled" ${cfg.enabled ? 'checked' : ''}> Send alerts</label><button type="submit" class="${UI.btn} ${UI.primary}">Save</button></form>` : `<div class="font-semibold">${esc(cfg.number)}</div>`}</div>
        <div class="${UI.card} p-5 text-sm"><h3 class="font-bold mb-1">Sending</h3>${cfg.automatic ? `<p class="text-green-700 font-semibold">Automatic — via ${esc(cfg.provider)}.</p>${canEdit ? `<div class="mt-3">${btn('Send a test message', 'waTest', 'ghost')}</div>` : ''}` : `<p class="text-yellow-800 font-semibold">Manual</p><p class="text-gray-600 mt-1">No WhatsApp provider is configured on the server, so alerts wait in the list. Tap <strong>Send via WhatsApp</strong> next to a message to send it from your phone or WhatsApp Web, then <strong>Mark sent</strong>. Ask your developer to set <code>WHATSAPP_PROVIDER</code> in <code>.env</code> for fully automatic sending.</p>`}
          <p class="text-xs text-gray-500 mt-3">Messages contain only the patient’s name, booking reference, service, consultant and time — never medical details.</p></div></div>
        <div class="lg:col-span-2">${box.messages.length ? table(['When', 'Message', 'Status', ''], box.messages.map((m) => `<tr>${td(`<div class="whitespace-nowrap">${esc(fmtDT(m.createdAt))}</div><div class="text-xs text-gray-500">${esc(m.eventType)}${m.code ? ' · ' + esc(m.code) : ''}</div>`)}${td(`<div class="text-xs text-gray-700 whitespace-pre-line max-w-md">${esc(m.message)}</div>`)}${td(`<span class="px-2 py-0.5 rounded-full text-xs font-bold ${badgeCls[m.status] || ''}">${esc(m.status)}</span>${m.error ? `<div class="text-xs text-red-600 mt-1 max-w-[12rem]">${esc(m.error)}</div>` : ''}${m.attempts ? `<div class="text-xs text-gray-400">tries: ${m.attempts}</div>` : ''}`)}${td(`<div class="flex flex-col gap-2">${m.status !== 'sent' ? `<a class="${UI.btn} ${UI.success} !py-1 !text-xs" href="${esc(m.link)}" target="_blank" rel="noopener noreferrer">Send via WhatsApp</a>${btn('Mark sent', 'waSent', 'ghost', `data-id="${m.id}"`)}` : ''}${m.status === 'failed' && cfg.automatic ? btn('Retry', 'waRetry', 'ghost', `data-id="${m.id}"`) : ''}</div>`)}</tr>`)) : empty('No alerts yet. They appear here when a patient books or asks to reschedule.')}</div></div>`;
    } },
    { id: 'settings', label: 'Payment details', perm: ['settings.manage'], render: async (el) => {
      const p = await App.api.get('/settings/payment');
      el.innerHTML = `<form data-form="savePay" class="${UI.card} p-6 space-y-4 max-w-xl"><h2 class="text-xl font-bold">Account patients pay into</h2>
        <div><label class="${UI.label}">Account name</label><input name="accountName" required value="${esc(p.accountName)}" class="${UI.input}"></div><div><label class="${UI.label}">Bank</label><input name="bank" required value="${esc(p.bank)}" class="${UI.input}"></div>
        <div><label class="${UI.label}">Account number</label><input name="accountNumber" required pattern="\\d{6,20}" value="${esc(p.accountNumber)}" class="${UI.input}"></div><div><label class="${UI.label}">Instructions</label><input name="instructions" maxlength="400" value="${esc(p.instructions || '')}" class="${UI.input}"></div>
        <button type="submit" class="${UI.btn} ${UI.primary}">Save</button></form>`;
    } },
  ];
  App.portalSubtitle = ((prev) => (u, portal) => (portal === 'staff' ? `${u.roleName} — manage bookings, payments and the clinic team according to your permissions.` : prev(u, portal)))(App.portalSubtitle);

  const roleChecks = (roles, have) => `<div class="space-y-1">${roles.map((r) => `<label class="flex items-start gap-2 text-sm"><input type="checkbox" name="roleId" value="${r.id}" ${have.includes(r.id) ? 'checked' : ''} class="mt-1"><span><strong>${esc(r.name)}</strong> <span class="text-xs text-gray-500">${r.portal === 'consultant' ? '· can take consultations' : ''}</span></span></label>`).join('')}</div>`;
  const checkedRoles = (f) => Array.from(f.querySelectorAll('input[name=roleId]:checked')).map((x) => +x.value);
  const ACT = { 'auth.login': 'Signed in', 'auth.lockout': 'Account locked after failed sign-ins', 'auth.first_time_setup': 'Completed first-time setup', 'auth.password_recovered': 'Reset password (recovery)', 'auth.recovery_locked': 'Password recovery locked', 'auth.change_password': 'Changed password',
    'patient.register': 'Patient registered', 'owner.created': 'Owner account created', 'owner.updated': 'Owner account updated', 'staff.create': 'Staff account created', 'staff.update': 'Staff account edited', 'staff.roles_changed': 'Roles changed', 'staff.reset_password': 'Staff password reset',
    'role.create': 'Role created', 'role.update_permissions': 'Role permissions changed', 'service.create': 'Service created', 'service.update': 'Service / fee changed', 'settings.payment_update': 'Payment details changed',
    'payment.approve': 'Payment approved', 'payment.reject': 'Payment rejected', 'receipt.view': 'Payment receipt viewed', 'meet.add': 'Meet link added', 'meet.update': 'Meet link replaced', 'meet.remove': 'Meet link removed',
    'booking.cancelled': 'Booking cancelled', 'booking.completed': 'Consultation completed', 'booking.missed': 'Marked as not consulted', 'meet.expired': 'Meet link removed automatically', 'booking.arrange': 'Booking moved to a new time', 'booking.message': 'Message sent to patient',
    'reschedule.request': 'Reschedule requested', 'reschedule.approve': 'Reschedule approved', 'reschedule.reject': 'Reschedule declined', 'reschedule.propose': 'Alternative time proposed', 'reschedule.accept': 'Alternative time accepted', 'reschedule.decline': 'Alternative time declined',
    'document.upload': 'Patient document uploaded', 'document.view': 'Patient document opened', 'document.delete': 'Patient document deleted', 'records.view': 'Patient records opened', 'lab_request.create': 'Lab tests requested', 'lab_request.cancel': 'Lab request cancelled',
    'prescription.issue': 'Prescription issued', 'prescription.void': 'Prescription voided', 'prescription.pdf': 'Prescription PDF opened', 'settings.whatsapp_update': 'WhatsApp alert settings changed', 'whatsapp.test': 'WhatsApp test message sent' };
  const detailText = (raw) => {
    if (!raw) return '';
    let o; try { o = JSON.parse(raw); } catch (_) { return String(raw); }
    if (typeof o !== 'object' || o === null) return String(o);
    return Object.entries(o).map(([k, v]) => `${k.replace(/([A-Z])/g, ' $1').toLowerCase()}: ${v && typeof v === 'object' && !Array.isArray(v) ? Object.values(v).map((x) => (Array.isArray(x) ? x.join(', ') : x)).join(' → ') : Array.isArray(v) ? v.join(', ') : v}`).join(' · ');
  };
  const permBoxes = (all, have) => `<div class="space-y-1">${all.map((p) => `<label class="flex items-start gap-2 text-sm"><input type="checkbox" name="perm" value="${esc(p.code)}" ${have.includes(p.code) ? 'checked' : ''} class="mt-1"><span><code class="text-xs">${esc(p.code)}</code> — ${esc(p.description)}</span></label>`).join('')}</div>`;
  const roleForm = (r, all) => `<form data-form="saveRole" data-id="${r.id}" class="${UI.card} p-5 space-y-3"><h3 class="font-bold">${esc(r.name)} <span class="text-xs font-normal text-gray-500">${r.isSystem ? 'built-in' : 'custom'} · ${esc(r.portal)}</span></h3>${permBoxes(all, r.permissions)}<button type="submit" class="${UI.btn} ${UI.primary}">Save permissions</button></form>`;
  const perms = (f) => Array.from(f.querySelectorAll('input[name=perm]:checked')).map((x) => x.value);

  App.actions.payFilter = (el) => { S.payStatus = el.dataset.status; App.reloadTab(); };
  App.forms.bookFilter = async (f, d) => { S.bookFilter = d; await App.reloadTab(); };
  App.forms.auditSearch = async (f, d) => { S.auditQ = d.q; await App.reloadTab(); };
  App.forms.patientSearch = async (f, d) => { S.patientQ = d.q; await App.reloadTab(); };
  App.forms.addService = async (f, d) => { await App.api.post('/services', { name: d.name, description: d.description, fee: d.fee }); App.toast('Service added.', 'success'); await App.reloadTab(); };
  App.actions.toggleService = async (el) => { await App.api.patch(`/services/${el.dataset.id}`, { active: el.dataset.active === '1' }); await App.reloadTab(); };
  App.actions.editService = (el) => {
    const body = App.openModal('Edit service', `<form data-form="editService" data-id="${el.dataset.id}" class="space-y-3"><div><label class="${UI.label}">Name</label><input name="name" required value="${esc(el.dataset.name)}" class="${UI.input}"></div><div><label class="${UI.label}">Description</label><input name="description" value="${esc(el.dataset.desc)}" class="${UI.input}"></div><div><label class="${UI.label}">Fee (₦)</label><input name="fee" type="number" min="0" step="0.01" required value="${esc(el.dataset.fee)}" class="${UI.input}"></div><p class="text-xs text-gray-500">Existing bookings keep the fee they were booked at.</p><button type="submit" class="${UI.btn} ${UI.primary}">Save changes</button></form>`);
    return body;
  };
  App.forms.editService = async (f, d) => { await App.api.patch(`/services/${f.dataset.id}`, { name: d.name, description: d.description, fee: d.fee }); App.closeModal(); App.toast('Service updated.', 'success'); await App.reloadTab(); };
  App.forms.addStaff = async (f, d) => { const roleIds = checkedRoles(f); if (!roleIds.length) throw new Error('Select at least one role.'); const r = await App.api.post('/admin/users', { fullName: d.fullName, email: d.email, phone: d.phone, jobTitle: d.jobTitle, roleIds }); f.reset(); App.toast(r.message, 'success'); await App.reloadTab(); };
  App.actions.toggleStaff = async (el) => { if (el.dataset.status === 'disabled' && !confirm('Disable this account? They will be signed out immediately.')) return; await App.api.patch(`/admin/users/${el.dataset.id}`, { status: el.dataset.status }); await App.reloadTab(); };
  App.actions.resetStaffPw = async (el) => { if (!confirm('Reset this user’s password to the temporary one? They must set a new password and security question at next login.')) return; const r = await App.api.post(`/admin/users/${el.dataset.id}/reset-password`); App.toast(r.message, 'success'); await App.reloadTab(); };
  App.actions.editStaff = async (el) => {
    const d = await App.api.get('/admin/users'); const u = d.users.find((x) => x.id === +el.dataset.id); const me = S.user; const self = u.id === me.id;
    const assignable = S.roles.filter((x) => x.portal !== 'patient' && (me.isOwner || x.rank < me.rank));
    App.openModal(self ? 'Edit my roles' : 'Edit staff account', `<form data-form="editStaff" data-id="${u.id}" data-self="${self ? 1 : 0}" class="space-y-3">
      ${self ? '' : `<div><label class="${UI.label}">Full name</label><input name="fullName" required value="${esc(u.fullName)}" class="${UI.input}"></div><div><label class="${UI.label}">Email</label><input name="email" type="email" required value="${esc(u.email || '')}" class="${UI.input}"></div><div><label class="${UI.label}">Phone</label><input name="phone" required value="${esc(u.phone || '')}" class="${UI.input}"></div>`}
      <div><label class="${UI.label}">Roles</label>${roleChecks(assignable, u.roleIds)}<p class="text-xs text-gray-500 mt-2">A person can hold several roles — e.g. an Owner who also sees patients as a Consultant. Permissions combine; they get a portal switcher for each type of role. Consultation privacy still applies: a role never grants access to someone else’s consultation.</p></div>
      <button type="submit" class="${UI.btn} ${UI.primary}">Save changes</button></form>`);
  };
  App.forms.editStaff = async (f, d) => {
    const roleIds = checkedRoles(f); if (!roleIds.length) throw new Error('Select at least one role.');
    const body = { roleIds }; if (f.dataset.self !== '1') Object.assign(body, { fullName: d.fullName, email: d.email, phone: d.phone });
    const r = await App.api.patch(`/admin/users/${f.dataset.id}`, body); App.closeModal();
    App.toast(r.upcomingBookingsToReview ? `Saved. ${r.upcomingBookingsToReview} upcoming booking(s) need to be rearranged.` : 'Account updated.', 'success');
    if (f.dataset.self === '1') { await App.loadMe(); App.render(); } else await App.reloadTab();
  };
  App.forms.saveRole = async (f, d) => {
    if (f.dataset.new) { await App.api.post('/admin/roles', { name: d.name, permissions: perms(f) }); App.toast('Role created.', 'success'); }
    else { await App.api.put(`/admin/roles/${f.dataset.id}`, { permissions: perms(f) }); App.toast('Permissions saved.', 'success'); }
    await App.reloadTab();
  };
  App.forms.saveWa = async (f, d) => { await App.api.put('/admin/settings/whatsapp', { number: d.number, enabled: !!d.enabled }); App.toast('WhatsApp alert settings saved.', 'success'); await App.reloadTab(); };
  App.actions.waTest = async () => { const r = await App.api.post('/admin/whatsapp/test'); App.toast(r.status === 'sent' ? 'Test message sent.' : `Test message ${r.status}${r.error ? ': ' + r.error : ''}`, r.status === 'sent' ? 'success' : 'error'); await App.reloadTab(); };
  App.actions.waSent = async (el) => { await App.api.post(`/admin/whatsapp/outbox/${el.dataset.id}/sent`); await App.reloadTab(); };
  App.actions.waRetry = async (el) => { await App.api.post(`/admin/whatsapp/outbox/${el.dataset.id}/retry`); App.toast('Retried.', 'success'); await App.reloadTab(); };
  App.forms.savePay = async (f, d) => { await App.api.put('/admin/settings/payment', d); App.toast('Payment details saved.', 'success'); };
})(window.App);
