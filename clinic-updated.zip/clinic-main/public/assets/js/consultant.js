'use strict';
/* Consultant portal: schedule + availability management. */
(function (App) {
  const { esc, btn, UI, empty, DAYS, fmtDate, fmtTime } = App;
  const dayOrder = [1, 2, 3, 4, 5, 6, 0];

  App.tabs.consultant = [
    { id: 'today', label: 'Today', render: async (el) => { const d = await App.api.get('/bookings?scope=today&as=consultant'); el.innerHTML = `<h2 class="text-xl font-bold mb-3">Today's consultations</h2>${App.bookingList(d.bookings.filter((b) => !['rejected'].includes(b.status)), { showConsultant: false })}`; } },
    { id: 'upcoming', label: 'Upcoming', render: async (el) => { const d = await App.api.get('/bookings?scope=upcoming&as=consultant'); el.innerHTML = `<h2 class="text-xl font-bold mb-1">Upcoming appointments</h2>${App.groupedBookings(d.bookings, { showConsultant: false })}`; } },
    { id: 'patients', label: 'My patients', render: (el) => App.consultantRecords.patients(el) },
    { id: 'prescriptions', label: 'Prescriptions', render: (el) => App.consultantRecords.prescriptions(el) },
    { id: 'requests', label: 'Reschedule requests', render: async (el) => {
      const d = await App.api.get('/reschedules?as=consultant');
      el.innerHTML = `<h2 class="text-xl font-bold mb-3">Open reschedule requests</h2>` + (d.requests.length ? `<div class="space-y-3">${d.requests.map((r) => `<div class="${UI.card} p-4 flex flex-wrap justify-between gap-3"><div><div class="font-bold">${esc(r.patientName)} <span class="text-gray-500 font-normal">${esc(r.code)}</span></div><div class="text-sm text-gray-600">${esc(fmtDate(r.date))} at ${esc(fmtTime(r.startTime))}</div><div class="text-sm mt-1">“${esc(r.reason)}”</div></div>${btn('Review', 'openBooking', 'primary', `data-id="${r.bookingId}"`)}</div>`).join('')}</div>` : empty('No open requests.'));
    } },
    { id: 'history', label: 'History', render: async (el) => { const d = await App.api.get('/bookings?scope=history&as=consultant'); el.innerHTML = `<h2 class="text-xl font-bold mb-1">Completed, cancelled &amp; not consulted</h2>${App.groupedBookings(d.bookings, { showConsultant: false })}`; } },
    { id: 'availability', label: 'My availability', render: renderAvailability },
  ];

  async function renderAvailability(el) {
    const a = await App.api.get('/availability');
    const weekly = (dow) => a.rules.filter((r) => r.type === 'weekly' && r.dayOfWeek === dow);
    const dated = a.rules.filter((r) => r.type === 'date');
    const timeFields = `<input type="time" name="startTime" required class="${UI.input} !py-2" aria-label="Start time"><input type="time" name="endTime" required class="${UI.input} !py-2" aria-label="End time">
      <select name="slotMinutes" class="${UI.input} !py-2" aria-label="Appointment length">${[15, 20, 30, 45, 60, 90].map((m) => `<option value="${m}" ${m === 30 ? 'selected' : ''}>${m} min</option>`).join('')}</select>`;
    el.innerHTML = `<div class="grid lg:grid-cols-3 gap-6"><div class="lg:col-span-2 space-y-4">
      <div class="${UI.card} p-5"><h2 class="text-xl font-bold mb-1">Weekly hours</h2><p class="text-sm text-gray-600 mb-4">Patients can only book within these hours. Add as many ranges per day as you like (e.g. 9:00–12:00, 14:00–16:00, 18:00–20:00). Each range is split into appointments of the length you choose.</p>
        <div class="space-y-4">${dayOrder.map((d) => `<div class="border border-gray-100 rounded-lg p-3"><div class="font-bold mb-2">${DAYS[d]}</div>
          ${weekly(d).length ? `<div class="flex flex-wrap gap-2 mb-3">${weekly(d).map((r) => `<span class="inline-flex items-center gap-2 bg-green-50 text-green-800 border border-green-200 rounded-full pl-3 pr-1 py-1 text-sm font-semibold">${esc(fmtTime(r.startTime))} – ${esc(fmtTime(r.endTime))} · ${r.slotMinutes}m<button type="button" data-action="delRule" data-id="${r.id}" class="w-6 h-6 rounded-full hover:bg-green-200" aria-label="Remove">×</button></span>`).join('')}</div>` : '<p class="text-sm text-gray-400 mb-3">Not available</p>'}
          <form data-form="addRule" class="grid grid-cols-2 sm:grid-cols-4 gap-2 items-center"><input type="hidden" name="type" value="weekly"><input type="hidden" name="dayOfWeek" value="${d}">${timeFields}<button type="submit" class="col-span-2 sm:col-span-4 ${UI.btn} ${UI.ghost} !py-2">Add hours</button></form></div>`).join('')}</div></div></div>
      <div class="space-y-4">
        <div class="${UI.card} p-5"><h3 class="font-bold mb-1">Special dates</h3><p class="text-xs text-gray-600 mb-3">Hours for one specific date replace your weekly hours for that day.</p>
          ${dated.map((r) => `<div class="flex justify-between items-center text-sm py-1"><span>${esc(fmtDate(r.date))}: ${esc(fmtTime(r.startTime))}–${esc(fmtTime(r.endTime))} · ${r.slotMinutes}m</span><button type="button" data-action="delRule" data-id="${r.id}" class="text-red-600 font-bold" aria-label="Remove">×</button></div>`).join('')}
          <form data-form="addRule" class="space-y-2 mt-3"><input type="hidden" name="type" value="date"><input type="date" name="date" min="${App.today()}" required class="${UI.input} !py-2"><div class="grid grid-cols-2 gap-2">${timeFields}</div><button type="submit" class="w-full ${UI.btn} ${UI.ghost} !py-2">Add date</button></form></div>
        <div class="${UI.card} p-5"><h3 class="font-bold mb-1">Days off</h3><p class="text-xs text-gray-600 mb-3">Block a date so nobody can book it.</p>
          ${a.blocked.map((b) => `<div class="flex justify-between items-center text-sm py-1"><span>${esc(fmtDate(b.date))}${b.reason ? ` — ${esc(b.reason)}` : ''}</span><button type="button" data-action="delBlocked" data-id="${b.id}" class="text-red-600 font-bold" aria-label="Remove">×</button></div>`).join('')}
          <form data-form="addBlocked" class="space-y-2 mt-3"><input type="date" name="date" min="${App.today()}" required class="${UI.input} !py-2"><input name="reason" maxlength="200" placeholder="Reason (optional)" class="${UI.input} !py-2"><button type="submit" class="w-full ${UI.btn} ${UI.ghost} !py-2">Block date</button></form></div>
        <form data-form="consProfile" class="${UI.card} p-5 space-y-3"><h3 class="font-bold">Profile</h3><div><label class="${UI.label}">Specialty</label><input name="specialty" maxlength="120" value="${esc(a.specialty || '')}" class="${UI.input} !py-2"></div>
          <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="accepting" ${a.accepting ? 'checked' : ''}> Accepting new bookings</label><button type="submit" class="${UI.btn} ${UI.primary} !py-2">Save</button></form></div></div>`;
  }
  const warn = (r) => { if (r.affectedBookings && r.affectedBookings.length) App.toast(`${r.affectedBookings.length} existing booking(s) fall outside your new hours. They were kept and the clinic team has been alerted.`, 'info'); };
  App.forms.addRule = async (f, d) => { const r = await App.api.post('/availability', { ...d, dayOfWeek: d.dayOfWeek !== undefined ? +d.dayOfWeek : undefined, slotMinutes: +d.slotMinutes }); App.toast('Availability saved.', 'success'); warn(r); await App.reloadTab(); };
  App.actions.delRule = async (el) => { const r = await App.api.del(`/availability/${el.dataset.id}`); warn(r); await App.reloadTab(); };
  App.forms.addBlocked = async (f, d) => { const r = await App.api.post('/availability/blocked', d); App.toast('Date blocked.', 'success'); warn(r); await App.reloadTab(); };
  App.actions.delBlocked = async (el) => { await App.api.del(`/availability/blocked/${el.dataset.id}`); await App.reloadTab(); };
  App.forms.consProfile = async (f, d) => { await App.api.patch('/availability/profile', { specialty: d.specialty, accepting: !!d.accepting }); App.toast('Profile saved.', 'success'); };
  App.portalSubtitle = ((prev) => (u, portal) => (portal === 'consultant' ? 'Your consultations, patients, prescriptions and availability.' : prev(u, portal)))(App.portalSubtitle);
})(window.App);
