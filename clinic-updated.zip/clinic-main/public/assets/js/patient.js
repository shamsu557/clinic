'use strict';
/* Patient portal. */
(function (App) {
  const { esc, btn, UI, empty } = App;
  App.tabs.patient = [
    { id: 'upcoming', label: 'Today & Upcoming', render: async (el) => {
      const [t, u, r] = await Promise.all([App.api.get('/bookings?scope=today&as=patient'), App.api.get('/bookings?scope=upcoming&as=patient'), App.api.get('/reschedules?as=patient')]);
      const alts = r.requests.filter((x) => x.status === 'alternative_proposed');
      el.innerHTML = `${alts.length ? `<div class="mb-6 p-4 bg-purple-50 border border-purple-200 rounded-xl"><div class="font-bold text-purple-800 mb-2">The clinic proposed a new time</div>${alts.map((a) => `<div class="flex flex-wrap items-center justify-between gap-2 py-2"><span class="text-sm">${esc(a.code)}: ${esc(App.fmtDate(a.newDate))} at ${esc(App.fmtTime(a.newStartTime))}</span>${btn('Review', 'openBooking', 'primary', `data-id="${a.bookingId}"`)}</div>`).join('')}</div>` : ''}
        <h2 class="text-xl font-bold mb-3">Today's consultations</h2>${App.bookingList(t.bookings.filter((b) => b.status !== 'rejected'))}
        <h2 class="text-xl font-bold mt-8 mb-1">Upcoming appointments</h2>${App.groupedBookings(u.bookings)}`;
    } },
    { id: 'records', label: 'Test results & documents', render: (el) => App.records.tab(el) },
    { id: 'prescriptions', label: 'Prescriptions', render: (el) => App.records.prescriptions(el) },
    { id: 'payments', label: 'Payments', render: (el) => App.records.payments(el) },
    { id: 'history', label: 'History', render: async (el) => {
      const h = await App.api.get('/bookings?scope=history&as=patient');
      el.innerHTML = `<h2 class="text-xl font-bold mb-3">Past &amp; closed bookings</h2><p class="text-sm text-gray-500 mb-4">Completed, cancelled, not-consulted and rejected bookings, and appointments whose date has passed.</p>${App.groupedBookings(h.bookings)}`;
    } },
  ];
  App.portalSubtitle = (u, portal) => (portal === 'patient' ? 'Book consultations, upload payment receipts and join your video visits.' : '');
  App.portalActions = (u, portal) => (portal === 'patient' ? `<div class="flex flex-wrap gap-2">${btn('+ Book a consultation', 'openWizard', 'primary')}${btn('Upload test result', 'openUpload', 'ghost')}</div>` : '');
  App.actions.openWizard = () => App.openWizard();
})(window.App);
