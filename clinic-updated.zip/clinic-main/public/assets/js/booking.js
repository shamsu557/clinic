'use strict';
/* Shared booking UI: cards, detail modal with role-specific actions, slot picker, booking wizard. */
(function (App) {
  const { esc, UI, btn, badge, money, fmtDate, fmtTime, fmtDT, empty } = App; const S = App.state;
  const field = (label, name, type = 'text', extra = '') => `<div><label class="${UI.label}" for="b_${name}">${label}</label><input id="b_${name}" name="${name}" type="${type}" class="${UI.input}" ${extra}></div>`;

  // ---------- WhatsApp: patient taps a button to message the clinic about a booking / reschedule ----------
  App.waNumber = async () => {
    if (S.waNumber === undefined) { try { S.waNumber = (await App.api.get('/settings/contact')).whatsappNumber || null; } catch (_) { S.waNumber = null; } }
    return S.waNumber;
  };
  const waHref = (num, text) => `https://wa.me/${String(num).replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
  const waButton = (num, text, label) => `<a href="${esc(waHref(num, text))}" target="_blank" rel="noopener noreferrer" class="${UI.btn} bg-[#25D366] hover:bg-[#1ebe5b] text-white shadow w-full py-3 text-base">
    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2zm0 18.2a8.2 8.2 0 01-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1112 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.700 6.700 0 01-3.300-2.900c-.2-.4.200-.4.700-1.300.1-.2 0-.3 0-.5l-.8-1.800c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.100-.7.300-.2.300-.9.900-.9 2.200s.9 2.500 1 2.700c.1.200 1.800 2.800 4.400 3.900 1.600.7 2.300.7 3.100.6.500-.1 1.500-.6 1.700-1.200.2-.6.200-1.100.2-1.200-.100-.2-.3-.3-.5-.4z"/></svg>${label}</a>`;
  /** Confirmation dialog shown right after a patient books / asks to reschedule, with the WhatsApp button. */
  App.sentDialog = async ({ title, lead, lines, waText }) => {
    const num = await App.waNumber();
    App.openModal(title, `<div class="text-center space-y-4">
      <div class="mx-auto w-14 h-14 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-3xl" aria-hidden="true">✓</div>
      <p class="text-gray-700">${esc(lead)}</p>
      <div class="text-left bg-gray-50 rounded-lg p-4 text-sm space-y-1">${lines.map((l) => `<div>${l}</div>`).join('')}</div>
      ${num ? `<p class="text-sm text-gray-600">Send the clinic a WhatsApp message about this so the team sees it straight away.</p>${waButton(num, waText, 'Send WhatsApp message to the clinic')}` : ''}
      <button type="button" data-action="closeModal" class="${UI.btn} ${UI.ghost} w-full">Done</button></div>`);
  };

  // ---------- cards ----------
  App.bookingCard = (b, { showPatient = true, showConsultant = true, pos = null } = {}) => {
    const who = [];
    if (showPatient && S.portal !== 'patient') who.push(`<span class="font-semibold">${esc(b.patientName)}</span> <span class="text-gray-500">(${esc(b.patientCode)})</span>`);
    if (showConsultant && S.portal !== 'consultant') who.push(`with <span class="font-semibold">${esc(b.consultantName)}</span>`);
    const join = b.meetUrl ? `<a href="${esc(b.meetUrl)}" target="_blank" rel="noopener noreferrer" class="${UI.btn} ${UI.success}">Join Google Meet</a>` : '';
    const waiting = !b.meetUrl && b.status === 'confirmed' ? '<span class="text-xs text-gray-500">Meeting link pending</span>' : '';
    // one-tap actions for the consultant who owns the consultation
    const mine = S.portal === 'consultant' && b.viewer === 'consultant';
    const quick = (mine && b.status === 'confirmed' && App.hasStarted(b) ? btn('✔ Mark done', 'setStatus', 'success', `data-id="${b.id}" data-status="completed"`) : '')
      + (mine && b.status === 'confirmed' && App.hasEnded(b) ? btn('Not consulted', 'setStatus', 'ghost', `data-id="${b.id}" data-status="missed"`) : '')
      + (S.portal === 'patient' && b.status === 'missed' ? btn('Request reschedule', 'openBooking', 'primary', `data-id="${b.id}"`) : '');
    const posBadge = pos ? `<span class="inline-flex w-7 h-7 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-bold" title="Order of the day">${pos}</span>` : '';
    return `<div class="${UI.card} p-4 ${b.overdue ? 'border-l-4 border-l-red-400' : ''}"><div class="flex flex-wrap justify-between gap-3">
      <div><div class="flex flex-wrap items-center gap-2 mb-1">${posBadge}<span class="text-lg font-bold text-gray-900">${esc(fmtTime(b.startTime))}</span><span class="text-gray-600">${esc(fmtDate(b.date))}</span>${badge(b.status)}${b.overdue ? '<span class="text-xs font-bold text-red-600">Date passed</span>' : ''}</div>
        <div class="text-sm text-gray-800">${esc(b.serviceName)} • ${esc(money(b.fee))}</div>
        <div class="text-sm text-gray-600">${who.join(' ')}</div>
        <div class="text-xs text-gray-400 mt-1">${esc(b.code)}${b.paymentStatus ? ` • Payment: ${esc(b.paymentStatus)}` : ''}</div></div>
      <div class="flex flex-col items-end gap-2">${join}${waiting}${quick}${btn('Details', 'openBooking', 'ghost', `data-id="${b.id}"`)}</div></div></div>`;
  };
  // Order inside a day never changes: earliest time slot first, and for the same time whoever booked first. Cancelled/rejected are not numbered.
  const counts = (st) => !['cancelled', 'rejected'].includes(st);
  App.bookingList = (list, opts) => { let n = 0; return list.length ? `<div class="space-y-3">${list.map((b) => App.bookingCard(b, { ...opts, pos: counts(b.status) ? ++n : null })).join('')}</div>` : empty('Nothing to show here yet.'); };
  /** Group a (date-sorted) list under date headings. */
  App.groupedBookings = (list, opts) => {
    if (!list.length) return empty('Nothing to show here yet.');
    const groups = []; list.forEach((b) => { const g = groups[groups.length - 1]; if (g && g.date === b.date) g.items.push(b); else groups.push({ date: b.date, items: [b] }); });
    return groups.map((g) => `<h3 class="text-sm font-bold uppercase tracking-wide text-gray-500 mt-6 mb-2">${esc(fmtDate(g.date))}${g.date === App.today() ? ' — Today' : ''}</h3><div class="space-y-3">${(() => { let n = 0; return g.items.map((b) => App.bookingCard(b, { ...opts, pos: counts(b.status) ? ++n : null })).join(''); })()}</div>`).join('');
  };

  // ---------- slot picker (used by wizard, arrange, reschedule decisions) ----------
  App.slotPicker = (name) => `<div data-slotpicker="${name}"><label class="${UI.label}">New date</label><input type="date" name="${name}Date" min="${App.today()}" data-change="loadSlots" class="${UI.input}">
    <input type="hidden" name="${name}Time"><div class="mt-3" data-slots></div></div>`;
  App.actions.loadSlots = async (el) => {
    const box = el.closest('[data-slotpicker]'); const out = box.querySelector('[data-slots]'); const form = el.closest('form');
    const cid = form.dataset.consultant; const date = el.value; box.querySelector('input[type=hidden]').value = '';
    if (!date) { out.innerHTML = ''; return; }
    out.innerHTML = '<span class="text-sm text-gray-500">Loading slots…</span>';
    const d = await App.api.get(`/consultants/${cid}/slots?date=${encodeURIComponent(date)}`);
    out.innerHTML = d.slots.length ? `<div class="grid grid-cols-3 sm:grid-cols-4 gap-2">${d.slots.map((s) => `<button type="button" data-action="pickSlot" data-time="${s.startTime.slice(0, 5)}" ${s.available ? '' : 'disabled'} class="slot-btn border rounded-lg py-2 text-sm font-semibold ${s.available ? 'border-blue-300 text-blue-700 hover:bg-blue-50' : 'border-gray-200 text-gray-400'}">${esc(fmtTime(s.startTime))}</button>`).join('')}</div>` : '<span class="text-sm text-gray-500">The consultant has no availability on this date.</span>';
  };
  App.actions.pickSlot = (el) => {
    const box = el.closest('[data-slotpicker]'); box.querySelector('input[type=hidden]').value = el.dataset.time;
    box.querySelectorAll('.slot-btn').forEach((b) => { b.classList.remove('bg-blue-600', 'text-white'); });
    el.classList.add('bg-blue-600', 'text-white');
  };

  // ---------- booking detail modal ----------
  App.openBooking = async (id) => {
    const body = App.openModal('Booking details', App.spinner, { wide: true });
    try { await renderDetail(body, id); } catch (e) { body.innerHTML = `<p class="text-red-600">${esc(e.message)}</p>`; }
  };
  App.actions.openBooking = (el) => App.openBooking(parseInt(el.dataset.id, 10));
  const refreshAfter = async (id) => { const body = document.getElementById('modalBody'); if (body) await renderDetail(body, id); App.reloadTab && App.reloadTab(); App.refreshNotifs && App.refreshNotifs(); };

  async function renderDetail(body, id) {
    const d = await App.api.get(`/bookings/${id}`); const b = d.booking; const u = S.user; const can = (p) => u.permissions.includes(p);
    const isPatient = b.viewer === 'patient'; const isConsultant = b.viewer === 'consultant';
    const hours = S.app.meetLinkHours || 3;
    const open = d.reschedules.find((r) => ['pending', 'alternative_proposed'].includes(r.status));
    const active = ['requested', 'confirmed', 'reschedule_requested'].includes(b.status);
    const now = new Date().toLocaleString('sv-SE', { timeZone: S.app.timezone || 'Africa/Lagos' }); // "YYYY-MM-DD HH:MM:SS"
    const started = `${b.date} ${b.startTime}:00` <= now; const ended = `${b.date} ${b.endTime}:00` <= now;
    const row = (k, v) => `<div class="flex justify-between gap-4 py-2 border-b border-gray-100 text-sm"><dt class="text-gray-500">${k}</dt><dd class="font-semibold text-right">${v}</dd></div>`;

    let html = `<div class="grid md:grid-cols-2 gap-6"><div><dl>
      ${row('Reference', esc(b.code))}${row('Status', badge(b.status))}${row('Service', esc(b.serviceName))}${row('Fee', esc(money(b.fee)))}
      ${row('Date', esc(fmtDate(b.date)))}${row('Time', `${esc(fmtTime(b.startTime))} – ${esc(fmtTime(b.endTime))}`)}
      ${isPatient ? '' : row('Patient', `${esc(b.patientName)} (${esc(b.patientCode)})${b.patientPhone ? `<br><span class="font-normal text-gray-500">${esc(b.patientPhone)}</span>` : ''}`)}
      ${isConsultant ? '' : row('Consultant', esc(b.consultantName))}${b.note ? row('Patient note', esc(b.note)) : ''}${row('Requested', esc(fmtDT(b.createdAt)))}</dl>
      ${b.meetUrl ? `<a href="${esc(b.meetUrl)}" target="_blank" rel="noopener noreferrer" class="${UI.btn} ${UI.success} w-full mt-4">Join Google Meet</a><p class="text-xs text-gray-500 mt-2">For privacy this link is removed automatically ${hours} hours after the consultation is marked done.</p>` : (b.hasMeetLink && !isPatient && !isConsultant ? '<p class="mt-4 p-3 bg-gray-50 rounded-lg text-sm text-gray-600">🔒 A Meet link has been added. For privacy it is visible only to the patient and the assigned consultant.</p>' : (b.status === 'confirmed' ? '<p class="mt-4 text-sm text-gray-500">The Google Meet link will appear here once the clinic adds it.</p>' : ''))}
      ${b.paymentNote ? `<p class="mt-3 p-3 bg-red-50 text-red-700 text-sm rounded-lg"><strong>Payment note:</strong> ${esc(b.paymentNote)}</p>` : ''}
      <h3 class="font-bold mt-6 mb-2">History</h3><ol class="space-y-2 text-sm border-l-2 border-gray-200 pl-4">${d.history.map((h) => `<li><div class="font-semibold">${esc(h.from && h.from !== h.to ? `${h.from} → ${h.to}` : h.to)}</div><div class="text-gray-600">${esc(h.note || '')}</div><div class="text-xs text-gray-400">${esc(fmtDT(h.at))}${h.by ? ` • ${esc(h.by)}` : ''}</div></li>`).join('')}</ol></div><div class="space-y-5">`;

    // patient: message the clinic on WhatsApp about this booking
    if (isPatient && ['requested', 'confirmed', 'reschedule_requested', 'missed'].includes(b.status)) {
      const num = await App.waNumber();
      if (num) html += `<div>${waButton(num, `Hello The Clinic, this is ${u.fullName} about booking ${b.code} (${b.serviceName}, ${fmtDate(b.date)} at ${fmtTime(b.startTime)}).`, 'Message the clinic on WhatsApp')}</div>`;
    }

    // receipts
    if (d.receipts.length) html += `<div><h3 class="font-bold mb-2">Payment receipt${d.receipts.length > 1 ? 's' : ''}</h3><ul class="space-y-2">${d.receipts.map((r) => `<li class="p-3 border rounded-lg text-sm flex justify-between gap-3 items-center"><div><div class="font-semibold">${esc(r.name)}</div><div class="text-xs text-gray-500">${esc(fmtDT(r.uploadedAt))} • ${esc(r.status)}${r.reviewer ? ` by ${esc(r.reviewer)}` : ''}${r.note ? ` — ${esc(r.note)}` : ''}</div></div>
      <a class="${UI.btn} ${UI.ghost}" href="/api/receipts/${r.id}" target="_blank" rel="noopener noreferrer">View</a></li>`).join('')}</ul></div>`;

    // reschedule info
    if (open) {
      html += `<div class="p-4 bg-purple-50 rounded-lg text-sm"><div class="font-bold text-purple-800 mb-1">Reschedule request (${esc(open.status === 'pending' ? 'awaiting review' : 'alternative proposed')})</div><div>${esc(open.reason)}</div>${open.preferredDate ? `<div class="text-gray-600 mt-1">Preferred: ${esc(fmtDate(open.preferredDate))} ${esc(fmtTime(open.preferredTime || ''))}</div>` : ''}
        ${open.status === 'alternative_proposed' ? `<div class="mt-2 font-semibold">Proposed: ${esc(fmtDate(open.newDate))} at ${esc(fmtTime(open.newStartTime))}${open.note ? ` — ${esc(open.note)}` : ''}</div>` : ''}</div>`;
      if (isPatient && open.status === 'alternative_proposed') html += `<div class="flex gap-2">${btn('Accept new time', 'respondAlt', 'success', `data-id="${open.id}" data-accept="1" data-booking="${b.id}"`)}${btn('Decline', 'respondAlt', 'ghost', `data-id="${open.id}" data-accept="0" data-booking="${b.id}"`)}</div>`;
      // a consultation that was not held can only be rescheduled by owner / administrators / support
      if (!isPatient && (b.status === 'missed' ? can('reschedule.review') : (isConsultant || can('reschedule.review')))) html += decisionForm(open, b);
    }

    // patient actions
    if (isPatient) {
      if (b.status === 'requested') html += `<form data-form="reupload" data-booking="${b.id}" class="p-4 border rounded-lg space-y-2"><div class="font-semibold text-sm">Uploaded the wrong receipt?</div><input type="file" name="receipt" accept="image/jpeg,image/png,application/pdf" required class="text-sm"><button type="submit" class="${UI.btn} ${UI.ghost}">Replace receipt</button></form>`;
      if (b.status === 'missed') html += `<div class="p-4 bg-red-50 border border-red-200 rounded-lg text-sm"><div class="font-bold text-red-700 mb-1">Not consulted</div>This consultation did not take place. ${open ? 'Your reschedule request is waiting for the clinic to approve a new time.' : 'Request a new time below — the clinic will review it and confirm a new date.'}</div>`;
      if ((b.status === 'confirmed' && !started) || (b.status === 'missed' && !open)) html += `<form data-form="reschedule" data-booking="${b.id}" class="p-4 border rounded-lg space-y-3"><div class="font-bold">${b.status === 'missed' ? 'Request a new time' : 'Request a reschedule'}</div>
        <div><label class="${UI.label}">Reason *</label><textarea name="reason" required minlength="5" maxlength="500" rows="2" class="${UI.input}"></textarea></div>
        <div class="grid grid-cols-2 gap-3"><div><label class="${UI.label}">Preferred date</label><input type="date" name="preferredDate" min="${App.today()}" class="${UI.input}"></div><div><label class="${UI.label}">Preferred time</label><input type="time" name="preferredTime" class="${UI.input}"></div></div>
        <button type="submit" class="${UI.btn} ${UI.primary}">Submit request</button></form>`;
      if (active && !started) html += cancelForm(b);
    }

    // consultant actions
    if (isConsultant) {
      html += `<div class="flex flex-wrap gap-2">`;
      if (['confirmed', 'reschedule_requested', 'completed'].includes(b.status)) html += btn('Open patient records &amp; prescribe', 'openRecords', 'primary', `data-patient="${b.patientId}" data-booking="${b.id}"`);
      if (['confirmed', 'missed'].includes(b.status) && started) html += btn('✔ Mark consultation done', 'setStatus', 'success', `data-id="${b.id}" data-status="completed"`);
      if (b.status === 'confirmed' && ended) html += btn('Mark not consulted', 'setStatus', 'ghost', `data-id="${b.id}" data-status="missed"`);
      html += `</div>`;
      if (active) html += cancelForm(b, true);
    }

    // staff actions
    if (!isPatient) {
      if (b.status === 'requested' && can('payments.verify')) html += `<form data-form="payment" data-booking="${b.id}" class="p-4 border-2 border-yellow-300 bg-yellow-50 rounded-lg space-y-3">
        <div class="font-bold">Verify payment</div><div class="text-sm">Expected fee: <strong>${esc(money(b.fee))}</strong>. Open the receipt, then approve or reject.</div>
        <label class="flex items-start gap-2 text-sm"><input type="checkbox" name="amountConfirmed" class="mt-1"> I have checked the receipt and the amount matches the fee.</label>
        <div><label class="${UI.label}">Note (required if rejecting)</label><input name="note" maxlength="500" class="${UI.input}"></div>
        <div class="flex gap-2"><button type="submit" name="decision" value="approve" class="${UI.btn} ${UI.success}">Approve payment</button><button type="submit" name="decision" value="reject" class="${UI.btn} ${UI.danger}">Reject</button></div></form>`;
      if (can('meet.manage') && b.status === 'confirmed') html += `<form data-form="meet" data-booking="${b.id}" class="p-4 border rounded-lg space-y-3"><div class="font-bold">Google Meet link</div>
        <input name="url" type="url" required value="${esc(b.meetUrl || '')}" autocomplete="off" placeholder="https://meet.google.com/abc-defg-hij" class="${UI.input}">
        <div class="flex flex-wrap gap-2"><button type="submit" class="${UI.btn} ${UI.primary}">${b.hasMeetLink ? 'Update link' : 'Save link'}</button>
        ${S.app.googleMeetAutomation ? btn('Generate with Google', 'genMeet', 'ghost', `data-id="${b.id}"`) : ''}${b.hasMeetLink ? btn('Remove', 'removeMeet', 'ghost', `data-id="${b.id}"`) : ''}</div>
        <p class="text-xs text-gray-500">Create a meeting at meet.google.com and paste the link here. Once saved, only this patient and the assigned consultant can see it — not even other staff or the Owner.</p></form>`;
      if (can('bookings.manage') && ['requested', 'confirmed', 'reschedule_requested', 'missed'].includes(b.status)) html += `<form data-form="arrange" data-booking="${b.id}" data-consultant="${b.consultantId}" class="p-4 border rounded-lg space-y-3"><div class="font-bold">Arrange a new date &amp; time</div>${App.slotPicker('new')}<input name="note" maxlength="300" placeholder="Note to patient (optional)" class="${UI.input}"><button type="submit" class="${UI.btn} ${UI.primary}">Move booking</button></form>`;
      if (can('bookings.manage')) html += `<form data-form="message" data-booking="${b.id}" class="p-4 border rounded-lg space-y-2"><div class="font-bold">Message patient (portal notification)</div><input name="message" required minlength="2" maxlength="400" class="${UI.input}"><button type="submit" class="${UI.btn} ${UI.ghost}">Send</button></form>`;
      if (can('bookings.manage') && (active || b.status === 'missed')) html += cancelForm(b, true);
    }
    body.innerHTML = html + '</div></div>';
  }

  const cancelForm = (b, needNote) => `<form data-form="cancelBooking" data-booking="${b.id}" class="p-4 border border-red-200 rounded-lg space-y-2"><div class="font-bold text-red-700">Cancel this booking</div>
    <input name="note" ${needNote ? 'required' : ''} maxlength="500" placeholder="${needNote ? 'Reason (required)' : 'Reason (optional)'}" class="${UI.input}"><button type="submit" class="${UI.btn} ${UI.danger}">Cancel booking</button></form>`;
  const decisionForm = (r, b) => `<form data-form="decide" data-request="${r.id}" data-booking="${b.id}" data-consultant="${b.consultantId}" class="p-4 border rounded-lg space-y-3"><div class="font-bold">Decide on this request</div>
    ${App.slotPicker('new')}<input name="note" maxlength="500" placeholder="Note to patient (required if declining)" class="${UI.input}">
    <div class="flex flex-wrap gap-2"><button type="submit" name="decision" value="approve" class="${UI.btn} ${UI.success}">Approve new time</button><button type="submit" name="decision" value="propose" class="${UI.btn} ${UI.primary}">Propose alternative</button><button type="submit" name="decision" value="reject" class="${UI.btn} ${UI.danger}">Decline</button></div></form>`;

  // ---------- form handlers inside the detail modal (submitter-aware) ----------
  document.addEventListener('submit', (e) => { const f = e.target; if (f.dataset && f.dataset.form && e.submitter && e.submitter.name) f._submitter = { name: e.submitter.name, value: e.submitter.value }; }, true);
  const bid = (f) => parseInt(f.dataset.booking, 10);
  App.forms.payment = async (f, d) => {
    const decision = f._submitter.value; if (decision === 'reject' && !d.note.trim()) throw new Error('Please enter the reason for rejecting this payment.');
    await App.api.post(`/bookings/${bid(f)}/payment`, { decision, note: d.note, amountConfirmed: !!d.amountConfirmed });
    App.toast(decision === 'approve' ? 'Payment approved. Add the Meet link next.' : 'Payment rejected and slot released.', 'success'); await refreshAfter(bid(f));
  };
  App.forms.meet = async (f, d) => { await App.api.put(`/bookings/${bid(f)}/meet`, { url: d.url }); App.toast('Meet link saved and shared with the patient and consultant.', 'success'); await refreshAfter(bid(f)); };
  App.actions.genMeet = async (el) => { await App.api.post(`/bookings/${el.dataset.id}/meet/generate`); App.toast('Meet link created.', 'success'); await refreshAfter(parseInt(el.dataset.id, 10)); };
  App.actions.removeMeet = async (el) => { if (!confirm('Remove the Meet link from this booking?')) return; await App.api.del(`/bookings/${el.dataset.id}/meet`); await refreshAfter(parseInt(el.dataset.id, 10)); };
  App.forms.arrange = async (f, d) => { if (!d.newTime) throw new Error('Please pick a date and an available time slot.'); await App.api.post(`/bookings/${bid(f)}/arrange`, { date: d.newDate, startTime: d.newTime, note: d.note }); App.toast('Booking moved. The patient and consultant were notified.', 'success'); await refreshAfter(bid(f)); };
  App.forms.message = async (f, d) => { await App.api.post(`/bookings/${bid(f)}/message`, { message: d.message }); f.reset(); App.toast('Message sent to the patient’s portal.', 'success'); };
  App.forms.cancelBooking = async (f, d) => { if (!confirm('Cancel this booking?')) return; await App.api.post(`/bookings/${bid(f)}/status`, { status: 'cancelled', note: d.note }); App.toast('Booking cancelled.', 'success'); await refreshAfter(bid(f)); };
  App.actions.setStatus = async (el) => {
    const hours = S.app.meetLinkHours || 3;
    if (el.dataset.status === 'completed' && !confirm(`Mark this consultation as done? The meeting link will be removed automatically after ${hours} hours.`)) return;
    if (el.dataset.status === 'missed' && !confirm('Mark this consultation as NOT consulted? The patient will be able to request a reschedule.')) return;
    await App.api.post(`/bookings/${el.dataset.id}/status`, { status: el.dataset.status }); App.toast(el.dataset.status === 'completed' ? 'Consultation marked as done.' : 'Marked as not consulted.', 'success'); await refreshAfter(parseInt(el.dataset.id, 10));
  };
  App.forms.reschedule = async (f, d) => {
    const id = bid(f);
    await App.api.post(`/bookings/${id}/reschedule`, { reason: d.reason, preferredDate: d.preferredDate || null, preferredTime: d.preferredTime || null });
    const b = (await App.api.get(`/bookings/${id}`)).booking; App.reloadTab && App.reloadTab(); App.refreshNotifs && App.refreshNotifs();
    await App.sentDialog({ title: 'Reschedule request sent', lead: 'The clinic will review your request and confirm a new time.',
      lines: [`<strong>Booking:</strong> ${esc(b.code)}`, `<strong>Current slot:</strong> ${esc(fmtDate(b.date))} at ${esc(fmtTime(b.startTime))}`],
      waText: `Hello The Clinic, I have asked to reschedule booking ${b.code} (${fmtDate(b.date)} at ${fmtTime(b.startTime)}). Please review and confirm a new time. Thank you.` });
  };
  App.forms.reupload = async (f) => { const fd = new FormData(f); await App.api.form(`/bookings/${bid(f)}/receipt`, fd); App.toast('Receipt replaced.', 'success'); await refreshAfter(bid(f)); };
  App.actions.respondAlt = async (el) => { await App.api.post(`/reschedules/${el.dataset.id}/respond`, { accept: el.dataset.accept === '1' }); App.toast(el.dataset.accept === '1' ? 'New time accepted.' : 'Alternative declined.', 'success'); await refreshAfter(parseInt(el.dataset.booking, 10)); };
  App.forms.decide = async (f, d) => {
    const decision = f._submitter.value;
    if (decision !== 'reject' && !d.newTime) throw new Error('Please pick a date and an available time slot.');
    if (decision === 'reject' && !d.note.trim()) throw new Error('Please add a note explaining why the request is declined.');
    await App.api.post(`/reschedules/${f.dataset.request}/decision`, { decision, newDate: d.newDate, newStartTime: d.newTime, note: d.note });
    App.toast('Decision saved and the patient was notified.', 'success'); await refreshAfter(bid(f));
  };
  App.actions.noop = () => {};

  // ---------- booking wizard (patient) ----------
  let bw = null;
  App.openWizard = async () => {
    bw = { service: null, consultant: null, date: '', time: '', file: null, note: '' };
    const body = App.openModal('Book a consultation', App.spinner, { wide: true });
    try {
      const [s, c, p] = await Promise.all([App.api.get('/services'), App.api.get('/consultants'), App.api.get('/settings/payment')]);
      bw.services = s.services; bw.consultants = c.consultants; bw.pay = p;
      if (!bw.services.length) { body.innerHTML = empty('No consultation services are available yet. Please check back soon.'); return; }
      if (!bw.consultants.length) { body.innerHTML = empty('No consultants are accepting bookings right now.'); return; }
      drawWizard();
    } catch (e) { body.innerHTML = `<p class="text-red-600">${esc(e.message)}</p>`; }
  };
  function drawWizard() {
    const body = document.getElementById('modalBody'); if (!body || !bw) return;
    const sel = (cond) => (cond ? 'border-blue-600 bg-blue-50 ring-2 ring-blue-200' : 'border-gray-200 hover:border-blue-300');
    let h = `<div class="space-y-6"><section><h3 class="font-bold mb-2">1. Choose a service</h3><div class="grid sm:grid-cols-2 gap-3">${bw.services.map((s) => `<button type="button" data-action="wzService" data-id="${s.id}" class="text-left p-4 border-2 rounded-xl ${sel(bw.service && bw.service.id === s.id)}"><div class="font-bold">${esc(s.name)}</div><div class="text-sm text-gray-600">${esc(s.description || '')}</div><div class="mt-2 text-lg font-extrabold text-blue-700">${esc(money(s.fee))}</div></button>`).join('')}</div></section>`;
    if (bw.service) h += `<section><h3 class="font-bold mb-2">2. Choose a consultant</h3><div class="grid sm:grid-cols-2 gap-3">${bw.consultants.map((c) => `<button type="button" data-action="wzConsultant" data-id="${c.id}" class="text-left p-4 border-2 rounded-xl ${sel(bw.consultant && bw.consultant.id === c.id)}"><div class="font-bold">${esc(c.fullName)}</div><div class="text-sm text-gray-600">${esc(c.specialty || 'Consultant')}</div></button>`).join('')}</div></section>`;
    if (bw.consultant) {
      h += `<section><h3 class="font-bold mb-2">3. Pick a date</h3>`;
      if (!bw.dates) h += '<p class="text-sm text-gray-500">Loading available dates…</p>';
      else if (!bw.dates.length) h += `<p class="p-3 bg-yellow-50 text-yellow-800 rounded-lg text-sm">${esc(bw.consultant.fullName)} has no free slots in the coming weeks. Please try another consultant.</p>`;
      else h += `<div class="flex gap-2 flex-wrap max-h-40 overflow-y-auto">${bw.dates.map((d) => `<button type="button" data-action="wzDate" data-date="${d.date}" class="px-3 py-2 rounded-lg border-2 text-sm font-semibold ${sel(bw.date === d.date)}">${esc(fmtDate(d.date).replace(/ \d{4}$/, ''))}<span class="block text-xs font-normal text-gray-500">${d.freeSlots} free</span></button>`).join('')}</div>`;
      h += '</section>';
    }
    if (bw.date) {
      h += `<section><h3 class="font-bold mb-2">4. Pick a time</h3>${!bw.slots ? '<p class="text-sm text-gray-500">Loading…</p>' : `<div class="grid grid-cols-3 sm:grid-cols-5 gap-2">${bw.slots.map((s) => `<button type="button" data-action="wzTime" data-time="${s.startTime.slice(0, 5)}" ${s.available ? '' : 'disabled'} class="slot-btn border-2 rounded-lg py-2 text-sm font-semibold ${s.available ? sel(bw.time === s.startTime.slice(0, 5)) : 'border-gray-200 text-gray-400'}">${esc(fmtTime(s.startTime))}</button>`).join('')}</div>`}</section>`;
    }
    if (bw.time) {
      const p = bw.pay;
      h += `<section><h3 class="font-bold mb-2">5. Pay &amp; upload your receipt</h3>
        <div class="p-4 bg-blue-50 border border-blue-200 rounded-xl text-sm space-y-1"><div class="text-gray-700">Please pay <strong class="text-lg text-blue-800">${esc(money(bw.service.fee))}</strong> to:</div>
          <div><span class="text-gray-500">Account name:</span> <strong>${esc(p.accountName)}</strong></div><div><span class="text-gray-500">Bank:</span> <strong>${esc(p.bank)}</strong></div>
          <div><span class="text-gray-500">Account number:</span> <strong class="text-lg tracking-wider">${esc(p.accountNumber)}</strong></div>${p.instructions ? `<div class="text-gray-600 pt-1">${esc(p.instructions)}</div>` : ''}</div>
        <form data-form="wzSubmit" class="mt-4 space-y-4"><div><label class="${UI.label}" for="wz_receipt">Payment receipt (JPG, PNG or PDF, max ${esc(S.app.maxReceiptMb || 5)} MB) *</label>
          <input id="wz_receipt" type="file" data-change="wzFile" accept="image/jpeg,image/png,application/pdf" class="${UI.input}">${bw.file ? `<p class="text-sm text-green-700 mt-1">Selected: ${esc(bw.file.name)}</p>` : ''}</div>
          <div><label class="${UI.label}" for="wz_note">Note for the consultant (optional)</label><textarea id="wz_note" name="note" rows="2" maxlength="500" class="${UI.input}">${esc(bw.note)}</textarea></div>
          <div class="p-3 bg-gray-50 rounded-lg text-sm">${esc(bw.service.name)} with <strong>${esc(bw.consultant.fullName)}</strong> on <strong>${esc(fmtDate(bw.date))}</strong> at <strong>${esc(fmtTime(bw.time))}</strong></div>
          <p class="text-xs text-gray-500">Your booking is confirmed only after the clinic verifies your payment.</p>
          <button type="submit" class="w-full ${UI.btn} ${UI.primary} py-3 font-bold">Submit booking request</button></form></section>`;
    }
    body.innerHTML = h + '</div>';
  }
  App.actions.wzService = (el) => { bw.service = bw.services.find((s) => s.id === +el.dataset.id); drawWizard(); };
  App.actions.wzConsultant = async (el) => {
    bw.consultant = bw.consultants.find((c) => c.id === +el.dataset.id); bw.dates = null; bw.date = ''; bw.time = ''; bw.slots = null; drawWizard();
    const d = await App.api.get(`/consultants/${bw.consultant.id}/dates`); bw.dates = d.dates; drawWizard();
  };
  App.actions.wzDate = async (el) => { bw.date = el.dataset.date; bw.time = ''; bw.slots = null; drawWizard(); const d = await App.api.get(`/consultants/${bw.consultant.id}/slots?date=${bw.date}`); bw.slots = d.slots; drawWizard(); };
  App.actions.wzTime = (el) => { bw.time = el.dataset.time; drawWizard(); const r = document.getElementById('wz_receipt'); if (r) r.scrollIntoView({ block: 'center', behavior: 'smooth' }); };
  App.actions.wzFile = (el) => {
    const f = el.files[0]; if (!f) return;
    const max = (S.app.maxReceiptMb || 5) * 1048576;
    if (!['image/jpeg', 'image/png', 'application/pdf'].includes(f.type)) { el.value = ''; throw new Error('Receipts must be a JPG, PNG or PDF file.'); }
    if (f.size > max) { el.value = ''; throw new Error(`That file is too large (max ${S.app.maxReceiptMb || 5} MB).`); }
    bw.file = f; const note = document.getElementById('wz_note'); if (note) bw.note = note.value; drawWizard();
  };
  App.forms.wzSubmit = async (f, d) => {
    if (!bw.file) throw new Error('Please upload your payment receipt.');
    const fd = new FormData(); fd.append('serviceId', bw.service.id); fd.append('consultantId', bw.consultant.id); fd.append('date', bw.date); fd.append('startTime', bw.time); fd.append('note', d.note || ''); fd.append('receipt', bw.file);
    let res;
    try { res = await App.api.form('/bookings', fd); }
    catch (e) { if (e.status === 409) { bw.time = ''; bw.slots = null; drawWizard(); const s = await App.api.get(`/consultants/${bw.consultant.id}/slots?date=${bw.date}`); bw.slots = s.slots; drawWizard(); } throw e; }
    const info = { code: res.code, service: bw.service.name, consultant: bw.consultant.fullName, date: bw.date, time: bw.time, fee: bw.service.fee };
    bw = null; App.reloadTab(); App.refreshNotifs();
    await App.sentDialog({ title: 'Booking request submitted', lead: 'Thank you! Your booking is confirmed once the clinic verifies your payment — you will be notified in the portal.',
      lines: [`<strong>Reference:</strong> ${esc(info.code)}`, `<strong>Service:</strong> ${esc(info.service)} — ${esc(money(info.fee))}`, `<strong>Consultant:</strong> ${esc(info.consultant)}`, `<strong>When:</strong> ${esc(fmtDate(info.date))} at ${esc(fmtTime(info.time))}`],
      waText: `Hello The Clinic, I have just booked a consultation.\nName: ${S.user.fullName}\nRef: ${info.code}\nService: ${info.service}\nConsultant: ${info.consultant}\nWhen: ${fmtDate(info.date)} at ${fmtTime(info.time)}\nI have uploaded my payment receipt — please verify it. Thank you.` });
  };
})(window.App);
