'use strict';
/* Medical records: patient uploads / test results, lab requests, prescriptions (+PDF), payments, consultant's patient records. */
(function (App) {
  const { esc, UI, btn, badge, money, fmtDate, fmtTime, fmtDT, empty } = App; const S = App.state;
  const sizeOf = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
  const CAT = { lab_result: 'Lab test result', imaging: 'Imaging / scan', report: 'Medical report', other: 'Other' };
  const FORMATS = ['pdf', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'heic', 'heif', 'tif', 'tiff', 'doc', 'docx'];
  const icon = (m) => (m === 'application/pdf' ? '📕' : m.startsWith('image/') ? '🖼️' : '📄');
  const th = (t) => `<th class="px-4 py-3 font-semibold whitespace-nowrap">${t}</th>`;

  // ---------- documents ----------
  App.docsTable = (docs, { canDelete = false } = {}) => (docs.length ? `<div class="${UI.card} overflow-x-auto"><table class="w-full text-sm"><thead class="bg-gray-50 text-left text-gray-600"><tr>${th('Document')}${th('Type')}${th('Test date')}${th('Uploaded')}${th('')}</tr></thead><tbody class="divide-y divide-gray-100">${docs.map((d) => `<tr>
    <td class="px-4 py-3"><div class="font-semibold">${icon(d.mime)} ${esc(d.title)}</div><div class="text-xs text-gray-500">${esc(d.fileName)} · ${esc(sizeOf(d.size))}</div>${d.notes ? `<div class="text-xs text-gray-600 mt-1">${esc(d.notes)}</div>` : ''}</td>
    <td class="px-4 py-3">${esc(CAT[d.category] || d.category)}${d.testType ? `<div class="text-xs text-gray-500">${esc(d.testType)}</div>` : ''}</td>
    <td class="px-4 py-3 whitespace-nowrap">${d.testDate ? esc(fmtDate(d.testDate)) : '—'}</td><td class="px-4 py-3 whitespace-nowrap">${esc(fmtDT(d.uploadedAt))}</td>
    <td class="px-4 py-3"><div class="flex flex-wrap gap-2">${d.viewable ? `<a class="${UI.btn} ${UI.ghost} !py-1" href="/api/documents/${d.id}/file" target="_blank" rel="noopener noreferrer">View</a>` : ''}<a class="${UI.btn} ${UI.ghost} !py-1" href="/api/documents/${d.id}/file?download=1">Download</a>${canDelete ? btn('Delete', 'delDoc', 'ghost', `data-id="${d.id}"`) : ''}</div></td></tr>`).join('')}</tbody></table></div>` : empty('No documents uploaded yet.'));

  const labPanel = (requests, { patientView }) => requests.map((r) => `<div class="${UI.card} p-4"><div class="flex flex-wrap justify-between gap-2"><div><div class="font-bold">${patientView ? `Requested by ${esc(r.consultantName)}` : esc(r.patientName || 'Lab request')} <span class="text-xs font-normal text-gray-500">${esc(fmtDT(r.createdAt))}</span></div>${r.notes ? `<div class="text-sm text-gray-600">${esc(r.notes)}</div>` : ''}</div>
    <span class="text-xs font-bold px-2 py-1 rounded-full h-fit ${r.status === 'open' ? 'bg-yellow-100 text-yellow-800' : r.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-gray-200 text-gray-700'}">${esc(r.status)}</span></div>
    <ul class="mt-3 space-y-2">${r.items.map((i) => `<li class="flex flex-wrap justify-between items-center gap-2 text-sm"><span>${i.status === 'uploaded' ? '✅' : '⏳'} ${esc(i.testType)}</span>${i.status === 'pending' && patientView && r.status === 'open' ? btn('Upload result', 'openUpload', 'primary', `data-item="${i.id}" data-test="${esc(i.testType)}"`) : i.documentId && !patientView ? `<a class="${UI.btn} ${UI.ghost} !py-1" href="/api/documents/${i.documentId}/file" target="_blank" rel="noopener noreferrer">View result</a>` : ''}</li>`).join('')}</ul>
    ${!patientView && r.status === 'open' ? `<div class="mt-3">${btn('Cancel request', 'cancelLab', 'ghost', `data-id="${r.id}"`)}</div>` : ''}</div>`).join('');

  // ---------- patient tabs ----------
  App.records = {
    async tab(el) {
      const [d, l] = await Promise.all([App.api.get('/documents'), App.api.get('/lab-requests?as=patient')]);
      S.docMeta = d; const open = l.requests.filter((r) => r.status === 'open');
      el.innerHTML = `${open.length ? `<h2 class="text-xl font-bold mb-3">Tests your consultant requested</h2><div class="space-y-3 mb-8">${labPanel(open, { patientView: true })}</div>` : ''}
        <div class="flex flex-wrap justify-between items-center gap-3 mb-3"><h2 class="text-xl font-bold">My test results &amp; documents</h2>${btn('+ Upload', 'openUpload', 'primary')}</div>
        <p class="text-sm text-gray-500 mb-3">Only you and the consultant you have booked can see these. Accepted: ${d.formats.map((f) => f.toUpperCase()).join(', ')} (max ${d.maxMb} MB each).</p>${App.docsTable(d.documents, { canDelete: true })}`;
    },
    async prescriptions(el) {
      const d = await App.api.get('/prescriptions?as=patient');
      el.innerHTML = `<h2 class="text-xl font-bold mb-1">My prescriptions</h2><p class="text-sm text-gray-500 mb-4">Download the PDF and take it to your pharmacy to buy your medication.</p>` + (d.prescriptions.length ? `<div class="space-y-3">${d.prescriptions.map((p) => rxCard(p, 'patient')).join('')}</div>` : empty('No prescriptions yet. They appear here after a consultation.'));
    },
    async payments(el) {
      const d = await App.api.get('/my/payments');
      el.innerHTML = `<h2 class="text-xl font-bold mb-3">Payment history</h2>` + (d.payments.length ? `<div class="${UI.card} overflow-x-auto"><table class="w-full text-sm"><thead class="bg-gray-50 text-left text-gray-600"><tr>${['Booking', 'Service', 'Amount', 'Appointment', 'Payment', 'Updated'].map(th).join('')}</tr></thead><tbody class="divide-y divide-gray-100">${d.payments.map((p) => `<tr><td class="px-4 py-3 font-semibold">${esc(p.code)}</td><td class="px-4 py-3">${esc(p.serviceName)}</td><td class="px-4 py-3 whitespace-nowrap">${esc(money(p.amount))}</td><td class="px-4 py-3 whitespace-nowrap">${esc(fmtDate(p.date))}</td><td class="px-4 py-3"><span class="font-semibold ${p.status === 'approved' ? 'text-green-700' : p.status === 'rejected' ? 'text-red-600' : 'text-yellow-700'}">${p.status === 'approved' ? 'Verified' : p.status === 'rejected' ? 'Rejected' : 'Awaiting verification'}</span>${p.status === 'rejected' && p.note ? `<div class="text-xs text-gray-500">${esc(p.note)}</div>` : ''}</td><td class="px-4 py-3 whitespace-nowrap">${esc(fmtDT(p.reviewedAt || p.uploadedAt))}</td></tr>`).join('')}</tbody></table></div>` : empty('No payments yet.'));
    },
  };

  function rxCard(p, viewer) {
    return `<div class="${UI.card} p-4 ${p.status === 'void' ? 'opacity-70' : ''}"><div class="flex flex-wrap justify-between gap-3"><div>
      <div class="flex flex-wrap items-center gap-2"><span class="font-bold">${esc(p.rxCode)}</span>${p.status === 'void' ? '<span class="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold">VOID</span>' : '<span class="px-2 py-0.5 rounded-full bg-green-100 text-green-800 text-xs font-bold">Valid</span>'}<span class="text-xs text-gray-500">${esc(fmtDT(p.issuedAt))}</span></div>
      <div class="text-sm text-gray-700 mt-1">${viewer === 'patient' ? `By ${esc(p.consultantName)}` : `For ${esc(p.patientName)} (${esc(p.patientCode)})`} · ${esc(p.diagnosis)}</div>
      <ul class="text-sm text-gray-600 mt-2 list-disc ml-5">${p.items.map((i) => `<li><strong>${esc(i.medication)}</strong> ${esc(i.dosage)} — ${esc(i.frequency)}, ${esc(i.duration)}</li>`).join('')}</ul>${p.status === 'void' && p.voidReason ? `<div class="text-xs text-red-600 mt-2">Voided: ${esc(p.voidReason)}</div>` : ''}</div>
      <div class="flex flex-col gap-2 items-end"><a class="${UI.btn} ${UI.primary}" href="/api/prescriptions/${p.id}/pdf">⬇ Download PDF</a>${viewer === 'consultant' && p.status === 'issued' ? btn('Void', 'voidRx', 'ghost', `data-id="${p.id}"`) : ''}</div></div>${p.advice ? `<div class="mt-3 text-sm bg-gray-50 rounded-lg p-3"><strong>Advice:</strong> ${esc(p.advice)}</div>` : ''}</div>`;
  }
  App.rxCard = rxCard;

  // ---------- upload modal ----------
  App.actions.openUpload = async (el) => {
    const meta = S.docMeta || await App.api.get('/documents'); S.docMeta = meta;
    const pre = (el && el.dataset) || {};
    App.openModal('Upload test result or document', `<form data-form="uploadDoc" class="space-y-4">
      <input type="hidden" name="labItemId" value="${esc(pre.item || '')}">
      <div class="grid sm:grid-cols-2 gap-4"><div><label class="${UI.label}">What is it? *</label><select name="category" class="${UI.input}">${Object.entries(CAT).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
        <div><label class="${UI.label}">Test type</label><select name="testType" class="${UI.input}"><option value="">— Not a lab test —</option>${meta.testTypes.map((t) => `<option ${t === pre.test ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div></div>
      <div class="grid sm:grid-cols-2 gap-4"><div><label class="${UI.label}">Title (optional)</label><input name="title" maxlength="150" class="${UI.input}" placeholder="e.g. HbA1c — January"></div><div><label class="${UI.label}">Date of test</label><input type="date" name="testDate" max="${App.today()}" class="${UI.input}"></div></div>
      <div><label class="${UI.label}">File(s) * — ${meta.formats.map((f) => f.toUpperCase()).join(', ')} · max ${meta.maxMb} MB each, up to 5 files</label><input type="file" name="files" multiple required accept="${FORMATS.map((f) => '.' + f).join(',')}" class="${UI.input}"></div>
      <div><label class="${UI.label}">Notes (optional)</label><textarea name="notes" rows="2" maxlength="500" class="${UI.input}" placeholder="Anything your consultant should know"></textarea></div>
      <button type="submit" class="w-full ${UI.btn} ${UI.primary} py-3">Upload</button></form>`);
    if (pre.item) { const c = document.querySelector('[name=category]'); if (c) c.value = 'lab_result'; }
  };
  App.forms.uploadDoc = async (f) => {
    const fd = new FormData(f); const files = fd.getAll('files').filter((x) => x && x.name);
    if (!files.length) throw new Error('Please choose at least one file.');
    if (files.length > 5) throw new Error('You can upload up to 5 files at a time.');
    const max = (S.docMeta.maxMb || 10) * 1048576;
    for (const x of files) {
      const ext = x.name.split('.').pop().toLowerCase();
      if (!FORMATS.includes(ext)) throw new Error(`"${x.name}" is not a supported file type.`);
      if (x.size > max) throw new Error(`"${x.name}" is larger than ${S.docMeta.maxMb} MB.`);
    }
    if (fd.get('category') === 'lab_result' && !fd.get('testType')) throw new Error('Please choose the test type for a lab result.');
    if (!fd.get('labItemId')) fd.delete('labItemId');
    if (!fd.get('testDate')) fd.delete('testDate');
    const r = await App.api.form('/documents', fd);
    App.closeModal(); App.toast(r.linkedToRequest ? 'Uploaded. Your consultant has been notified.' : 'Uploaded successfully.', 'success'); await App.reloadTab();
  };
  App.actions.delDoc = async (el) => { if (!confirm('Delete this document? Your consultant will no longer be able to see it.')) return; await App.api.del(`/documents/${el.dataset.id}`); App.toast('Document deleted.', 'success'); await App.reloadTab(); };

  // ---------- consultant: patients, records, prescriptions ----------
  App.consultantRecords = {
    async patients(el) {
      const d = await App.api.get('/my-patients');
      el.innerHTML = `<h2 class="text-xl font-bold mb-1">My patients</h2><p class="text-sm text-gray-500 mb-4">Patients with a confirmed booking with you (or a recent completed one). You can see only your own patients' records.</p>` +
        (d.patients.length ? `<div class="${UI.card} overflow-x-auto"><table class="w-full text-sm"><thead class="bg-gray-50 text-left text-gray-600"><tr>${['Patient', 'Age / Gender', 'Bookings', 'Last visit', 'Documents', ''].map(th).join('')}</tr></thead><tbody class="divide-y divide-gray-100">${d.patients.map((p) => `<tr><td class="px-4 py-3"><div class="font-semibold">${esc(p.fullName)}</div><div class="text-xs text-gray-500">${esc(p.patientCode)}</div></td><td class="px-4 py-3">${esc(p.age ?? '')} ${esc(p.gender || '')}</td><td class="px-4 py-3">${p.bookings}</td><td class="px-4 py-3 whitespace-nowrap">${esc(fmtDate(p.lastDate))}</td><td class="px-4 py-3">${p.documents}</td><td class="px-4 py-3">${btn('Open records', 'openRecords', 'primary', `data-patient="${p.id}"`)}</td></tr>`).join('')}</tbody></table></div>` : empty('No patients yet.'));
    },
    async prescriptions(el) {
      const d = await App.api.get('/prescriptions?as=consultant');
      el.innerHTML = `<h2 class="text-xl font-bold mb-3">Prescriptions I issued</h2>` + (d.prescriptions.length ? `<div class="space-y-3">${d.prescriptions.map((p) => rxCard(p, 'consultant')).join('')}</div>` : empty('You have not issued any prescriptions yet.'));
    },
  };

  App.actions.openRecords = (el) => App.openRecords(parseInt(el.dataset.patient, 10), el.dataset.booking ? parseInt(el.dataset.booking, 10) : null);
  App.openRecords = async (pid, bookingId) => {
    const body = App.openModal('Patient records', App.spinner, { wide: true });
    try { await drawRecords(body, pid, bookingId); } catch (e) { body.innerHTML = `<p class="text-red-600">${esc(e.message)}</p>`; }
  };
  async function drawRecords(body, pid, bookingId) {
    const d = await App.api.get(`/patients/${pid}/records`); S.rec = { pid, bookingId, d };
    const bkOpts = d.bookings.map((b) => `<option value="${b.id}" ${b.id === bookingId ? 'selected' : ''}>${esc(b.code)} — ${esc(fmtDate(b.date))} ${esc(fmtTime(b.startTime))} (${esc(b.status.replace('_', ' '))})</option>`).join('');
    body.innerHTML = `<div class="p-4 bg-blue-50 rounded-xl mb-5 flex flex-wrap justify-between gap-2"><div><div class="text-lg font-bold">${esc(d.patient.fullName)}</div><div class="text-sm text-gray-600">${esc(d.patient.patientCode)} · ${esc(d.patient.age ?? '')} yrs · ${esc(d.patient.gender || '')}</div></div><div class="text-xs text-gray-500 max-w-xs">Opening these records is logged. Only you, as the booked consultant, can see them.</div></div>
      <section class="mb-8"><h3 class="font-bold text-lg mb-2">Test results &amp; documents <span class="text-sm font-normal text-gray-500">(${d.documents.length})</span></h3>${App.docsTable(d.documents)}</section>
      <section class="mb-8"><h3 class="font-bold text-lg mb-2">Lab tests</h3>${d.labRequests.length ? `<div class="space-y-3 mb-4">${labPanel(d.labRequests, { patientView: false })}</div>` : ''}
        <form data-form="newLab" class="${UI.card} p-4 space-y-3"><div class="font-semibold">Request lab tests</div><select name="bookingId" class="${UI.input}">${bkOpts}</select>
          <div class="grid sm:grid-cols-3 gap-2">${d.testTypes.map((t) => `<label class="flex items-center gap-2 text-sm border rounded-lg px-3 py-2"><input type="checkbox" name="tests" value="${esc(t)}"> ${esc(t)}</label>`).join('')}</div>
          <input name="notes" maxlength="500" placeholder="Instructions for the patient (e.g. fasting sample)" class="${UI.input}"><button type="submit" class="${UI.btn} ${UI.primary}">Send request to patient</button></form></section>
      <section><h3 class="font-bold text-lg mb-2">Prescriptions</h3>${d.prescriptions.length ? `<div class="space-y-3 mb-4">${d.prescriptions.map((p) => rxCard(p, 'consultant')).join('')}</div>` : ''}
        <form data-form="newRx" class="${UI.card} p-4 space-y-3"><div class="font-semibold">Write a prescription</div>
          <div><label class="${UI.label}">For consultation</label><select name="bookingId" class="${UI.input}">${bkOpts}</select><p class="text-xs text-gray-500 mt-1">Available once the consultation has started, and after it.</p></div>
          <div><label class="${UI.label}">Clinical diagnosis *</label><textarea name="diagnosis" required maxlength="500" rows="2" class="${UI.input}"></textarea></div>
          <div id="rxRows" class="space-y-3">${rxRow()}</div>${btn('+ Add medication', 'addRxRow', 'ghost')}
          <div><label class="${UI.label}">Medical advice</label><textarea name="advice" maxlength="1000" rows="2" class="${UI.input}"></textarea></div>
          <button type="submit" class="${UI.btn} ${UI.success}">Issue prescription</button></form></section>`;
  }
  function rxRow() {
    const i = (n, ph, req = true) => `<input name="${n}" ${req ? 'required' : ''} maxlength="${n === 'instructions' ? 300 : n === 'medication' ? 150 : 100}" placeholder="${ph}" class="${UI.input} !py-2" aria-label="${ph}">`;
    return `<div data-rx-row class="p-3 border border-gray-200 rounded-lg space-y-2 bg-gray-50"><div class="grid sm:grid-cols-2 gap-2">${i('medication', 'Medication (e.g. Metformin)')}${i('dosage', 'Dosage (e.g. 500 mg)')}${i('frequency', 'Frequency (e.g. twice daily)')}${i('duration', 'Duration (e.g. 30 days)')}</div>${i('instructions', 'Instructions (optional)', false)}<button type="button" data-action="rmRxRow" class="text-sm text-red-600 font-semibold">Remove</button></div>`;
  }
  App.actions.addRxRow = () => { const rows = document.getElementById('rxRows'); if (rows.children.length >= 15) throw new Error('A prescription can have up to 15 medications.'); rows.insertAdjacentHTML('beforeend', rxRow()); };
  App.actions.rmRxRow = (el) => { const rows = document.getElementById('rxRows'); if (rows.children.length > 1) el.closest('[data-rx-row]').remove(); };
  const refresh = async () => { const b = document.getElementById('modalBody'); if (b && S.rec) await drawRecords(b, S.rec.pid, S.rec.bookingId); App.reloadTab && App.reloadTab(); };
  App.forms.newRx = async (f, d) => {
    const items = [...f.querySelectorAll('[data-rx-row]')].map((r) => Object.fromEntries([...r.querySelectorAll('input')].map((x) => [x.name, x.value.trim()])));
    await App.api.post('/prescriptions', { bookingId: +d.bookingId, diagnosis: d.diagnosis, advice: d.advice, items });
    App.toast('Prescription issued. The patient can now download it.', 'success'); await refresh();
  };
  App.forms.newLab = async (f, d) => {
    const tests = [...f.querySelectorAll('[name=tests]:checked')].map((x) => x.value);
    if (!tests.length) throw new Error('Select at least one test.');
    await App.api.post('/lab-requests', { bookingId: +d.bookingId, tests, notes: d.notes });
    App.toast('Lab test request sent to the patient.', 'success'); await refresh();
  };
  App.actions.cancelLab = async (el) => { if (!confirm('Cancel this lab request?')) return; await App.api.post(`/lab-requests/${el.dataset.id}/cancel`); await refresh(); };
  App.actions.voidRx = async (el) => {
    const reason = prompt('Why is this prescription being voided? (the patient will be told)');
    if (!reason || reason.trim().length < 5) { if (reason !== null) throw new Error('Please give a reason of at least 5 characters.'); return; }
    await App.api.post(`/prescriptions/${el.dataset.id}/void`, { reason: reason.trim() }); App.toast('Prescription voided.', 'success');
    if (document.getElementById('modalBody') && S.rec) await refresh(); else await App.reloadTab();
  };
})(window.App);
