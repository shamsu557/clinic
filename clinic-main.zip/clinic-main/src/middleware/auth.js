'use strict';
const { db } = require('../db');
const { HttpError } = require('../lib/validate');

const PORTAL_PRIORITY = ['staff', 'consultant', 'patient'];

/** Loads the signed-in user fresh from MySQL on every request so disabled accounts / role changes apply immediately. */
async function loadUser(req, res, next) {
  try {
    const id = req.session && req.session.userId;
    if (!id) return next();
    const [rows] = await db.query(
      `SELECT id, full_name, email, phone, status, must_change_password, must_setup_security FROM users WHERE id = ?`, [id]);
    const u = rows[0];
    if (!u || u.status !== 'active') return req.session.destroy(() => next());
    const [roles] = await db.query(
      `SELECT r.id, r.code, r.name, r.portal, r.rank_level FROM user_roles ur JOIN roles r ON r.id = ur.role_id
        WHERE ur.user_id = ? ORDER BY r.rank_level DESC, r.name`, [id]);
    if (!roles.length) return req.session.destroy(() => next());
    const [perms] = await db.query(
      `SELECT DISTINCT p.code FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id
         JOIN permissions p ON p.id = rp.permission_id WHERE ur.user_id = ?`, [id]);
    const portals = PORTAL_PRIORITY.filter((p) => roles.some((r) => r.portal === p));
    req.user = {
      id: u.id, fullName: u.full_name, email: u.email, phone: u.phone,
      roles: roles.map((r) => ({ id: r.id, code: r.code, name: r.name, portal: r.portal, rank: r.rank_level })),
      roleCode: roles[0].code, roleName: roles.map((r) => r.name).join(' + '),
      rank: Math.max(...roles.map((r) => r.rank_level)),
      isOwner: roles.some((r) => r.code === 'owner'),
      isConsultant: roles.some((r) => r.portal === 'consultant'),
      portals, portal: portals[0],               // default portal; users with several roles can switch
      permissions: perms.map((p) => p.code),
      mustChangePassword: !!u.must_change_password, mustSetupSecurity: !!u.must_setup_security,
    };
    next();
  } catch (e) { next(e); }
}

function requireAuth(req, res, next) {
  if (!req.user) return next(new HttpError(401, 'Please sign in to continue.'));
  next();
}

/** Blocks everything except the setup endpoints until first-time setup is complete. */
function requireReady(req, res, next) {
  if (req.user.mustChangePassword || req.user.mustSetupSecurity) {
    const err = new HttpError(403, 'Please complete your first-time account setup.');
    err.code = 'SETUP_REQUIRED';
    return next(err);
  }
  next();
}

/** Passes if the user has ANY of the listed portals (a user may hold several roles). */
const requirePortal = (...portals) => (req, res, next) =>
  portals.some((p) => req.user.portals.includes(p)) ? next() : next(new HttpError(403, 'You do not have access to this area.'));

/** Passes if the user holds ANY of the listed permissions. */
const requirePerm = (...perms) => (req, res, next) =>
  perms.some((p) => req.user.permissions.includes(p)) ? next() : next(new HttpError(403, 'You do not have permission to do that.'));

const can = (user, perm) => user.permissions.includes(perm);

module.exports = { loadUser, requireAuth, requireReady, requirePortal, requirePerm, can };
