'use strict';
/* Patient documents / test results, lab test requests, prescriptions (+PDF), consultant access to patient records. */
const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const config = require('../config');
const { db, tx } = require('../db');
const S = require('../lib/security');
const V = require('../lib/validate');
const T = require('../lib/time');
const { audit } = require('../lib/audit');
const { notify } = require('../lib/notify');
const { writePrescriptionPdf } = require('../lib/prescriptionPdf');
const { requirePortal } = require('../middleware/auth');

const router = express.Router();
const { HttpError, bad } = V;

const DOC_DIR = path.join(config.uploadDir, 'documents');
fs.mkdirSync(DOC_DIR, { recursive: true });

const TEST_TYPES = ['HbA1c', 'Fasting Blood Sugar', 'Lipid Profile', 'Kidney Function', 'Liver Function', 'Other'];
const CATEGORIES = ['lab_result', 'imaging', 'report', 'other'];

// ---- supported formats: extension -> allowed sniffed mime types
const EXT = {
  pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp',
  heic: 'image/heic', heif: 'image/heic', tif: 'image/tiff', tiff: 'image/tiff',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};
const INLINE = new Set(['application/pdf', 'image/png', 'image/jpeg', 'image/gif', 'image/webp']);
const extOf = (n) => (path.extname(String(n || '')).slice(1) || '').toLowerCase();

/** Identify the real file type from its bytes; must agree with the file extension. */
function sniffDoc(file) {
  const ext = extOf(file.originalname); if (!EXT[ext]) return null;
  const fd = fs.openSync(file.path, 'r'); const b = Buffer.alloc(16); fs.readSync(fd, b, 0, 16, 0); fs.closeSync(fd);
  let mime = null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) mime = 'image/jpeg';
  else if (b.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) mime = 'image/png';
  else if (b.slice(0, 4).toString() === '%PDF') mime = 'application/pdf';
  else if (b.slice(0, 4).toString() === 'GIF8') mime = 'image/gif';
  else if (b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') mime = 'image/webp';
  else if (b.slice(4, 8).toString() === 'ftyp' && ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1'].includes(b.slice(8, 12).toString())) mime = 'image/heic';
  else if ((b[0] === 0x49 && b[1] === 0x49 && b[2] === 0x2a && b[3] === 0) || (b[0] === 0x4d && b[1] === 0x4d && b[2] === 0 && b[3] === 0x2a)) mime = 'image/tiff';
  else if (b.slice(0, 8).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]))) mime = 'application/msword';
  else if (b[0] === 0x50 && b[1] === 0x4b && b[2] === 3 && b[3] === 4 && fs.readFileSync(file.path).includes('word/')) mime = EXT.docx;
  return mime && mime === EXT[ext] ? mime : null;
}

const docUpload = multer({
  storage: multer.diskStorage({ destination: DOC_DIR, filename: (req, f, cb) => cb(null, S.randomToken(16)) }),
  limits: { fileSize: config.maxDocumentBytes, files: 5, fields: 20 },
  fileFilter: (req, f, cb) => (EXT[extOf(f.originalname)] ? cb(null, true) : cb(new HttpError(400, 'Unsupported file type. Allowed: PDF, PNG, JPG, JPEG, GIF, WEBP, HEIC, TIFF, DOC, DOCX.'))),
}).array('files', 5);
const runDocUpload = (req, res, next) => docUpload(req, res, (err) => {
  if (!err) return next();
  if (err.code === 'LIMIT_FILE_SIZE') return next(new HttpError(400, `A file is too large. Maximum size is ${config.maxDocumentBytes / 1048576} MB each.`));
  if (err.code === 'LIMIT_UNEXPECTED_FILE' || err.code === 'LIMIT_FILE_COUNT') return next(new HttpError(400, 'You can upload up to 5 files at a time.'));
  next(err instanceof HttpError ? err : new HttpError(400, 'The file could not be uploaded.'));
});
const rmAll = (files) => (files || []).forEach((f) => fs.unlink(f.path, () => {}));

// ---- access rule: a consultant may open a patient's records only through a booking assigned to them
async function consultantMayView(c, consultantId, patientId) {
  const cutoff = T.addDays(T.nowLocal().date, -config.recordAccessDays);
  const [r] = await c.query(
    `SELECT id FROM bookings WHERE consultant_id=? AND patient_id=?
        AND (status IN ('confirmed','reschedule_requested') OR (status='completed' AND appointment_date >= ?)) LIMIT 1`, [consultantId, patientId, cutoff]);
  return r.length > 0;
}
const isPatient = (req) => req.user.portals.includes('patient');
const asMode = (req) => req.query.as || (isPatient(req) ? 'patient' : 'consultant');

const shapeDoc = (d) => ({ id: d.id, category: d.category, testType: d.test_type, title: d.title, notes: d.notes, testDate: d.test_date,
  fileName: d.original_name, mime: d.mime_type, size: d.size_bytes, uploadedAt: T.iso(d.uploaded_at), viewable: INLINE.has(d.mime_type) });

// ================= Patient documents / test results =================
router.get('/documents', requirePortal('patient'), async (req, res, next) => {
  try {
    const [rows] = await db.query('SELECT * FROM patient_documents WHERE patient_id=? AND deleted_at IS NULL ORDER BY uploaded_at DESC, id DESC', [req.user.id]);
    res.json({ documents: rows.map(shapeDoc), testTypes: TEST_TYPES, categories: CATEGORIES, maxMb: config.maxDocumentBytes / 1048576, formats: Object.keys(EXT) });
  } catch (e) { next(e); }
});

router.post('/documents', requirePortal('patient'), runDocUpload, async (req, res, next) => {
  const files = req.files || [];
  try {
    const b = req.body || {};
    if (!files.length) throw bad('Please choose at least one file to upload.');
    const category = CATEGORIES.includes(b.category) ? b.category : 'lab_result';
    const testType = category === 'lab_result' ? V.str(b.testType, { max: 60, field: 'Test type' }) : V.str(b.testType, { max: 60, field: 'Test type', required: false });
    if (testType && !TEST_TYPES.includes(testType)) throw bad('Please choose a valid test type.');
    const titleIn = V.str(b.title, { max: 150, field: 'Title', required: false });
    const notes = V.str(b.notes, { max: 500, field: 'Notes', required: false });
    let testDate = null; if (b.testDate) { if (!T.isValidDate(b.testDate) || b.testDate > T.nowLocal().date) throw bad('Please enter a valid test date (not in the future).'); testDate = b.testDate; }
    const checked = files.map((f) => { const mime = sniffDoc(f); if (!mime) throw bad(`"${f.originalname}" is not a valid file of its type. Allowed: PDF, PNG, JPG, JPEG, GIF, WEBP, HEIC, TIFF, DOC, DOCX.`); return { f, mime }; });
    const labItemId = b.labItemId ? V.int(b.labItemId, { field: 'Lab request item' }) : null;

    const out = await tx(async (c) => {
      let item = null;
      if (labItemId) {
        [[item]] = await c.query(`SELECT i.*, r.consultant_id, r.id AS rid FROM lab_request_items i JOIN lab_requests r ON r.id=i.request_id
           WHERE i.id=? AND r.patient_id=? AND r.status='open' AND i.status='pending' FOR UPDATE`, [labItemId, req.user.id]);
        if (!item) throw bad('That test request is no longer open.');
      } else if (testType && testType !== 'Other') {
        [[item]] = await c.query(`SELECT i.*, r.consultant_id, r.id AS rid FROM lab_request_items i JOIN lab_requests r ON r.id=i.request_id
           WHERE i.test_type=? AND r.patient_id=? AND r.status='open' AND i.status='pending' ORDER BY r.created_at LIMIT 1 FOR UPDATE`, [testType, req.user.id]);
      }
      const ids = [];
      for (const { f, mime } of checked) {
        const sha = S.sha256(fs.readFileSync(f.path));
        const title = titleIn || (testType ? `${testType} result` : f.originalname.slice(0, 150));
        const [r] = await c.query(
          `INSERT INTO patient_documents (patient_id, category, test_type, title, notes, test_date, stored_name, original_name, mime_type, size_bytes, sha256)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          [req.user.id, category, testType, title, notes, testDate, path.basename(f.path), String(f.originalname).replace(/[^\w.\- ]/g, '_').slice(0, 200), mime, f.size, sha]);
        ids.push(r.insertId);
        await audit(c, req, 'document.upload', 'document', r.insertId, { category, testType, size: f.size });
      }
      if (item) {
        await c.query("UPDATE lab_request_items SET status='uploaded', document_id=?, fulfilled_at=UTC_TIMESTAMP() WHERE id=?", [ids[0], item.id]);
        const [[left]] = await c.query("SELECT COUNT(*) n FROM lab_request_items WHERE request_id=? AND status='pending'", [item.rid]);
        if (!left.n) await c.query("UPDATE lab_requests SET status='completed' WHERE id=?", [item.rid]);
        await notify(c, item.consultant_id, 'lab_result', 'Lab result uploaded', `${req.user.fullName} uploaded the requested ${item.test_type} result.`);
      }
      return { ids, linkedToRequest: !!item };
    });
    res.status(201).json({ ok: true, ...out });
  } catch (e) { rmAll(files); next(e); }
});

router.get('/documents/:id/file', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Document' });
    const [[d]] = await db.query('SELECT * FROM patient_documents WHERE id=? AND deleted_at IS NULL', [id]);
    if (!d) throw new HttpError(404, 'Document not found.');
    const mine = req.user.id === d.patient_id;
    if (!mine) {
      // Only a consultant with an active booking for this patient. Owners/admins/staff get nothing by role alone.
      if (!(req.user.isConsultant && await consultantMayView(db, req.user.id, d.patient_id))) throw new HttpError(404, 'Document not found.');
      await audit(null, req, 'document.view', 'document', id, { patientId: d.patient_id });
    }
    const file = path.join(DOC_DIR, path.basename(d.stored_name));
    if (!fs.existsSync(file)) throw new HttpError(404, 'The file is missing from storage.');
    const inline = INLINE.has(d.mime_type) && req.query.download !== '1';
    res.set({ 'Content-Type': d.mime_type, 'Cache-Control': 'private, no-store',
      'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename="${d.original_name.replace(/"/g, '')}"`,
      'Content-Security-Policy': "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox" });
    fs.createReadStream(file).pipe(res);
  } catch (e) { next(e); }
});

router.delete('/documents/:id', requirePortal('patient'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Document' });
    await tx(async (c) => {
      const [r] = await c.query('UPDATE patient_documents SET deleted_at=UTC_TIMESTAMP() WHERE id=? AND patient_id=? AND deleted_at IS NULL', [id, req.user.id]);
      if (!r.affectedRows) throw new HttpError(404, 'Document not found.');
      const [items] = await c.query('SELECT id, request_id FROM lab_request_items WHERE document_id=?', [id]);
      for (const it of items) {
        await c.query("UPDATE lab_request_items SET status='pending', document_id=NULL, fulfilled_at=NULL WHERE id=?", [it.id]);
        await c.query("UPDATE lab_requests SET status='open' WHERE id=? AND status='completed'", [it.request_id]);
      }
      await audit(c, req, 'document.delete', 'document', id, null);
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ================= Lab test requests =================
async function labRequestsFor(c, where, args) {
  const [reqs] = await c.query(
    `SELECT r.*, cu.full_name AS consultant_name, pu.full_name AS patient_name FROM lab_requests r JOIN users cu ON cu.id=r.consultant_id JOIN users pu ON pu.id=r.patient_id
      WHERE ${where} ORDER BY r.created_at DESC LIMIT 100`, args);
  if (!reqs.length) return [];
  const [items] = await c.query('SELECT i.id, i.request_id, i.test_type, i.status, i.document_id FROM lab_request_items i WHERE i.request_id IN (?) ORDER BY i.id', [reqs.map((r) => r.id)]);
  return reqs.map((r) => ({ id: r.id, bookingId: r.booking_id, status: r.status, notes: r.notes, createdAt: T.iso(r.created_at), consultantName: r.consultant_name, patientName: r.patient_name, patientId: r.patient_id,
    items: items.filter((i) => i.request_id === r.id).map((i) => ({ id: i.id, testType: i.test_type, status: i.status, documentId: i.document_id })) }));
}

router.get('/lab-requests', async (req, res, next) => {
  try {
    const mode = asMode(req);
    if (mode === 'patient') { if (!isPatient(req)) throw new HttpError(403, 'Not a patient account.'); return res.json({ requests: await labRequestsFor(db, "r.patient_id=? AND r.status<>'cancelled'", [req.user.id]), testTypes: TEST_TYPES }); }
    if (!req.user.isConsultant) throw new HttpError(403, 'You are not a consultant.');
    res.json({ requests: await labRequestsFor(db, 'r.consultant_id=?', [req.user.id]), testTypes: TEST_TYPES });
  } catch (e) { next(e); }
});

router.post('/lab-requests', async (req, res, next) => {
  try {
    if (!req.user.isConsultant) throw new HttpError(403, 'Only consultants can request lab tests.');
    const b = req.body || {};
    const bookingId = V.int(b.bookingId, { field: 'Booking' });
    const tests = [...new Set((Array.isArray(b.tests) ? b.tests : []).map(String))];
    if (!tests.length) throw bad('Please select at least one test.');
    for (const t of tests) if (!TEST_TYPES.includes(t)) throw bad('Invalid test selected.');
    const notes = V.str(b.notes, { max: 500, field: 'Notes', required: false });
    const created = await tx(async (c) => {
      const [[bk]] = await c.query('SELECT id, booking_code, patient_id, consultant_id, status FROM bookings WHERE id=? FOR UPDATE', [bookingId]);
      if (!bk || bk.consultant_id !== req.user.id || !['confirmed', 'reschedule_requested', 'completed'].includes(bk.status)) throw new HttpError(404, 'Booking not found.');
      const [r] = await c.query('INSERT INTO lab_requests (booking_id, patient_id, consultant_id, notes) VALUES (?,?,?,?)', [bookingId, bk.patient_id, req.user.id, notes]);
      for (const t of tests) await c.query('INSERT INTO lab_request_items (request_id, test_type) VALUES (?,?)', [r.insertId, t]);
      await notify(c, bk.patient_id, 'lab_request', 'Lab tests requested', `${req.user.fullName} requested: ${tests.join(', ')}. Upload the results from "Test results & documents" when ready.`, bookingId);
      await audit(c, req, 'lab_request.create', 'lab_request', r.insertId, { tests, booking: bk.booking_code });
      return r.insertId;
    });
    res.status(201).json({ ok: true, id: created });
  } catch (e) { next(e); }
});

router.post('/lab-requests/:id/cancel', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Request' });
    await tx(async (c) => {
      const [[r]] = await c.query("SELECT * FROM lab_requests WHERE id=? AND consultant_id=? AND status='open' FOR UPDATE", [id, req.user.id]);
      if (!r) throw new HttpError(404, 'Request not found.');
      await c.query("UPDATE lab_requests SET status='cancelled' WHERE id=?", [id]);
      await notify(c, r.patient_id, 'lab_request', 'Lab request cancelled', 'A lab test request was cancelled by your consultant.', r.booking_id);
      await audit(c, req, 'lab_request.cancel', 'lab_request', id, null);
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ================= Prescriptions =================
async function loadRx(c, where, args) {
  const [rows] = await c.query(
    `SELECT p.*, b.booking_code, pu.full_name AS patient_name, pp.patient_code, pp.age, pp.gender, cu.full_name AS consultant_name, co.specialty
       FROM prescriptions p JOIN bookings b ON b.id=p.booking_id JOIN users pu ON pu.id=p.patient_id JOIN patient_profiles pp ON pp.user_id=p.patient_id
       JOIN users cu ON cu.id=p.consultant_id JOIN consultants co ON co.user_id=p.consultant_id WHERE ${where} ORDER BY p.issued_at DESC, p.id DESC LIMIT 200`, args);
  if (!rows.length) return [];
  const [items] = await c.query('SELECT * FROM prescription_items WHERE prescription_id IN (?) ORDER BY sort_order, id', [rows.map((r) => r.id)]);
  return rows.map((r) => ({
    id: r.id, rxCode: r.rx_code, bookingId: r.booking_id, bookingCode: r.booking_code, status: r.status, voidReason: r.void_reason,
    diagnosis: r.diagnosis, advice: r.advice, issuedAt: T.iso(r.issued_at), patientId: r.patient_id, patientName: r.patient_name, patientCode: r.patient_code,
    patientAge: r.age, patientGender: r.gender, consultantId: r.consultant_id, consultantName: r.consultant_name, consultantSpecialty: r.specialty,
    items: items.filter((i) => i.prescription_id === r.id).map((i) => ({ medication: i.medication, dosage: i.dosage, frequency: i.frequency, duration: i.duration, instructions: i.instructions })),
  }));
}

router.get('/prescriptions', async (req, res, next) => {
  try {
    const mode = asMode(req);
    if (mode === 'patient') { if (!isPatient(req)) throw new HttpError(403, 'Not a patient account.'); return res.json({ prescriptions: await loadRx(db, 'p.patient_id=?', [req.user.id]) }); }
    if (!req.user.isConsultant) throw new HttpError(403, 'You are not a consultant.');
    res.json({ prescriptions: await loadRx(db, 'p.consultant_id=?', [req.user.id]) });
  } catch (e) { next(e); }
});

async function rxForUser(req) {
  const id = V.int(req.params.id, { field: 'Prescription' });
  const [rx] = await loadRx(db, 'p.id=?', [id]);
  // ONLY the patient it was written for and the consultant who wrote it. No role (owner, admin, support) grants access.
  if (!rx || (rx.patientId !== req.user.id && rx.consultantId !== req.user.id)) throw new HttpError(404, 'Prescription not found.');
  return rx;
}
router.get('/prescriptions/:id', async (req, res, next) => { try { res.json({ prescription: await rxForUser(req) }); } catch (e) { next(e); } });
router.get('/prescriptions/:id/pdf', async (req, res, next) => {
  try {
    const rx = await rxForUser(req);
    if (req.user.id === rx.consultantId) await audit(null, req, 'prescription.pdf', 'prescription', rx.id, null);
    writePrescriptionPdf(res, rx, `prescription-${rx.rxCode}.pdf`);
  } catch (e) { next(e); }
});

router.post('/prescriptions', async (req, res, next) => {
  try {
    if (!req.user.isConsultant) throw new HttpError(403, 'Only consultants can write prescriptions.');
    const b = req.body || {};
    const bookingId = V.int(b.bookingId, { field: 'Booking' });
    const diagnosis = V.str(b.diagnosis, { min: 3, max: 500, field: 'Clinical diagnosis' });
    const advice = V.str(b.advice, { max: 1000, field: 'Medical advice', required: false });
    const raw = Array.isArray(b.items) ? b.items : [];
    if (!raw.length || raw.length > 15) throw bad('Add between 1 and 15 medications.');
    const items = raw.map((it, i) => ({
      medication: V.str(it.medication, { max: 150, field: `Medication ${i + 1} name` }), dosage: V.str(it.dosage, { max: 100, field: `Medication ${i + 1} dosage` }),
      frequency: V.str(it.frequency, { max: 100, field: `Medication ${i + 1} frequency` }), duration: V.str(it.duration, { max: 100, field: `Medication ${i + 1} duration` }),
      instructions: V.str(it.instructions, { max: 300, field: `Medication ${i + 1} instructions`, required: false }),
    }));
    const id = await tx(async (c) => {
      const [[bk]] = await c.query('SELECT * FROM bookings WHERE id=? FOR UPDATE', [bookingId]);
      if (!bk || bk.consultant_id !== req.user.id) throw new HttpError(404, 'Booking not found.');   // owners/admins cannot prescribe on someone else's consultation
      if (!['confirmed', 'completed'].includes(bk.status)) throw bad('Prescriptions can be written for confirmed or completed consultations.');
      const n = T.nowLocal();
      if (bk.appointment_date > n.date || (bk.appointment_date === n.date && bk.start_time > n.time)) throw bad('You can write a prescription once the consultation has started.');
      let code; let r;
      for (let i = 0; i < 5 && !r; i++) {
        code = `RX-${n.date.replace(/-/g, '')}-${S.randomToken(3).toUpperCase()}`;
        try { [r] = await c.query('INSERT INTO prescriptions (rx_code, booking_id, patient_id, consultant_id, diagnosis, advice) VALUES (?,?,?,?,?,?)', [code, bookingId, bk.patient_id, req.user.id, diagnosis, advice]); }
        catch (e) { if (e.code === 'ER_DUP_ENTRY') continue; throw e; }
      }
      if (!r) throw new Error('Could not allocate prescription number');
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        await c.query('INSERT INTO prescription_items (prescription_id, sort_order, medication, dosage, frequency, duration, instructions) VALUES (?,?,?,?,?,?,?)',
          [r.insertId, i, it.medication, it.dosage, it.frequency, it.duration, it.instructions]);
      }
      await notify(c, bk.patient_id, 'prescription', 'New prescription', `${req.user.fullName} issued prescription ${code}. Open "Prescriptions" to view or download the PDF.`, bookingId);
      await audit(c, req, 'prescription.issue', 'prescription', r.insertId, { code, medications: items.length, booking: bk.booking_code });
      return r.insertId;
    });
    res.status(201).json({ ok: true, id });
  } catch (e) { next(e); }
});

router.post('/prescriptions/:id/void', async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Prescription' });
    const reason = V.str(req.body.reason, { min: 5, max: 300, field: 'Reason' });
    await tx(async (c) => {
      const [[rx]] = await c.query("SELECT * FROM prescriptions WHERE id=? AND consultant_id=? AND status='issued' FOR UPDATE", [id, req.user.id]);
      if (!rx) throw new HttpError(404, 'Prescription not found.');
      await c.query("UPDATE prescriptions SET status='void', void_reason=?, voided_at=UTC_TIMESTAMP() WHERE id=?", [reason, id]);
      await notify(c, rx.patient_id, 'prescription', 'Prescription voided', `Prescription ${rx.rx_code} was voided by your consultant: ${reason}. Do not use it.`, rx.booking_id);
      await audit(c, req, 'prescription.void', 'prescription', id, { reason });
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ================= Consultant: patients and their records =================
router.get('/my-patients', async (req, res, next) => {
  try {
    if (!req.user.isConsultant) throw new HttpError(403, 'You are not a consultant.');
    const cutoff = T.addDays(T.nowLocal().date, -config.recordAccessDays);
    const [rows] = await db.query(
      `SELECT u.id, u.full_name, pp.patient_code, pp.age, pp.gender, COUNT(*) AS bookings, MAX(b.appointment_date) AS last_date,
              (SELECT COUNT(*) FROM patient_documents d WHERE d.patient_id=u.id AND d.deleted_at IS NULL) AS docs
         FROM bookings b JOIN users u ON u.id=b.patient_id JOIN patient_profiles pp ON pp.user_id=u.id
        WHERE b.consultant_id=? AND (b.status IN ('confirmed','reschedule_requested') OR (b.status='completed' AND b.appointment_date >= ?))
        GROUP BY u.id, u.full_name, pp.patient_code, pp.age, pp.gender ORDER BY MAX(b.appointment_date) DESC`, [req.user.id, cutoff]);
    res.json({ patients: rows.map((r) => ({ id: r.id, fullName: r.full_name, patientCode: r.patient_code, age: r.age, gender: r.gender, bookings: r.bookings, lastDate: r.last_date, documents: r.docs })) });
  } catch (e) { next(e); }
});

router.get('/patients/:id/records', async (req, res, next) => {
  try {
    const pid = V.int(req.params.id, { field: 'Patient' });
    if (!req.user.isConsultant || !(await consultantMayView(db, req.user.id, pid))) throw new HttpError(404, 'Patient not found.');
    const [[p]] = await db.query('SELECT u.id, u.full_name, pp.patient_code, pp.age, pp.gender FROM users u JOIN patient_profiles pp ON pp.user_id=u.id WHERE u.id=?', [pid]);
    const cutoff = T.addDays(T.nowLocal().date, -config.recordAccessDays);
    const [bks] = await db.query(
      `SELECT id, booking_code, appointment_date, start_time, status, service_name FROM bookings WHERE consultant_id=? AND patient_id=?
          AND (status IN ('confirmed','reschedule_requested') OR (status='completed' AND appointment_date >= ?)) ORDER BY appointment_date DESC, start_time DESC`, [req.user.id, pid, cutoff]);
    const [docs] = await db.query('SELECT * FROM patient_documents WHERE patient_id=? AND deleted_at IS NULL ORDER BY COALESCE(test_date, DATE(uploaded_at)) DESC, id DESC', [pid]);
    await audit(null, req, 'records.view', 'user', pid, null);
    res.json({
      patient: { id: p.id, fullName: p.full_name, patientCode: p.patient_code, age: p.age, gender: p.gender },
      bookings: bks.map((b) => ({ id: b.id, code: b.booking_code, date: b.appointment_date, startTime: b.start_time.slice(0, 5), status: b.status, serviceName: b.service_name })),
      documents: docs.map(shapeDoc),
      labRequests: await labRequestsFor(db, 'r.patient_id=? AND r.consultant_id=?', [pid, req.user.id]),
      prescriptions: await loadRx(db, 'p.patient_id=? AND p.consultant_id=?', [pid, req.user.id]),
      testTypes: TEST_TYPES,
    });
  } catch (e) { next(e); }
});

// ================= Patient: payment history =================
router.get('/my/payments', requirePortal('patient'), async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT b.id, b.booking_code, b.service_name, b.fee_amount, b.appointment_date, b.status AS booking_status, pr.status, pr.uploaded_at, pr.reviewed_at, pr.review_note
         FROM bookings b JOIN payment_receipts pr ON pr.id=(SELECT MAX(id) FROM payment_receipts WHERE booking_id=b.id)
        WHERE b.patient_id=? ORDER BY b.created_at DESC LIMIT 200`, [req.user.id]);
    res.json({ payments: rows.map((r) => ({ bookingId: r.id, code: r.booking_code, serviceName: r.service_name, amount: Number(r.fee_amount), date: r.appointment_date,
      bookingStatus: r.booking_status, status: r.status, uploadedAt: T.iso(r.uploaded_at), reviewedAt: T.iso(r.reviewed_at), note: r.review_note })) });
  } catch (e) { next(e); }
});

module.exports = router;
