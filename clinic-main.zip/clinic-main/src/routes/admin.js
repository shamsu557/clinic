'use strict';
const express = require('express');
const config = require('../config');
const { db, tx } = require('../db');
const S = require('../lib/security');
const V = require('../lib/validate');
const T = require('../lib/time');
const { audit } = require('../lib/audit');
const { notifyPermission } = require('../lib/notify');
const wa = require('../lib/whatsapp');
const { requirePerm } = require('../middleware/auth');

const router = express.Router();
const { HttpError, bad } = V;

const dupMsg = 'Another account already uses this email address or phone number.';

// ---------- Roles & permissions ----------
router.get('/permissions', requirePerm('roles.manage', 'users.manage'), async (req, res, next) => {
  try { const [rows] = await db.query('SELECT code, description FROM permissions ORDER BY code'); res.json({ permissions: rows }); }
  catch (e) { next(e); }
});

router.get('/roles', requirePerm('users.view', 'users.manage', 'roles.manage'), async (req, res, next) => {
  try {
    const [roles] = await db.query('SELECT id, code, name, portal, rank_level, is_system FROM roles ORDER BY rank_level DESC, name');
    const [rp] = await db.query('SELECT rp.role_id, p.code FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id');
    res.json({ roles: roles.map((r) => ({ id: r.id, code: r.code, name: r.name, portal: r.portal, rank: r.rank_level, isSystem: !!r.is_system,
      permissions: rp.filter((x) => x.role_id === r.id).map((x) => x.code) })) });
  } catch (e) { next(e); }
});

async function validPermissionCodes(list) {
  if (!Array.isArray(list)) throw bad('Permissions must be a list.');
  const [rows] = await db.query('SELECT id, code FROM permissions');
  const map = new Map(rows.map((r) => [r.code, r.id]));
  const ids = [];
  for (const c of new Set(list)) { if (!map.has(c)) throw bad(`Unknown permission: ${c}`); ids.push(map.get(c)); }
  return ids;
}

// Owner-only: custom staff roles. Custom roles always rank below Support Staff/Consultant so they cannot manage them.
router.post('/roles', requirePerm('roles.manage'), async (req, res, next) => {
  try {
    const name = V.str(req.body.name, { min: 3, max: 80, field: 'Role name' });
    const code = 'custom_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 30);
    const ids = await validPermissionCodes(req.body.permissions || []);
    await tx(async (c) => {
      let r;
      try { [r] = await c.query("INSERT INTO roles (code, name, portal, rank_level, is_system) VALUES (?,?, 'staff', 30, 0)", [code, name]); }
      catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'A role with this name already exists.'); throw e; }
      for (const pid of ids) await c.query('INSERT INTO role_permissions (role_id, permission_id) VALUES (?,?)', [r.insertId, pid]);
      await audit(c, req, 'role.create', 'role', r.insertId, { name, permissions: req.body.permissions });
    });
    res.status(201).json({ ok: true });
  } catch (e) { next(e); }
});

router.put('/roles/:id', requirePerm('roles.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Role' });
    const [[role]] = await db.query('SELECT * FROM roles WHERE id=?', [id]);
    if (!role) throw new HttpError(404, 'Role not found.');
    if (role.code === 'owner' || role.code === 'patient') throw new HttpError(403, 'This role cannot be modified.');
    const ids = await validPermissionCodes(req.body.permissions || []);
    await tx(async (c) => {
      if (!role.is_system && req.body.name) await c.query('UPDATE roles SET name=? WHERE id=?', [V.str(req.body.name, { min: 3, max: 80, field: 'Role name' }), id]);
      await c.query('DELETE FROM role_permissions WHERE role_id=?', [id]);
      for (const pid of ids) await c.query('INSERT INTO role_permissions (role_id, permission_id) VALUES (?,?)', [id, pid]);
      await audit(c, req, 'role.update_permissions', 'role', id, { role: role.code, permissions: req.body.permissions });
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- Staff accounts (a person may hold several roles, e.g. Owner + Consultant) ----------
const shapeUser = (u, roles) => ({
  id: u.id, fullName: u.full_name, email: u.email, phone: u.phone, status: u.status,
  roles: roles.map((r) => ({ id: r.id, code: r.code, name: r.name, portal: r.portal, rank: r.rank_level })),
  roleIds: roles.map((r) => r.id), roleName: roles.map((r) => r.name).join(' + '),
  setupPending: !!(u.must_change_password || u.must_setup_security),
  mustChangePassword: !!u.must_change_password, mustSetupSecurity: !!u.must_setup_security,
  lastLoginAt: T.iso(u.last_login_at), createdAt: T.iso(u.created_at),
  specialty: u.specialty || null, jobTitle: u.job_title || null,
});
async function rolesOf(c, ids) {
  if (!ids.length) return new Map();
  const [rows] = await c.query(
    `SELECT ur.user_id, r.id, r.code, r.name, r.portal, r.rank_level FROM user_roles ur JOIN roles r ON r.id=ur.role_id
      WHERE ur.user_id IN (?) ORDER BY r.rank_level DESC, r.name`, [ids]);
  const m = new Map(); rows.forEach((r) => { if (!m.has(r.user_id)) m.set(r.user_id, []); m.get(r.user_id).push(r); });
  return m;
}

router.get('/users', requirePerm('users.view', 'users.manage'), async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.full_name, u.email, u.phone, u.status, u.must_change_password, u.must_setup_security, u.last_login_at, u.created_at,
              c.specialty, sp.job_title
         FROM users u LEFT JOIN consultants c ON c.user_id=u.id LEFT JOIN staff_profiles sp ON sp.user_id=u.id
        WHERE EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND r.portal <> 'patient')
        ORDER BY u.full_name`);
    const rm = await rolesOf(db, rows.map((r) => r.id));
    const users = rows.map((u) => shapeUser(u, rm.get(u.id) || []));
    users.sort((a, b) => Math.max(...b.roles.map((r) => r.rank)) - Math.max(...a.roles.map((r) => r.rank)) || a.fullName.localeCompare(b.fullName));
    res.json({ users });
  } catch (e) { next(e); }
});

/** Roles an actor may hand out: the Owner may assign any staff role (including Owner); others only roles below their own rank. */
async function resolveRoles(actor, rawIds) {
  const ids = [...new Set((Array.isArray(rawIds) ? rawIds : [rawIds]).map((x) => Number(x)).filter(Boolean))];
  if (!ids.length) throw bad('Please select at least one role.');
  const [roles] = await db.query('SELECT * FROM roles WHERE id IN (?)', [ids]);
  if (roles.length !== ids.length) throw bad('Please select valid roles.');
  for (const r of roles) {
    if (r.portal === 'patient') throw bad('The Patient role cannot be assigned to staff.');
    if (!actor.isOwner && r.rank_level >= actor.rank) throw new HttpError(403, `You cannot assign the ${r.name} role.`);
  }
  return roles;
}
const mayManage = (actor, targetRoles) => actor.isOwner || Math.max(...targetRoles.map((r) => r.rank_level)) < actor.rank;
const topRole = (roles) => roles.slice().sort((a, b) => b.rank_level - a.rank_level)[0];

async function otherActiveOwners(c, exceptId) {
  const [[r]] = await c.query(
    `SELECT COUNT(*) n FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles ro ON ro.id=ur.role_id
      WHERE ro.code='owner' AND u.status='active' AND u.id<>?`, [exceptId]);
  return r.n;
}

router.post('/users', requirePerm('users.manage'), async (req, res, next) => {
  try {
    const b = req.body || {};
    const fullName = V.str(b.fullName, { min: 3, max: 150, field: 'Full name' });
    const email = V.normalizeEmail(b.email); const phone = V.normalizePhone(b.phone);
    if (!email) throw bad('Please enter a valid email address.');
    if (!phone) throw bad('Please enter a valid phone number.');
    const roles = await resolveRoles(req.user, b.roleIds !== undefined ? b.roleIds : b.roleId);
    const jobTitle = V.str(b.jobTitle, { max: 100, field: 'Job title', required: false });
    const specialty = V.str(b.specialty, { max: 120, field: 'Specialty', required: false });
    const hash = await S.hashPassword(config.tempStaffPassword);
    let newId;
    try {
      await tx(async (c) => {
        const [r] = await c.query(
          `INSERT INTO users (role_id, full_name, email, phone, password_hash, must_change_password, must_setup_security, created_by)
           VALUES (?,?,?,?,?,1,1,?)`, [topRole(roles).id, fullName, email, phone, hash, req.user.id]);
        newId = r.insertId;
        await c.query('INSERT INTO staff_profiles (user_id, job_title) VALUES (?,?)', [newId, jobTitle]);
        for (const ro of roles) await c.query('INSERT INTO user_roles (user_id, role_id, assigned_by) VALUES (?,?,?)', [newId, ro.id, req.user.id]);
        if (roles.some((x) => x.portal === 'consultant')) await c.query('INSERT INTO consultants (user_id, specialty) VALUES (?,?)', [newId, specialty]);
        await audit(c, req, 'staff.create', 'user', newId, { roles: roles.map((x) => x.name) });
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, dupMsg); throw e; }
    // The temporary password is deliberately NOT returned or logged; the owner communicates it out-of-band.
    res.status(201).json({ ok: true, id: newId, message: 'Staff account created. The temporary password must be changed at first login.' });
  } catch (e) { next(e); }
});

router.patch('/users/:id', requirePerm('users.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'User' });
    const [[target]] = await db.query('SELECT * FROM users WHERE id=?', [id]);
    const curRoles = target ? (await rolesOf(db, [id])).get(id) || [] : [];
    if (!target || !curRoles.length || curRoles.some((r) => r.portal === 'patient')) throw new HttpError(404, 'Staff account not found.');
    const self = target.id === req.user.id;
    if (self && !req.user.isOwner) throw new HttpError(403, 'You cannot change your own roles or status here.');
    if (!self && !mayManage(req.user, curRoles)) throw new HttpError(403, 'You can only manage accounts below your own authority.');
    const b = req.body || {};
    if (self && b.status !== undefined) throw new HttpError(403, 'You cannot change your own account status.');
    const sets = []; const vals = []; const changes = {};
    if (b.fullName !== undefined) { sets.push('full_name=?'); vals.push(V.str(b.fullName, { min: 3, max: 150, field: 'Full name' })); changes.fullName = true; }
    if (b.email !== undefined) { const e = V.normalizeEmail(b.email); if (!e) throw bad('Please enter a valid email address.'); sets.push('email=?'); vals.push(e); changes.email = true; }
    if (b.phone !== undefined) { const p = V.normalizePhone(b.phone); if (!p) throw bad('Please enter a valid phone number.'); sets.push('phone=?'); vals.push(p); changes.phone = true; }
    if (b.status !== undefined) {
      if (!['active', 'disabled'].includes(b.status)) throw bad('Invalid status.');
      if (b.status === 'disabled' && curRoles.some((r) => r.code === 'owner') && !(await otherActiveOwners(db, id))) throw bad('At least one active Owner must remain.');
      sets.push('status=?'); vals.push(b.status); changes.status = b.status;
    }
    let newRoles = null;
    const rawRoleIds = b.roleIds !== undefined ? b.roleIds : (b.roleId !== undefined ? b.roleId : undefined);
    if (rawRoleIds !== undefined) {
      newRoles = await resolveRoles(req.user, rawRoleIds);
      // a person may keep roles they already hold even if above the actor's rank (e.g. an Administrator editing another user's extra role)
      const sameSet = newRoles.length === curRoles.length && newRoles.every((r) => curRoles.some((c) => c.id === r.id));
      if (sameSet) newRoles = null;
    }
    if (newRoles) {
      if (curRoles.some((r) => r.code === 'owner') && !newRoles.some((r) => r.code === 'owner') && !(await otherActiveOwners(db, id))) throw bad('At least one active Owner must remain.');
      if (self && !newRoles.some((r) => r.code === 'owner')) throw bad('You cannot remove your own Owner role.');
      sets.push('role_id=?'); vals.push(topRole(newRoles).id);
      changes.roles = { from: curRoles.map((r) => r.name), to: newRoles.map((r) => r.name) };
    }
    if (!sets.length && b.specialty === undefined && b.jobTitle === undefined) throw bad('Nothing to update.');
    let futureBookings = 0;
    try {
      await tx(async (c) => {
        if (sets.length) await c.query(`UPDATE users SET ${sets.join(', ')} WHERE id=?`, [...vals, id]);
        if (newRoles) {
          await c.query('DELETE FROM user_roles WHERE user_id=?', [id]);
          for (const ro of newRoles) await c.query('INSERT INTO user_roles (user_id, role_id, assigned_by) VALUES (?,?,?)', [id, ro.id, req.user.id]);
          const wasCons = curRoles.some((r) => r.portal === 'consultant'); const isCons = newRoles.some((r) => r.portal === 'consultant');
          if (isCons) { await c.query('INSERT IGNORE INTO consultants (user_id) VALUES (?)', [id]); }
          if (wasCons && !isCons) {
            await c.query('UPDATE consultants SET accepting_bookings=0 WHERE user_id=?', [id]);
            const [[f]] = await c.query("SELECT COUNT(*) n FROM bookings WHERE consultant_id=? AND status IN ('requested','confirmed','reschedule_requested') AND appointment_date >= ?", [id, T.nowLocal().date]);
            futureBookings = f.n;
          }
        }
        if (b.specialty !== undefined && (newRoles ? newRoles : curRoles).some((r) => r.portal === 'consultant'))
          await c.query('UPDATE consultants SET specialty=? WHERE user_id=?', [V.str(b.specialty, { max: 120, required: false, field: 'Specialty' }), id]);
        if (b.jobTitle !== undefined) await c.query('INSERT INTO staff_profiles (user_id, job_title) VALUES (?,?) ON DUPLICATE KEY UPDATE job_title=VALUES(job_title)', [id, V.str(b.jobTitle, { max: 100, required: false, field: 'Job title' })]);
        await audit(c, req, newRoles ? 'staff.roles_changed' : 'staff.update', 'user', id, changes);
        if (futureBookings) await notifyPermission(c, 'bookings.manage', 'consultant_removed', 'Consultant role removed',
          `${target.full_name} is no longer a consultant but has ${futureBookings} upcoming booking(s) that need to be reassigned or rearranged.`);
      });
    } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, dupMsg); throw e; }
    res.json({ ok: true, upcomingBookingsToReview: futureBookings });
  } catch (e) { next(e); }
});

router.post('/users/:id/reset-password', requirePerm('users.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'User' });
    const roles = (await rolesOf(db, [id])).get(id) || [];
    if (!roles.length || roles.some((r) => r.portal === 'patient')) throw new HttpError(404, 'Staff account not found.');
    if (id === req.user.id || !mayManage(req.user, roles)) throw new HttpError(403, 'You can only reset passwords for accounts below your own authority.');
    await tx(async (c) => {
      await c.query('UPDATE users SET password_hash=?, must_change_password=1, must_setup_security=1, failed_login_count=0, locked_until=NULL WHERE id=?',
        [await S.hashPassword(config.tempStaffPassword), id]);
      await c.query('DELETE FROM user_security_answers WHERE user_id=?', [id]);
      await audit(c, req, 'staff.reset_password', 'user', id, null);
    });
    res.json({ ok: true, message: 'Password reset to the temporary password. The user must set a new one at next login.' });
  } catch (e) { next(e); }
});

// ---------- Patients directory ----------
router.get('/patients', requirePerm('patients.view', 'users.view'), async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim().slice(0, 60);
    const like = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
    const [rows] = await db.query(
      `SELECT u.id, u.full_name, u.email, u.phone, u.status, u.created_at, p.patient_code, p.age, p.gender,
              (SELECT COUNT(*) FROM bookings b WHERE b.patient_id=u.id) AS bookings
         FROM users u JOIN patient_profiles p ON p.user_id=u.id
        WHERE (?='' OR u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR p.patient_code LIKE ?)
        ORDER BY u.created_at DESC LIMIT 200`, [q, like, like, like, like]);
    res.json({ patients: rows.map((r) => ({ id: r.id, fullName: r.full_name, email: r.email, phone: r.phone, status: r.status,
      patientCode: r.patient_code, age: r.age, gender: r.gender, bookings: r.bookings, createdAt: T.iso(r.created_at) })) });
  } catch (e) { next(e); }
});

// ---------- Audit log ----------
router.get('/audit', requirePerm('audit.view'), async (req, res, next) => {
  try {
    const limit = Math.min(parseInt(req.query.limit || '200', 10) || 200, 1000);
    const [rows] = await db.query(
      `SELECT a.id, a.action, a.entity_type, a.entity_id, a.entity_label, a.details, a.ip_address, a.created_at, a.actor_id,
              COALESCE(a.actor_name, u.full_name) AS actor_name, a.actor_role
         FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id ORDER BY a.id DESC LIMIT ?`, [limit]);
    res.json({ logs: rows.map((r) => ({ id: r.id, action: r.action, entityType: r.entity_type, entityId: r.entity_id, entityLabel: r.entity_label,
      details: r.details, ip: r.ip_address, actorId: r.actor_id, actor: r.actor_name || null, actorRole: r.actor_role || null, createdAt: T.iso(r.created_at) })) });
  } catch (e) { next(e); }
});

// ---------- Settings (payment account) ----------
router.put('/settings/payment', requirePerm('settings.manage'), async (req, res, next) => {
  try {
    const b = req.body || {};
    const vals = {
      payment_account_name: V.str(b.accountName, { max: 120, field: 'Account name' }),
      payment_bank: V.str(b.bank, { max: 80, field: 'Bank' }),
      payment_account_number: V.str(b.accountNumber, { min: 6, max: 20, field: 'Account number' }),
      payment_instructions: V.str(b.instructions, { max: 400, field: 'Instructions', required: false }) || '',
    };
    if (!/^\d{6,20}$/.test(vals.payment_account_number)) throw bad('Account number must contain digits only.');
    await tx(async (c) => {
      for (const [k, v] of Object.entries(vals))
        await c.query('INSERT INTO app_settings (setting_key, setting_value, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by)', [k, v, req.user.id]);
      await audit(c, req, 'settings.payment_update', 'settings', 'payment', { bank: vals.payment_bank, accountName: vals.payment_account_name });
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- WhatsApp alerts ----------
router.get('/whatsapp', requirePerm('settings.manage', 'bookings.manage'), async (req, res, next) => {
  try {
    const s = await wa.settings();
    res.json({ enabled: s.enabled, number: s.number, provider: wa.provider, automatic: wa.configured });
  } catch (e) { next(e); }
});

router.put('/settings/whatsapp', requirePerm('settings.manage'), async (req, res, next) => {
  try {
    const number = V.normalizePhone(req.body.number);
    if (!number) throw bad('Please enter a valid WhatsApp number, e.g. +234 703 563 9129.');
    const enabled = req.body.enabled === true || req.body.enabled === 'on' || req.body.enabled === '1' ? '1' : '0';
    await tx(async (c) => {
      for (const [k, v] of [['whatsapp_number', number], ['whatsapp_enabled', enabled]])
        await c.query('INSERT INTO app_settings (setting_key, setting_value, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by)', [k, v, req.user.id]);
      await audit(c, req, 'settings.whatsapp_update', 'settings', 'whatsapp', { number, enabled: enabled === '1' });
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.get('/whatsapp/outbox', requirePerm('settings.manage', 'bookings.manage'), async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT o.*, b.booking_code FROM whatsapp_outbox o LEFT JOIN bookings b ON b.id=o.booking_id ORDER BY o.id DESC LIMIT 100`);
    res.json({ messages: rows.map((r) => ({ id: r.id, eventType: r.event_type, code: r.booking_code, to: r.to_number, message: r.message, status: r.status, attempts: r.attempts,
      error: r.last_error, createdAt: T.iso(r.created_at), sentAt: T.iso(r.sent_at), link: `https://wa.me/${wa.digits(r.to_number)}?text=${encodeURIComponent(r.message)}` })) });
  } catch (e) { next(e); }
});

router.post('/whatsapp/outbox/:id/sent', requirePerm('settings.manage', 'bookings.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Message' });
    const [r] = await db.query("UPDATE whatsapp_outbox SET status='sent', provider='manual', sent_at=UTC_TIMESTAMP(), last_error=NULL WHERE id=? AND status IN ('manual','failed','queued')", [id]);
    if (!r.affectedRows) throw new HttpError(404, 'Message not found or already sent.');
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/whatsapp/outbox/:id/retry', requirePerm('settings.manage', 'bookings.manage'), async (req, res, next) => {
  try {
    const id = V.int(req.params.id, { field: 'Message' });
    const [r] = await db.query("UPDATE whatsapp_outbox SET status='queued', attempts=0, last_error=NULL WHERE id=? AND status='failed'", [id]);
    if (!r.affectedRows) throw new HttpError(404, 'Only failed messages can be retried.');
    await wa.flush();
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/whatsapp/test', requirePerm('settings.manage'), async (req, res, next) => {
  try {
    const id = await tx((c) => wa.enqueue(c, 'test', null, `✅ Test message from The Clinic portal, sent by ${req.user.fullName}. WhatsApp alerts are working.`));
    if (!id) throw bad('WhatsApp alerts are switched off, or no number is set.');
    await wa.flush();
    const [[row]] = await db.query('SELECT status, last_error FROM whatsapp_outbox WHERE id=?', [id]);
    await audit(null, req, 'whatsapp.test', 'settings', 'whatsapp', { status: row.status });
    res.json({ ok: true, status: row.status, error: row.last_error });
  } catch (e) { next(e); }
});

module.exports = router;
