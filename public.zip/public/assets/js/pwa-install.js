/* The Clinic install reminder, for desktop, Android and iOS.
 * 'Maybe later' lasts only until the next page visit. We only persist a
 * successful native installation, never a dismissal or patient information.
 * Browser install prompts require HTTPS and the browser's own eligibility checks.
 */
'use strict';
(function () {
  const root = document.getElementById('pwaInstallRoot');
  if (!root) return;

  const ua = navigator.userAgent || '';
  const isIOS = /iPad|iPhone|iPod/i.test(ua) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const isDesktop = !isIOS && !isAndroid;
  const installedKey = 'theclinic-pwa-installed';
  let deferredPrompt = null;
  let dismissedForThisVisit = false;
  let showManual = false;
  let installed = false;

  function isStandalone() {
    return (typeof window.matchMedia === 'function' &&
      (window.matchMedia('(display-mode: standalone)').matches ||
       window.matchMedia('(display-mode: fullscreen)').matches)) ||
      navigator.standalone === true ||
      (typeof document.referrer === 'string' && document.referrer.startsWith('android-app://'));
  }
  function savedInstalled() {
    try { return localStorage.getItem(installedKey) === '1'; } catch (_) { return false; }
  }
  function saveInstalled() {
    try { localStorage.setItem(installedKey, '1'); } catch (_) { /* storage optional */ }
  }
  function hide() { root.replaceChildren(); }
  function dismiss() { dismissedForThisVisit = true; hide(); }
  function markInstalled() {
    installed = true;
    deferredPrompt = null;
    saveInstalled();
    hide();
  }
  installed = isStandalone() || savedInstalled();

  function manualSteps() {
    if (isIOS) {
      return '<ol class="pwa-steps">' +
        '<li>Open this website in <strong>Safari</strong>.</li>' +
        '<li>Tap <strong>Share</strong> (the square with an upward arrow).</li>' +
        '<li>Choose <strong>Add to Home Screen</strong>.</li>' +
        '<li>Tap <strong>Add</strong> (enable <strong>Open as Web App</strong> if shown).</li>' +
        '</ol>';
    }
    if (isAndroid) {
      return '<ol class="pwa-steps">' +
        '<li>Open this site in <strong>Chrome</strong>.</li>' +
        '<li>Tap <strong>⋮</strong> and choose <strong>Install app</strong> or <strong>Add to Home screen</strong>.</li>' +
        '<li>Confirm the installation.</li></ol>';
    }
    return '<ol class="pwa-steps">' +
      '<li>Open this site in <strong>Chrome</strong> or <strong>Edge</strong>.</li>' +
      '<li>Choose the <strong>Install</strong> icon in the address bar, or open the browser menu and select <strong>Install this site as an app</strong>.</li>' +
      '<li>Confirm <strong>Install</strong>.</li></ol>';
  }

  function render() {
    if (dismissedForThisVisit || installed || isStandalone()) { hide(); return; }
    const title = 'Install App';
    const subtitle = isIOS ? 'Add The Clinic to your Home Screen.' :
      (isAndroid ? '' : 'Open The Clinic like a desktop app.');
    root.innerHTML = '<section class="pwa-install" role="region" aria-label="Install The Clinic app">' +
      '<div class="pwa-install-header">' +
      '<img class="pwa-install-icon" src="/assets/icons/icon-192.png" alt="The Clinic icon">' +
      '<div class="pwa-install-info"><h2 class="pwa-install-title">' + title + '</h2>' +
      (subtitle ? '<p class="pwa-install-subtitle">' + subtitle + '</p>' : '') + '</div>' +
      '<button type="button" class="pwa-install-close" data-pwa="later" aria-label="Maybe later">&times;</button>' +
      '</div>' +
      (showManual ? manualSteps() : '') +
      '<div class="pwa-install-buttons">' +
      '<button type="button" class="pwa-btn pwa-btn-secondary" data-pwa="later">Maybe Later</button>' +
      '<button type="button" class="pwa-btn pwa-btn-primary" data-pwa="install">Install App</button>' +
      '</div>' +
      (isIOS && showManual ? '<p class="pwa-install-note">Apple requires installation from the browser Share menu.</p>' : '') +
      '</section>';
  }

  root.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-pwa]');
    if (!button) return;
    if (button.dataset.pwa === 'later') { dismiss(); return; }
    if (button.dataset.pwa !== 'install') return;

    if (!isIOS && deferredPrompt) {
      const prompt = deferredPrompt;
      deferredPrompt = null; // Each native install event may be used once only.
      try {
        // Run prompt() inside the genuine click event (required by browsers).
        await prompt.prompt();
        const choice = await prompt.userChoice;
        if (choice && choice.outcome === 'accepted') { markInstalled(); return; }
        // If declined, dismiss only until the user next visits.
        dismiss();
        return;
      } catch (_) { /* Offer browser menu instructions below. */ }
    }
    // iOS never exposes beforeinstallprompt. Unsupported desktop/Android
    // browsers also need explicit instructions rather than a dead button.
    showManual = true;
    render();
  });

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    if (!dismissedForThisVisit && !installed) render();
  });
  window.addEventListener('appinstalled', markInstalled);
  if (typeof window.matchMedia === 'function') {
    const media = window.matchMedia('(display-mode: standalone)');
    if (media.addEventListener) media.addEventListener('change', () => {
      if (isStandalone()) markInstalled();
    });
  }
  window.addEventListener('pageshow', () => {
    if (isStandalone()) markInstalled();
  });

  // Show on each new visit in a normal browser until installation. Do not save
  // “Maybe Later” across reloads or subsequent visits.
  if (!installed) window.setTimeout(render, 900);

  if ('serviceWorker' in navigator &&
      (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(() => {
        /* The normal website remains functional if registration is blocked. */
      });
    });
  }
})();
