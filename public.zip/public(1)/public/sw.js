/* The Clinic PWA: cache only versioned public, non-sensitive shell assets. */
'use strict';
const VERSION = 'theclinic-static-v3-20261102-about';
const ASSETS = [
  '/offline.html', '/assets/pwa.css', '/assets/app.css',
  '/assets/js/core.js', '/assets/js/auth.js', '/assets/js/booking.js',
  '/assets/js/records.js', '/assets/js/patient.js', '/assets/js/consultant.js',
  '/assets/js/staff.js', '/assets/js/boot.js', '/assets/js/pwa-install.js',
  '/assets/icons/icon-192.png', '/assets/icons/icon-512.png',
  '/assets/icons/icon-maskable-512.png', '/assets/icons/apple-touch-icon.png',
  '/assets/images/logo-transparent.png', '/assets/images/health-bg.svg',
];
const PUBLIC_ASSETS = new Set(ASSETS.filter((p) => p !== '/offline.html'));
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(VERSION).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(Promise.all([
    caches.keys().then((names) => Promise.all(names.filter((n) => n.startsWith('theclinic-static-') && n !== VERSION).map((n) => caches.delete(n)))),
    self.clients.claim(),
  ]));
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  // All navigation, API, downloads, private records, and documents must use network only.
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match('/offline.html')));
    return;
  }
  if (!PUBLIC_ASSETS.has(url.pathname)) return;
  event.respondWith(caches.match(request).then((cached) => cached || fetch(request)));
});
